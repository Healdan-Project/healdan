/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.4.13-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: logicaldoc
-- ------------------------------------------------------
-- Server version	11.4.13-MariaDB-ubu2404

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Sequence structure for `hd_api_token_SEQ`
--

DROP SEQUENCE IF EXISTS `hd_api_token_SEQ`;
CREATE SEQUENCE `hd_api_token_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`hd_api_token_SEQ`, 50100, 0);

--
-- Sequence structure for `hd_client_SEQ`
--

DROP SEQUENCE IF EXISTS `hd_client_SEQ`;
CREATE SEQUENCE `hd_client_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`hd_client_SEQ`, 50100, 0);

--
-- Sequence structure for `hd_hold_device_SEQ`
--

DROP SEQUENCE IF EXISTS `hd_hold_device_SEQ`;
CREATE SEQUENCE `hd_hold_device_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`hd_hold_device_SEQ`, 50100, 0);

--
-- Sequence structure for `hd_matter_SEQ`
--

DROP SEQUENCE IF EXISTS `hd_matter_SEQ`;
CREATE SEQUENCE `hd_matter_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`hd_matter_SEQ`, 50100, 0);

--
-- Sequence structure for `hd_signin_group_SEQ`
--

DROP SEQUENCE IF EXISTS `hd_signin_group_SEQ`;
CREATE SEQUENCE `hd_signin_group_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`hd_signin_group_SEQ`, 50100, 0);

--
-- Sequence structure for `hd_signin_identity_SEQ`
--

DROP SEQUENCE IF EXISTS `hd_signin_identity_SEQ`;
CREATE SEQUENCE `hd_signin_identity_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`hd_signin_identity_SEQ`, 100, 0);

--
-- Sequence structure for `hd_storage_backend_SEQ`
--

DROP SEQUENCE IF EXISTS `hd_storage_backend_SEQ`;
CREATE SEQUENCE `hd_storage_backend_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`hd_storage_backend_SEQ`, 50100, 0);

--
-- Sequence structure for `hd_storage_event_SEQ`
--

DROP SEQUENCE IF EXISTS `hd_storage_event_SEQ`;
CREATE SEQUENCE `hd_storage_event_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`hd_storage_event_SEQ`, 50100, 0);

--
-- Sequence structure for `hd_storage_store_SEQ`
--

DROP SEQUENCE IF EXISTS `hd_storage_store_SEQ`;
CREATE SEQUENCE `hd_storage_store_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`hd_storage_store_SEQ`, 50100, 0);

--
-- Sequence structure for `ld_apikey_SEQ`
--

DROP SEQUENCE IF EXISTS `ld_apikey_SEQ`;
CREATE SEQUENCE `ld_apikey_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`ld_apikey_SEQ`, 100, 0);

--
-- Sequence structure for `ld_attributeset_SEQ`
--

DROP SEQUENCE IF EXISTS `ld_attributeset_SEQ`;
CREATE SEQUENCE `ld_attributeset_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`ld_attributeset_SEQ`, 50100, 0);

--
-- Sequence structure for `ld_bookmark_SEQ`
--

DROP SEQUENCE IF EXISTS `ld_bookmark_SEQ`;
CREATE SEQUENCE `ld_bookmark_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`ld_bookmark_SEQ`, 100, 0);

--
-- Sequence structure for `ld_contact_SEQ`
--

DROP SEQUENCE IF EXISTS `ld_contact_SEQ`;
CREATE SEQUENCE `ld_contact_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`ld_contact_SEQ`, 100, 0);

--
-- Sequence structure for `ld_dashlet_SEQ`
--

DROP SEQUENCE IF EXISTS `ld_dashlet_SEQ`;
CREATE SEQUENCE `ld_dashlet_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`ld_dashlet_SEQ`, 100, 0);

--
-- Sequence structure for `ld_device_SEQ`
--

DROP SEQUENCE IF EXISTS `ld_device_SEQ`;
CREATE SEQUENCE `ld_device_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`ld_device_SEQ`, 50100, 0);

--
-- Sequence structure for `ld_document_SEQ`
--

DROP SEQUENCE IF EXISTS `ld_document_SEQ`;
CREATE SEQUENCE `ld_document_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`ld_document_SEQ`, 50100, 0);

--
-- Sequence structure for `ld_extoption_SEQ`
--

DROP SEQUENCE IF EXISTS `ld_extoption_SEQ`;
CREATE SEQUENCE `ld_extoption_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`ld_extoption_SEQ`, 50100, 0);

--
-- Sequence structure for `ld_filler_SEQ`
--

DROP SEQUENCE IF EXISTS `ld_filler_SEQ`;
CREATE SEQUENCE `ld_filler_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`ld_filler_SEQ`, 100, 0);

--
-- Sequence structure for `ld_folder_SEQ`
--

DROP SEQUENCE IF EXISTS `ld_folder_SEQ`;
CREATE SEQUENCE `ld_folder_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`ld_folder_SEQ`, 50100, 0);

--
-- Sequence structure for `ld_folder_history_SEQ`
--

DROP SEQUENCE IF EXISTS `ld_folder_history_SEQ`;
CREATE SEQUENCE `ld_folder_history_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`ld_folder_history_SEQ`, 50100, 0);

--
-- Sequence structure for `ld_generic_SEQ`
--

DROP SEQUENCE IF EXISTS `ld_generic_SEQ`;
CREATE SEQUENCE `ld_generic_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`ld_generic_SEQ`, 50100, 0);

--
-- Sequence structure for `ld_group_SEQ`
--

DROP SEQUENCE IF EXISTS `ld_group_SEQ`;
CREATE SEQUENCE `ld_group_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`ld_group_SEQ`, 50100, 0);

--
-- Sequence structure for `ld_history_SEQ`
--

DROP SEQUENCE IF EXISTS `ld_history_SEQ`;
CREATE SEQUENCE `ld_history_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`ld_history_SEQ`, 50100, 0);

--
-- Sequence structure for `ld_link_SEQ`
--

DROP SEQUENCE IF EXISTS `ld_link_SEQ`;
CREATE SEQUENCE `ld_link_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`ld_link_SEQ`, 100, 0);

--
-- Sequence structure for `ld_menu_SEQ`
--

DROP SEQUENCE IF EXISTS `ld_menu_SEQ`;
CREATE SEQUENCE `ld_menu_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`ld_menu_SEQ`, 100, 0);

--
-- Sequence structure for `ld_messagetemplate_SEQ`
--

DROP SEQUENCE IF EXISTS `ld_messagetemplate_SEQ`;
CREATE SEQUENCE `ld_messagetemplate_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`ld_messagetemplate_SEQ`, 50100, 0);

--
-- Sequence structure for `ld_note_SEQ`
--

DROP SEQUENCE IF EXISTS `ld_note_SEQ`;
CREATE SEQUENCE `ld_note_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`ld_note_SEQ`, 100, 0);

--
-- Sequence structure for `ld_password_history_SEQ`
--

DROP SEQUENCE IF EXISTS `ld_password_history_SEQ`;
CREATE SEQUENCE `ld_password_history_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`ld_password_history_SEQ`, 50100, 0);

--
-- Sequence structure for `ld_rating_SEQ`
--

DROP SEQUENCE IF EXISTS `ld_rating_SEQ`;
CREATE SEQUENCE `ld_rating_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`ld_rating_SEQ`, 100, 0);

--
-- Sequence structure for `ld_search_SEQ`
--

DROP SEQUENCE IF EXISTS `ld_search_SEQ`;
CREATE SEQUENCE `ld_search_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`ld_search_SEQ`, 100, 0);

--
-- Sequence structure for `ld_sequence_SEQ`
--

DROP SEQUENCE IF EXISTS `ld_sequence_SEQ`;
CREATE SEQUENCE `ld_sequence_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`ld_sequence_SEQ`, 50100, 0);

--
-- Sequence structure for `ld_session_SEQ`
--

DROP SEQUENCE IF EXISTS `ld_session_SEQ`;
CREATE SEQUENCE `ld_session_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`ld_session_SEQ`, 50100, 0);

--
-- Sequence structure for `ld_systemmessage_SEQ`
--

DROP SEQUENCE IF EXISTS `ld_systemmessage_SEQ`;
CREATE SEQUENCE `ld_systemmessage_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`ld_systemmessage_SEQ`, 100, 0);

--
-- Sequence structure for `ld_template_SEQ`
--

DROP SEQUENCE IF EXISTS `ld_template_SEQ`;
CREATE SEQUENCE `ld_template_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`ld_template_SEQ`, 50100, 0);

--
-- Sequence structure for `ld_tenant_SEQ`
--

DROP SEQUENCE IF EXISTS `ld_tenant_SEQ`;
CREATE SEQUENCE `ld_tenant_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`ld_tenant_SEQ`, 100, 0);

--
-- Sequence structure for `ld_ticket_SEQ`
--

DROP SEQUENCE IF EXISTS `ld_ticket_SEQ`;
CREATE SEQUENCE `ld_ticket_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`ld_ticket_SEQ`, 100, 0);

--
-- Sequence structure for `ld_user_SEQ`
--

DROP SEQUENCE IF EXISTS `ld_user_SEQ`;
CREATE SEQUENCE `ld_user_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`ld_user_SEQ`, 50100, 0);

--
-- Sequence structure for `ld_user_history_SEQ`
--

DROP SEQUENCE IF EXISTS `ld_user_history_SEQ`;
CREATE SEQUENCE `ld_user_history_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`ld_user_history_SEQ`, 50100, 0);

--
-- Sequence structure for `ld_version_SEQ`
--

DROP SEQUENCE IF EXISTS `ld_version_SEQ`;
CREATE SEQUENCE `ld_version_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`ld_version_SEQ`, 50100, 0);

--
-- Sequence structure for `ld_webservicecall_SEQ`
--

DROP SEQUENCE IF EXISTS `ld_webservicecall_SEQ`;
CREATE SEQUENCE `ld_webservicecall_SEQ` start with 100 minvalue 1 maxvalue 9223372036854775806 increment by 50 cache 1000 nocycle ENGINE=InnoDB;
DO SETVAL(`ld_webservicecall_SEQ`, 100, 0);

--
-- Table structure for table `docker_init`
--

DROP TABLE IF EXISTS `docker_init`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `docker_init` (
  `completed` timestamp NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `docker_init`
--

LOCK TABLES `docker_init` WRITE;
/*!40000 ALTER TABLE `docker_init` DISABLE KEYS */;
INSERT INTO `docker_init` VALUES
('2026-11-20 02:00:28');
/*!40000 ALTER TABLE `docker_init` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hd_admin_event`
--

DROP TABLE IF EXISTS `hd_admin_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hd_admin_event` (
  `hd_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `hd_tenantid` bigint(20) NOT NULL,
  `hd_date` datetime(3) NOT NULL,
  `hd_userid` bigint(20) NOT NULL,
  `hd_username` varchar(255) NOT NULL,
  `hd_address` varchar(255) DEFAULT NULL,
  `hd_area` varchar(20) NOT NULL,
  `hd_action` varchar(60) NOT NULL,
  `hd_targetkind` varchar(20) NOT NULL,
  `hd_targetid` bigint(20) DEFAULT NULL,
  `hd_targetname` varchar(255) DEFAULT NULL,
  `hd_detail` text DEFAULT NULL,
  PRIMARY KEY (`hd_id`),
  KEY `hd_admin_event_target` (`hd_targetkind`,`hd_targetid`),
  KEY `hd_admin_event_user` (`hd_userid`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hd_admin_event`
--

LOCK TABLES `hd_admin_event` WRITE;
/*!40000 ALTER TABLE `hd_admin_event` DISABLE KEYS */;
INSERT INTO `hd_admin_event` VALUES
(1,1,'2026-11-20 02:00:38.980',1,'admin',NULL,'MATTERS','client.created','client',4951,'1 – Smoke Client','{\"name\":{\"before\":null,\"after\":\"Smoke Client\"},\"number\":{\"before\":null,\"after\":\"1\"}}'),
(2,1,'2026-11-20 02:00:39.096',1,'admin',NULL,'MATTERS','matter.created','matter',4951,'1.1 – Smoke Matter','{\"client\":{\"before\":null,\"after\":\"1 – Smoke Client\"},\"name\":{\"before\":null,\"after\":\"Smoke Matter\"},\"number\":{\"before\":null,\"after\":\"1\"},\"owner\":{\"before\":null,\"after\":\"Admin Admin\"},\"store\":{\"before\":null,\"after\":\"Smoke\"},\"template\":{\"before\":null,\"after\":\"Smoke template\"}}'),
(3,1,'2026-11-20 02:00:39.331',1,'admin',NULL,'MATTERS','matter.created','matter',4952,'1.4 – Second Matter','{\"client\":{\"before\":null,\"after\":\"1 – Smoke Client\"},\"name\":{\"before\":null,\"after\":\"Second Matter\"},\"number\":{\"before\":null,\"after\":\"4\"},\"owner\":{\"before\":null,\"after\":\"Admin Admin\"},\"store\":{\"before\":null,\"after\":\"Smoke\"},\"template\":{\"before\":null,\"after\":\"Smoke template\"}}'),
(4,1,'2026-11-20 02:00:51.258',1,'admin',NULL,'MATTERS','matter.created','matter',4953,'1.5 – Dépôt Müller','{\"client\":{\"before\":null,\"after\":\"1 – Smoke Client\"},\"name\":{\"before\":null,\"after\":\"Dépôt Müller\"},\"number\":{\"before\":null,\"after\":\"5\"},\"owner\":{\"before\":null,\"after\":\"Admin Admin\"},\"store\":{\"before\":null,\"after\":\"Dépôt Local\"},\"template\":{\"before\":null,\"after\":\"Smoke template\"}}');
/*!40000 ALTER TABLE `hd_admin_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hd_api_token`
--

DROP TABLE IF EXISTS `hd_api_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hd_api_token` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `hd_userid` bigint(20) NOT NULL,
  `hd_hash` varchar(64) NOT NULL,
  `hd_name` varchar(255) NOT NULL,
  `hd_lastused` datetime NOT NULL,
  `hd_expires` datetime NOT NULL,
  `hd_sid` varchar(255) DEFAULT NULL,
  `hd_device` varchar(64) DEFAULT NULL,
  `hd_provider` varchar(32) DEFAULT NULL,
  `hd_refresh` text DEFAULT NULL,
  `hd_checked` datetime DEFAULT NULL,
  PRIMARY KEY (`ld_id`),
  UNIQUE KEY `hd_hash` (`hd_hash`),
  KEY `hd_api_token_user` (`hd_userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hd_api_token`
--

LOCK TABLES `hd_api_token` WRITE;
/*!40000 ALTER TABLE `hd_api_token` DISABLE KEYS */;
INSERT INTO `hd_api_token` VALUES
(4951,'2026-11-20 02:00:43','2026-11-20 02:00:43',0,1,1,4952,'4b3c5b7b96b1d91155f6e4832d828105f07daf1ac9c3f7609c3bd8aec2d70c96','Move fixture','2026-11-20 02:00:43','2027-11-20 02:00:43','8c9da877-7056-4e1c-a13e-32cd6e5077d9','move-fixture',NULL,NULL,NULL);
/*!40000 ALTER TABLE `hd_api_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hd_client`
--

DROP TABLE IF EXISTS `hd_client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hd_client` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `hd_number` bigint(20) NOT NULL,
  `hd_name` varchar(255) NOT NULL,
  PRIMARY KEY (`ld_id`),
  UNIQUE KEY `hd_number` (`hd_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hd_client`
--

LOCK TABLES `hd_client` WRITE;
/*!40000 ALTER TABLE `hd_client` DISABLE KEYS */;
INSERT INTO `hd_client` VALUES
(4951,'2026-11-20 02:00:38','2026-11-20 02:00:38',0,0,1,1,'Smoke Client');
/*!40000 ALTER TABLE `hd_client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hd_counter`
--

DROP TABLE IF EXISTS `hd_counter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hd_counter` (
  `name` varchar(64) NOT NULL,
  `next_value` bigint(20) NOT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hd_counter`
--

LOCK TABLES `hd_counter` WRITE;
/*!40000 ALTER TABLE `hd_counter` DISABLE KEYS */;
INSERT INTO `hd_counter` VALUES
('docnumber',6);
/*!40000 ALTER TABLE `hd_counter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hd_email`
--

DROP TABLE IF EXISTS `hd_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hd_email` (
  `hd_docid` bigint(20) NOT NULL,
  `hd_messageid` varchar(998) NOT NULL,
  `hd_messageidhash` char(64) NOT NULL,
  PRIMARY KEY (`hd_docid`),
  KEY `hd_email_messageid` (`hd_messageidhash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hd_email`
--

LOCK TABLES `hd_email` WRITE;
/*!40000 ALTER TABLE `hd_email` DISABLE KEYS */;
INSERT INTO `hd_email` VALUES
(4954,'move-fixture-1@example.com','1a6db3124585682fb3514410928f6a3f29f463ae08050c3a802e370bf08d5122');
/*!40000 ALTER TABLE `hd_email` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hd_error`
--

DROP TABLE IF EXISTS `hd_error`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hd_error` (
  `hd_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `hd_fingerprint` char(64) NOT NULL,
  `hd_level` varchar(10) NOT NULL,
  `hd_area` varchar(30) NOT NULL,
  `hd_logger` varchar(255) NOT NULL,
  `hd_message` text NOT NULL,
  `hd_stack` text DEFAULT NULL,
  `hd_documents` varchar(1000) DEFAULT NULL,
  `hd_total` bigint(20) NOT NULL,
  `hd_firstseen` datetime(3) NOT NULL,
  `hd_lastseen` datetime(3) NOT NULL,
  `hd_resolved` int(11) NOT NULL,
  `hd_resolvedby` varchar(255) DEFAULT NULL,
  `hd_resolvedat` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`hd_id`),
  UNIQUE KEY `hd_error_fingerprint` (`hd_fingerprint`),
  KEY `hd_error_lastseen` (`hd_lastseen`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hd_error`
--

LOCK TABLES `hd_error` WRITE;
/*!40000 ALTER TABLE `hd_error` DISABLE KEYS */;
INSERT INTO `hd_error` VALUES
(1,'efc1958c750d4f69c5c089206bab8d33395f674eb9c6fa072e2eef073ce9efb1','ERROR','Email','com.logicaldoc.core.communication.EMailSender','Couldn\'t connect to host, port: localhost, 25; timeout -1','org.eclipse.angus.mail.util.MailConnectException: Couldn\'t connect to host, port: localhost, 25; timeout -1;\n  nested exception is:\n	java.net.ConnectException: Connection refused\n	at org.eclipse.angus.mail.smtp.SMTPTransport.openServer(SMTPTransport.java:2243)\n	at org.eclipse.angus.mail.smtp.SMTPTransport.protocolConnect(SMTPTransport.java:729)\n	at jakarta.mail.Service.connect(Service.java:345)\n	at com.logicaldoc.core.communication.EMailSender.buildTransport(EMailSender.java:575)\n	at com.logicaldoc.core.communication.EMailSender.send(EMailSender.java:381)\n	at com.logicaldoc.core.communication.EMailSender.send(EMailSender.java:289)\n	at com.logicaldoc.core.communication.EMailSender.lambda$sendAsync$0(EMailSender.java:244)\n	at java.base/java.util.concurrent.FutureTask.run(Unknown Source)\n	at java.base/java.util.concurrent.ScheduledThreadPoolExecutor$ScheduledFutureTask.run(Unknown Source)\n	at java.base/java.util.concurrent.ThreadPoolExecutor.runWorker(Unknown Source)\n	at java.base/java.util.concurrent.ThreadPoolExecutor$Worker.run(Unknown Source)\n	at java.base/java.lang.Thread.run(Unknown Source)\nCaused by: java.net.ConnectException: Connection refused\n	at java.base/sun.nio.ch.Net.connect0(Native Method)\n	at java.base/sun.nio.ch.Net.connect(Unknown Source)\n	at java.base/sun.nio.ch.Net.connect(Unknown Source)\n	at java.base/sun.nio.ch.NioSocketImpl.connect(Unknown Source)\n	at java.base/java.net.SocksSocketImpl.connect(Unknown Source)\n	at java.base/java.net.Socket.connect(Unknown Source)\n	at java.base/java.net.Socket.connect(Unknown Source)\n	at org.eclipse.angus.mail.util.SocketFetcher.createSocket(SocketFetcher.java:368)\n	at org.eclipse.angus.mail.util.SocketFetcher.getSocket(SocketFetcher.java:243)\n	at org.eclipse.angus.mail.smtp.SMTPTransport.openServer(SMTPTransport.java:2193)\n	... 11 more\n',NULL,2,'2026-11-20 02:00:43.964','2026-11-20 02:00:44.002',0,NULL,NULL),
(2,'da9a027c30b534c693558510be0c1ca7f88611cb37653303d74edaa582d59fe6','ERROR','Storage','com.logicaldoc.healdan.storage.MoveFixture','Le dépôt n\'a pas répondu','java.io.IOException: Le dépôt n\'a pas répondu',NULL,3,'2026-11-19 10:15:34.069','2026-11-19 11:20:35.760',1,'admin','2026-11-19 12:00:00.000');
/*!40000 ALTER TABLE `hd_error` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hd_error_hour`
--

DROP TABLE IF EXISTS `hd_error_hour`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hd_error_hour` (
  `hd_errorid` bigint(20) NOT NULL,
  `hd_hour` datetime NOT NULL,
  `hd_count` int(11) NOT NULL,
  PRIMARY KEY (`hd_errorid`,`hd_hour`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hd_error_hour`
--

LOCK TABLES `hd_error_hour` WRITE;
/*!40000 ALTER TABLE `hd_error_hour` DISABLE KEYS */;
INSERT INTO `hd_error_hour` VALUES
(1,'2026-11-20 02:00:00',2),
(2,'2026-11-19 10:00:00',2),
(2,'2026-11-19 11:00:00',1);
/*!40000 ALTER TABLE `hd_error_hour` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hd_hold_device`
--

DROP TABLE IF EXISTS `hd_hold_device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hd_hold_device` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime(3) NOT NULL,
  `ld_creation` datetime(3) NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `hd_docid` bigint(20) NOT NULL,
  `hd_device` varchar(64) DEFAULT NULL,
  `hd_tokenid` bigint(20) DEFAULT NULL,
  `hd_app` varchar(100) DEFAULT NULL,
  `hd_lastsaveid` varchar(64) DEFAULT NULL,
  `hd_lastsaveversionid` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ld_id`),
  UNIQUE KEY `hd_docid` (`hd_docid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hd_hold_device`
--

LOCK TABLES `hd_hold_device` WRITE;
/*!40000 ALTER TABLE `hd_hold_device` DISABLE KEYS */;
INSERT INTO `hd_hold_device` VALUES
(4951,'2026-11-20 02:00:49.100','2026-11-20 02:00:47.879',1,0,1,4951,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `hd_hold_device` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hd_local_value`
--

DROP TABLE IF EXISTS `hd_local_value`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hd_local_value` (
  `hd_objecttype` char(1) NOT NULL,
  `hd_objectid` bigint(20) NOT NULL,
  `hd_attribute` varchar(255) NOT NULL,
  PRIMARY KEY (`hd_objecttype`,`hd_objectid`,`hd_attribute`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hd_local_value`
--

LOCK TABLES `hd_local_value` WRITE;
/*!40000 ALTER TABLE `hd_local_value` DISABLE KEYS */;
INSERT INTO `hd_local_value` VALUES
('F',4955,'client'),
('F',4955,'matter'),
('F',4957,'client'),
('F',4957,'matter'),
('F',4960,'client'),
('F',4960,'matter');
/*!40000 ALTER TABLE `hd_local_value` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hd_matter`
--

DROP TABLE IF EXISTS `hd_matter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hd_matter` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `hd_clientid` bigint(20) NOT NULL,
  `hd_number` bigint(20) NOT NULL,
  `hd_name` varchar(255) NOT NULL,
  `hd_description` varchar(4000) DEFAULT NULL,
  `hd_folderid` bigint(20) NOT NULL,
  `hd_ownerid` bigint(20) NOT NULL,
  `hd_templateid` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ld_id`),
  UNIQUE KEY `hd_folderid` (`hd_folderid`),
  UNIQUE KEY `hd_clientid` (`hd_clientid`,`hd_number`),
  CONSTRAINT `hd_matter_ibfk_1` FOREIGN KEY (`hd_clientid`) REFERENCES `hd_client` (`ld_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hd_matter`
--

LOCK TABLES `hd_matter` WRITE;
/*!40000 ALTER TABLE `hd_matter` DISABLE KEYS */;
INSERT INTO `hd_matter` VALUES
(4951,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,4951,1,'Smoke Matter',NULL,4955,1,4953),
(4952,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,4951,4,'Second Matter',NULL,4957,1,4953),
(4953,'2026-11-20 02:00:51','2026-11-20 02:00:51',0,0,1,4951,5,'Dépôt Müller',NULL,4960,1,4953);
/*!40000 ALTER TABLE `hd_matter` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hd_preview_job`
--

DROP TABLE IF EXISTS `hd_preview_job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hd_preview_job` (
  `hd_docid` bigint(20) NOT NULL,
  `hd_fileversion` varchar(10) NOT NULL,
  `hd_attempts` int(11) NOT NULL,
  `hd_nexttry` datetime NOT NULL,
  `hd_lasterror` varchar(4000) DEFAULT NULL,
  `hd_created` datetime NOT NULL,
  PRIMARY KEY (`hd_docid`,`hd_fileversion`),
  KEY `hd_preview_job_due` (`hd_attempts`,`hd_nexttry`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hd_preview_job`
--

LOCK TABLES `hd_preview_job` WRITE;
/*!40000 ALTER TABLE `hd_preview_job` DISABLE KEYS */;
INSERT INTO `hd_preview_job` VALUES
(4951,'1.0',0,'2026-11-20 02:00:44',NULL,'2026-11-20 02:00:44'),
(4951,'2.0',0,'2026-11-20 02:00:47',NULL,'2026-11-20 02:00:47'),
(4952,'1.0',0,'2026-11-20 02:00:45',NULL,'2026-11-20 02:00:45'),
(4953,'1.0',0,'2026-11-20 02:00:46',NULL,'2026-11-20 02:00:46'),
(4955,'1.0',0,'2026-11-20 02:00:52',NULL,'2026-11-20 02:00:52');
/*!40000 ALTER TABLE `hd_preview_job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hd_schema_history`
--

DROP TABLE IF EXISTS `hd_schema_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hd_schema_history` (
  `installed_rank` int(11) NOT NULL,
  `version` varchar(50) DEFAULT NULL,
  `description` varchar(200) NOT NULL,
  `type` varchar(20) NOT NULL,
  `script` varchar(1000) NOT NULL,
  `checksum` int(11) DEFAULT NULL,
  `installed_by` varchar(100) NOT NULL,
  `installed_on` timestamp NOT NULL DEFAULT current_timestamp(),
  `execution_time` int(11) NOT NULL,
  `success` tinyint(1) NOT NULL,
  PRIMARY KEY (`installed_rank`),
  KEY `hd_schema_history_s_idx` (`success`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hd_schema_history`
--

LOCK TABLES `hd_schema_history` WRITE;
/*!40000 ALTER TABLE `hd_schema_history` DISABLE KEYS */;
INSERT INTO `hd_schema_history` VALUES
(1,'0','<< Flyway Baseline >>','BASELINE','<< Flyway Baseline >>',NULL,'logicaldoc','2026-11-20 02:00:38',0,1),
(2,'1','core tables','SQL','V1__core_tables.sql',147451898,'logicaldoc','2026-11-20 02:00:38',13,1),
(3,'2','preview jobs','SQL','V2__preview_jobs.sql',-1146031727,'logicaldoc','2026-11-20 02:00:38',4,1),
(4,'3','api tokens','SQL','V3__api_tokens.sql',-1972712656,'logicaldoc','2026-11-20 02:00:38',5,1),
(5,'4','devices','SQL','V4__devices.sql',-1730601183,'logicaldoc','2026-11-20 02:00:38',4,1),
(6,'5','last save version','SQL','V5__last_save_version.sql',1764270980,'logicaldoc','2026-11-20 02:00:38',2,1),
(7,'6','signin','SQL','V6__signin.sql',-1101869635,'logicaldoc','2026-11-20 02:00:38',15,1),
(8,'7','refresh token width','SQL','V7__refresh_token_width.sql',-1141537726,'logicaldoc','2026-11-20 02:00:38',4,1),
(9,'8','email index','SQL','V8__email_index.sql',492695923,'logicaldoc','2026-11-20 02:00:38',3,1),
(10,'9','storage','SQL','V9__storage.sql',616168538,'logicaldoc','2026-11-20 02:00:38',23,1),
(11,'10','storage file backend','SQL','V10__storage_file_backend.sql',649549374,'logicaldoc','2026-11-20 02:00:38',3,1),
(12,'11','trash','SQL','V11__trash.sql',-587922475,'logicaldoc','2026-11-20 02:00:38',3,1),
(13,'12','admin','SQL','V12__admin.sql',-1628946373,'logicaldoc','2026-11-20 02:00:38',4,1);
/*!40000 ALTER TABLE `hd_schema_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hd_searchfolder`
--

DROP TABLE IF EXISTS `hd_searchfolder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hd_searchfolder` (
  `hd_folderid` bigint(20) NOT NULL,
  `hd_days` int(11) NOT NULL,
  `hd_onlymine` int(11) NOT NULL,
  `hd_kind` varchar(16) NOT NULL,
  `hd_docclass` varchar(255) DEFAULT NULL,
  `hd_docsubclass` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`hd_folderid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hd_searchfolder`
--

LOCK TABLES `hd_searchfolder` WRITE;
/*!40000 ALTER TABLE `hd_searchfolder` DISABLE KEYS */;
/*!40000 ALTER TABLE `hd_searchfolder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hd_setting`
--

DROP TABLE IF EXISTS `hd_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hd_setting` (
  `name` varchar(255) NOT NULL,
  `value` varchar(4000) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hd_setting`
--

LOCK TABLES `hd_setting` WRITE;
/*!40000 ALTER TABLE `hd_setting` DISABLE KEYS */;
INSERT INTO `hd_setting` VALUES
('api.cors.origins',''),
('api.token.idledays','30'),
('api.token.maxdays','365'),
('class.default','Docs'),
('matter.label','Matter'),
('matter.label.plural','Matters'),
('matter.numbering','PER_CLIENT'),
('profile.template','4951'),
('recentmatters.days','30'),
('seed.api-settings','done'),
('seed.apikey-counters','done'),
('seed.columns','done'),
('seed.count-office-pages','done'),
('seed.document-rows-granting-nothing','done'),
('seed.everyone','done'),
('seed.hide-dropbox','done'),
('seed.profile','done'),
('seed.profile-comments','done'),
('seed.profile-message-id','done'),
('seed.queue-drawing-previews','done'),
('seed.queue-office-previews','done'),
('seed.reindex-office','done'),
('seed.search-attributes','done'),
('seed.search-client-column','done'),
('seed.search-docnumber-column','done'),
('seed.settings','done'),
('seed.signin-settings','done'),
('seed.smoke-api-user','done'),
('seed.smoke-fixture','done'),
('seed.smoke-organising','done'),
('seed.smoke-second-matter','done'),
('seed.smoke-signin','done'),
('seed.smoke-web-user','done'),
('seed.storage-hide-stores','done'),
('seed.storage-record-original','done'),
('seed.storage-settings','done'),
('seed.templates-store','done'),
('seed.throttle-alert','done'),
('seed.throttle-signin','done'),
('seed.trash-record-existing','done'),
('seed.trash-system-destroy','done'),
('signin.adminAlert','false'),
('signin.adminAlert.recipients','admin'),
('signin.password.label','Sign In with a Password'),
('signin.providers','smoke'),
('signin.recheck.minutes','0'),
('signin.smoke.claim.email','email'),
('signin.smoke.claim.groups','groups'),
('signin.smoke.claim.identity','sub'),
('signin.smoke.claim.username','preferred_username'),
('signin.smoke.clientId','healdan'),
('signin.smoke.clientSecret','v1:rAYOUjfkV9FnMMv1oOIxRXWzSDHaU9/G5+NnjJhT4CZE5XwJk3ihm2IoAXsx5q0='),
('signin.smoke.enabled','true'),
('signin.smoke.issuer','http://keycloak:8080/realms/healdan'),
('signin.smoke.label','Sign In with Smoke SSO'),
('signin.smoke.linkByEmail','true'),
('signin.smoke.preset','other'),
('storage.cacheGb','20'),
('storage.holdDays','30'),
('storage.installId','000c1f3e-0cc1-4138-b632-0ccb8a30d869'),
('storage.retestSeconds','60'),
('storage.sweepSeconds','300'),
('storage.transfers','4'),
('store.templates','4951');
/*!40000 ALTER TABLE `hd_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hd_signin_group`
--

DROP TABLE IF EXISTS `hd_signin_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hd_signin_group` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `hd_provider` varchar(32) NOT NULL,
  `hd_value` varchar(255) NOT NULL,
  `hd_groupid` bigint(20) NOT NULL,
  PRIMARY KEY (`ld_id`),
  UNIQUE KEY `hd_provider` (`hd_provider`,`hd_value`,`hd_groupid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hd_signin_group`
--

LOCK TABLES `hd_signin_group` WRITE;
/*!40000 ALTER TABLE `hd_signin_group` DISABLE KEYS */;
INSERT INTO `hd_signin_group` VALUES
(4951,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,'smoke','healdan-users',4952);
/*!40000 ALTER TABLE `hd_signin_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hd_signin_identity`
--

DROP TABLE IF EXISTS `hd_signin_identity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hd_signin_identity` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `hd_provider` varchar(32) NOT NULL,
  `hd_identity` varchar(255) NOT NULL,
  `hd_userid` bigint(20) NOT NULL,
  `hd_linked` datetime NOT NULL,
  `hd_how` varchar(10) NOT NULL,
  `hd_lastsignin` datetime DEFAULT NULL,
  `hd_unlinked` datetime DEFAULT NULL,
  `hd_unlinkedby` bigint(20) DEFAULT NULL,
  `hd_linkkey` varchar(300) DEFAULT NULL,
  `hd_linkuser` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ld_id`),
  UNIQUE KEY `hd_linkkey` (`hd_linkkey`),
  UNIQUE KEY `hd_linkuser` (`hd_linkuser`),
  KEY `hd_signin_identity_provider` (`hd_provider`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hd_signin_identity`
--

LOCK TABLES `hd_signin_identity` WRITE;
/*!40000 ALTER TABLE `hd_signin_identity` DISABLE KEYS */;
/*!40000 ALTER TABLE `hd_signin_identity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hd_storage_backend`
--

DROP TABLE IF EXISTS `hd_storage_backend`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hd_storage_backend` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `hd_name` varchar(100) NOT NULL,
  `hd_kind` varchar(10) NOT NULL,
  `hd_path` varchar(1000) DEFAULT NULL,
  `hd_endpoint` varchar(1000) DEFAULT NULL,
  `hd_region` varchar(100) DEFAULT NULL,
  `hd_bucket` varchar(255) DEFAULT NULL,
  `hd_prefix` varchar(255) DEFAULT NULL,
  `hd_pathstyle` int(11) NOT NULL,
  `hd_accesskey` varchar(255) DEFAULT NULL,
  `hd_secret` varchar(4000) DEFAULT NULL,
  `hd_encrypted` int(11) NOT NULL,
  `hd_keyconfirmed` int(11) NOT NULL,
  PRIMARY KEY (`ld_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hd_storage_backend`
--

LOCK TABLES `hd_storage_backend` WRITE;
/*!40000 ALTER TABLE `hd_storage_backend` DISABLE KEYS */;
INSERT INTO `hd_storage_backend` VALUES
(1,'2026-11-20 02:00:38','2026-11-20 02:00:38',1,0,1,'Original','local',NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,0,0),
(4951,'2026-11-20 02:00:51','2026-11-20 02:00:51',1,0,1,'Move Local','local','/opt/logicaldoc/repository/move-local',NULL,NULL,NULL,NULL,0,NULL,NULL,1,1);
/*!40000 ALTER TABLE `hd_storage_backend` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hd_storage_event`
--

DROP TABLE IF EXISTS `hd_storage_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hd_storage_event` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `hd_backendid` bigint(20) NOT NULL,
  `hd_event` varchar(20) NOT NULL,
  `hd_date` datetime NOT NULL,
  `hd_userid` bigint(20) NOT NULL,
  `hd_username` varchar(255) NOT NULL,
  PRIMARY KEY (`ld_id`),
  KEY `hd_storage_event_backend` (`hd_backendid`,`hd_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hd_storage_event`
--

LOCK TABLES `hd_storage_event` WRITE;
/*!40000 ALTER TABLE `hd_storage_event` DISABLE KEYS */;
INSERT INTO `hd_storage_event` VALUES
(4951,'2026-11-20 02:00:51','2026-11-20 02:00:51',0,0,1,4951,'key-shown','2026-11-20 02:00:51',1,'admin');
/*!40000 ALTER TABLE `hd_storage_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hd_storage_file`
--

DROP TABLE IF EXISTS `hd_storage_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hd_storage_file` (
  `hd_docid` bigint(20) NOT NULL,
  `hd_resource` varchar(255) NOT NULL,
  `hd_backendid` bigint(20) NOT NULL,
  `hd_storeid` bigint(20) DEFAULT NULL,
  `hd_size` bigint(20) NOT NULL,
  `hd_write` bigint(20) NOT NULL,
  `hd_stored` datetime NOT NULL,
  `hd_waiting` datetime DEFAULT NULL,
  `hd_attempts` int(11) NOT NULL,
  `hd_lasterror` varchar(4000) DEFAULT NULL,
  `hd_stuck` int(11) NOT NULL,
  `hd_nexttry` datetime DEFAULT NULL,
  PRIMARY KEY (`hd_docid`,`hd_resource`),
  KEY `hd_storage_file_store` (`hd_storeid`,`hd_backendid`),
  KEY `hd_storage_file_due` (`hd_stuck`,`hd_nexttry`),
  KEY `hd_storage_file_waiting` (`hd_waiting`),
  KEY `hd_storage_file_backend` (`hd_backendid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hd_storage_file`
--

LOCK TABLES `hd_storage_file` WRITE;
/*!40000 ALTER TABLE `hd_storage_file` DISABLE KEYS */;
INSERT INTO `hd_storage_file` VALUES
(4951,'1.0',1,4952,1304,-3394898503609911817,'2026-11-20 02:00:44',NULL,0,NULL,0,NULL),
(4951,'2.0',1,4952,1324,-3776868017013518449,'2026-11-20 02:00:47',NULL,0,NULL,0,NULL),
(4952,'1.0',1,4952,1288,5213122175009689677,'2026-11-20 02:00:45',NULL,0,NULL,0,NULL),
(4953,'1.0',1,4952,1313,664267333378750652,'2026-11-20 02:00:46',NULL,0,NULL,0,NULL),
(4954,'1.0',1,4952,299,-4461358584912789880,'2026-11-20 02:00:49',NULL,0,NULL,0,NULL),
(4955,'1.0',4951,4959,1304,5766751534851883860,'2026-11-20 02:00:52',NULL,0,NULL,0,NULL);
/*!40000 ALTER TABLE `hd_storage_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hd_storage_held`
--

DROP TABLE IF EXISTS `hd_storage_held`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hd_storage_held` (
  `hd_backendid` bigint(20) NOT NULL,
  `hd_location` varchar(700) NOT NULL,
  `hd_docid` bigint(20) NOT NULL,
  `hd_resource` varchar(255) NOT NULL,
  `hd_held` datetime NOT NULL,
  `hd_purge` datetime NOT NULL,
  PRIMARY KEY (`hd_backendid`,`hd_location`),
  KEY `hd_storage_held_purge` (`hd_purge`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hd_storage_held`
--

LOCK TABLES `hd_storage_held` WRITE;
/*!40000 ALTER TABLE `hd_storage_held` DISABLE KEYS */;
/*!40000 ALTER TABLE `hd_storage_held` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hd_storage_store`
--

DROP TABLE IF EXISTS `hd_storage_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hd_storage_store` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `hd_storeid` bigint(20) NOT NULL,
  `hd_backendid` bigint(20) NOT NULL,
  PRIMARY KEY (`ld_id`),
  UNIQUE KEY `hd_storeid` (`hd_storeid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hd_storage_store`
--

LOCK TABLES `hd_storage_store` WRITE;
/*!40000 ALTER TABLE `hd_storage_store` DISABLE KEYS */;
INSERT INTO `hd_storage_store` VALUES
(4951,'2026-11-20 02:00:52','2026-11-20 02:00:52',0,0,1,4959,4951);
/*!40000 ALTER TABLE `hd_storage_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hd_trash`
--

DROP TABLE IF EXISTS `hd_trash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hd_trash` (
  `hd_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `hd_tenantid` bigint(20) NOT NULL,
  `hd_kind` varchar(10) NOT NULL,
  `hd_objectid` bigint(20) NOT NULL,
  `hd_name` varchar(255) NOT NULL,
  `hd_docnumber` varchar(255) DEFAULT NULL,
  `hd_fromfolderid` bigint(20) DEFAULT NULL,
  `hd_frompath` varchar(4000) DEFAULT NULL,
  `hd_matterid` bigint(20) DEFAULT NULL,
  `hd_folders` int(11) NOT NULL,
  `hd_documents` int(11) NOT NULL,
  `hd_deletedby` bigint(20) DEFAULT NULL,
  `hd_deletedbyname` varchar(255) DEFAULT NULL,
  `hd_deletedat` datetime(3) NOT NULL,
  PRIMARY KEY (`hd_id`),
  KEY `hd_trash_deleter` (`hd_tenantid`,`hd_deletedby`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hd_trash`
--

LOCK TABLES `hd_trash` WRITE;
/*!40000 ALTER TABLE `hd_trash` DISABLE KEYS */;
INSERT INTO `hd_trash` VALUES
(1,1,'document',4953,'Draft to delete.docx','3',4956,'[\"Smoke\",\"1.1 – Smoke Matter\",\"Documents\"]',4951,0,0,4952,'User Api','2026-11-20 02:00:49.177');
/*!40000 ALTER TABLE `hd_trash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hd_trash_member`
--

DROP TABLE IF EXISTS `hd_trash_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hd_trash_member` (
  `hd_trashid` bigint(20) NOT NULL,
  `hd_objecttype` char(1) NOT NULL,
  `hd_objectid` bigint(20) NOT NULL,
  `hd_state` varchar(10) NOT NULL,
  `hd_removedby` bigint(20) DEFAULT NULL,
  `hd_removedbyname` varchar(255) DEFAULT NULL,
  `hd_removedat` datetime(3) DEFAULT NULL,
  `hd_restoredby` bigint(20) DEFAULT NULL,
  `hd_restoredbyname` varchar(255) DEFAULT NULL,
  `hd_restoredat` datetime(3) DEFAULT NULL,
  `hd_destroyedat` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`hd_trashid`,`hd_objecttype`,`hd_objectid`),
  KEY `hd_trash_member_object` (`hd_objecttype`,`hd_objectid`,`hd_state`),
  KEY `hd_trash_member_removed` (`hd_state`,`hd_removedat`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hd_trash_member`
--

LOCK TABLES `hd_trash_member` WRITE;
/*!40000 ALTER TABLE `hd_trash_member` DISABLE KEYS */;
INSERT INTO `hd_trash_member` VALUES
(1,'D',4953,'deleted',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `hd_trash_member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_apikey`
--

DROP TABLE IF EXISTS `ld_apikey`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_apikey` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_userid` bigint(20) NOT NULL,
  `ld_lastused` datetime DEFAULT NULL,
  `ld_key` varchar(255) NOT NULL,
  `ld_name` varchar(255) NOT NULL,
  `ld_label` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ld_id`),
  UNIQUE KEY `AK_APIKEY` (`ld_key`),
  UNIQUE KEY `AK_APIKEY2` (`ld_name`,`ld_userid`),
  KEY `LD_APIKEY_USERID` (`ld_userid`),
  CONSTRAINT `FK_APIKEY_USER` FOREIGN KEY (`ld_userid`) REFERENCES `ld_user` (`ld_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_apikey`
--

LOCK TABLES `ld_apikey` WRITE;
/*!40000 ALTER TABLE `ld_apikey` DISABLE KEYS */;
/*!40000 ALTER TABLE `ld_apikey` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_attributeset`
--

DROP TABLE IF EXISTS `ld_attributeset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_attributeset` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_name` varchar(255) NOT NULL,
  `ld_label` varchar(255) DEFAULT NULL,
  `ld_description` varchar(2000) DEFAULT NULL,
  `ld_readonly` int(11) NOT NULL,
  `ld_type` int(11) NOT NULL,
  PRIMARY KEY (`ld_id`),
  UNIQUE KEY `AK_ATTRIBUTESET` (`ld_name`,`ld_tenantid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_attributeset`
--

LOCK TABLES `ld_attributeset` WRITE;
/*!40000 ALTER TABLE `ld_attributeset` DISABLE KEYS */;
INSERT INTO `ld_attributeset` VALUES
(4951,'2026-11-20 02:00:38','2026-11-20 02:00:38',1,0,1,'Healdan profile','Healdan profile','The Class and Subclass lists of the Healdan profile',0,0);
/*!40000 ALTER TABLE `ld_attributeset` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_attributeset_ext`
--

DROP TABLE IF EXISTS `ld_attributeset_ext`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_attributeset_ext` (
  `ld_attsetid` bigint(20) NOT NULL,
  `ld_mandatory` int(11) NOT NULL,
  `ld_type` int(11) NOT NULL,
  `ld_editor` int(11) NOT NULL,
  `ld_position` int(11) NOT NULL,
  `ld_stringvalue` varchar(4000) DEFAULT NULL,
  `ld_stringvalues` varchar(4000) DEFAULT NULL,
  `ld_intvalue` bigint(20) DEFAULT NULL,
  `ld_doublevalue` double DEFAULT NULL,
  `ld_datevalue` datetime DEFAULT NULL,
  `ld_validation` varchar(4000) DEFAULT NULL,
  `ld_initialization` varchar(4000) DEFAULT NULL,
  `ld_name` varchar(255) NOT NULL,
  `ld_label` varchar(255) DEFAULT NULL,
  `ld_setid` bigint(20) DEFAULT NULL,
  `ld_hidden` int(11) NOT NULL,
  `ld_readonly` int(11) NOT NULL,
  `ld_multiple` int(11) NOT NULL,
  `ld_parent` varchar(255) DEFAULT NULL,
  `ld_dependson` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ld_attsetid`,`ld_name`),
  CONSTRAINT `FK_ATT_ATTSET` FOREIGN KEY (`ld_attsetid`) REFERENCES `ld_attributeset` (`ld_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_attributeset_ext`
--

LOCK TABLES `ld_attributeset_ext` WRITE;
/*!40000 ALTER TABLE `ld_attributeset_ext` DISABLE KEYS */;
INSERT INTO `ld_attributeset_ext` VALUES
(4951,0,0,1,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'docclass','Class',4951,0,0,0,NULL,NULL),
(4951,0,0,1,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'docsubclass','Subclass',4951,0,0,0,NULL,NULL);
/*!40000 ALTER TABLE `ld_attributeset_ext` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_bookmark`
--

DROP TABLE IF EXISTS `ld_bookmark`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_bookmark` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_userid` bigint(20) NOT NULL,
  `ld_docid` bigint(20) NOT NULL,
  `ld_title` varchar(255) NOT NULL,
  `ld_description` varchar(4000) DEFAULT NULL,
  `ld_position` int(11) NOT NULL,
  `ld_filetype` varchar(40) DEFAULT NULL,
  `ld_type` int(11) NOT NULL,
  PRIMARY KEY (`ld_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_bookmark`
--

LOCK TABLES `ld_bookmark` WRITE;
/*!40000 ALTER TABLE `ld_bookmark` DISABLE KEYS */;
/*!40000 ALTER TABLE `ld_bookmark` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_contact`
--

DROP TABLE IF EXISTS `ld_contact`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_contact` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_userid` bigint(20) DEFAULT NULL,
  `ld_firstname` varchar(255) DEFAULT NULL,
  `ld_lastname` varchar(255) DEFAULT NULL,
  `ld_email` varchar(512) DEFAULT NULL,
  `ld_company` varchar(255) DEFAULT NULL,
  `ld_address` varchar(512) DEFAULT NULL,
  `ld_phone` varchar(255) DEFAULT NULL,
  `ld_mobile` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ld_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_contact`
--

LOCK TABLES `ld_contact` WRITE;
/*!40000 ALTER TABLE `ld_contact` DISABLE KEYS */;
/*!40000 ALTER TABLE `ld_contact` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_dashlet`
--

DROP TABLE IF EXISTS `ld_dashlet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_dashlet` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_name` varchar(255) DEFAULT NULL,
  `ld_title` varchar(255) DEFAULT NULL,
  `ld_type` varchar(255) DEFAULT NULL,
  `ld_query` varchar(4000) DEFAULT NULL,
  `ld_content` varchar(4000) DEFAULT NULL,
  `ld_max` int(11) DEFAULT NULL,
  `ld_columns` varchar(1000) DEFAULT NULL,
  `ld_unique` int(11) NOT NULL,
  PRIMARY KEY (`ld_id`),
  UNIQUE KEY `AK_DASHLET` (`ld_name`,`ld_tenantid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_dashlet`
--

LOCK TABLES `ld_dashlet` WRITE;
/*!40000 ALTER TABLE `ld_dashlet` DISABLE KEYS */;
INSERT INTO `ld_dashlet` VALUES
(1,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'checkout','event.checkedoutdocs','document','from Document where lockUserId=$user.id and status=1 order by date desc',NULL,10,NULL,0),
(2,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'checkin','event.checkedindocs','docevent','from DocumentHistory where userId=$user.id and event=\'event.checkedin\' order by date desc',NULL,10,NULL,0),
(3,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'locked','event.lockeddocs','document','from Document where lockUserId=$user.id and status=2 order by date desc',NULL,10,NULL,0),
(4,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'download','event.downloadeddocs','docevent','from DocumentHistory where userId=$user.id and event=\'event.downloaded\' order by date desc',NULL,10,NULL,0),
(5,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'change','event.changeddocs','docevent','from DocumentHistory where userId=$user.id and event=\'event.changed\' order by date desc',NULL,10,NULL,0),
(6,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'notes','lastnotes','note','from DocumentNote where userId=$user.id order by date desc',NULL,10,NULL,0),
(7,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'tagcloud','tagcloud','content',NULL,NULL,10,NULL,0),
(8,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'lastaccessed','lastaccesseddocuments','docevent','from DocumentHistory where userId=$user.id and event in(\'event.stored\',\'event.changed\',\'event.downloaded\',\'event.checkedin\',\'event.checkedout\',\r\n\'event.renamed\',\'event.moved\',\'event.locked\',\'event.unlocked\',\'event.workflowstatus\',\'event.viewed\',\'event.restored\',\'event.exported\',\r\n\'event.exportpdf\',\'event.password.protected\',\'event.password.unprotected\',\'event.form.submitted\',\'event.form.edited\',\'event.copyed\') \r\nand date >= dateadd(day, -10, current_date) \r\norder by date desc',NULL,10,NULL,1),
(9,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'bookmark','bookmarks','bookmark','',NULL,10,NULL,0);
/*!40000 ALTER TABLE `ld_dashlet` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_device`
--

DROP TABLE IF EXISTS `ld_device`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_device` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_userid` bigint(20) DEFAULT NULL,
  `ld_deviceid` varchar(255) NOT NULL,
  `ld_username` varchar(255) DEFAULT NULL,
  `ld_browser` varchar(255) DEFAULT NULL,
  `ld_browserversion` varchar(255) DEFAULT NULL,
  `ld_operativesystem` varchar(255) DEFAULT NULL,
  `ld_type` varchar(255) DEFAULT NULL,
  `ld_ip` varchar(255) DEFAULT NULL,
  `ld_trusted` int(11) DEFAULT NULL,
  `ld_lastlogin` datetime DEFAULT NULL,
  `ld_label` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ld_id`),
  UNIQUE KEY `AK_DEVICE` (`ld_deviceid`),
  KEY `LD_DEV_USERID` (`ld_userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_device`
--

LOCK TABLES `ld_device` WRITE;
/*!40000 ALTER TABLE `ld_device` DISABLE KEYS */;
INSERT INTO `ld_device` VALUES
(4951,'2026-11-20 02:00:50',1,0,1,'2026-11-20 02:00:43',1,'602ee439-d38c-46c6-b19b-4d9745eeec41','Admin Admin','Downloading Tool',NULL,'Unknown','UNKNOWN','127.0.0.1',0,'2026-11-20 02:00:50',NULL),
(4952,'2026-11-20 02:00:43',0,0,1,'2026-11-20 02:00:43',4952,'bb88aa0a-a198-4030-a113-27a69009cd90','User Api','Downloading Tool',NULL,'Unknown','UNKNOWN','127.0.0.1',0,'2026-11-20 02:00:43',NULL);
/*!40000 ALTER TABLE `ld_device` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_document`
--

DROP TABLE IF EXISTS `ld_document`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_document` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_immutable` int(11) NOT NULL,
  `ld_customid` varchar(200) DEFAULT NULL,
  `ld_version` varchar(10) DEFAULT NULL,
  `ld_fileversion` varchar(10) DEFAULT NULL,
  `ld_revision` varchar(255) DEFAULT NULL,
  `ld_date` datetime DEFAULT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_publisher` varchar(255) DEFAULT NULL,
  `ld_publisherid` bigint(20) NOT NULL,
  `ld_creator` varchar(255) DEFAULT NULL,
  `ld_creatorid` bigint(20) NOT NULL,
  `ld_status` int(11) DEFAULT NULL,
  `ld_type` varchar(255) DEFAULT NULL,
  `ld_lockuserid` bigint(20) DEFAULT NULL,
  `ld_lockuser` varchar(255) DEFAULT NULL,
  `ld_language` varchar(10) DEFAULT NULL,
  `ld_filename` varchar(255) DEFAULT NULL,
  `ld_password` varchar(255) DEFAULT NULL,
  `ld_filesize` bigint(20) DEFAULT NULL,
  `ld_indexed` int(11) NOT NULL DEFAULT 0,
  `ld_embedded` int(11) NOT NULL DEFAULT 0,
  `ld_signed` int(11) NOT NULL,
  `ld_stamped` int(11) NOT NULL,
  `ld_digest` varchar(255) DEFAULT NULL,
  `ld_folderid` bigint(20) DEFAULT NULL,
  `ld_templateid` bigint(20) DEFAULT NULL,
  `ld_exportstatus` int(11) NOT NULL,
  `ld_exportid` bigint(20) DEFAULT NULL,
  `ld_exportname` varchar(255) DEFAULT NULL,
  `ld_exportversion` varchar(10) DEFAULT NULL,
  `ld_docref` bigint(20) DEFAULT NULL,
  `ld_docreftype` varchar(255) DEFAULT NULL,
  `ld_deleteuserid` bigint(20) DEFAULT NULL,
  `ld_deleteuser` varchar(255) DEFAULT NULL,
  `ld_rating` int(11) DEFAULT NULL,
  `ld_comment` varchar(1000) DEFAULT NULL,
  `ld_lastnote` varchar(4000) DEFAULT NULL,
  `ld_workflowstatus` varchar(1000) DEFAULT NULL,
  `ld_workflowstatusdisp` varchar(1000) DEFAULT NULL,
  `ld_published` int(11) NOT NULL,
  `ld_startpublishing` datetime DEFAULT NULL,
  `ld_stoppublishing` datetime DEFAULT NULL,
  `ld_transactionid` varchar(255) DEFAULT NULL,
  `ld_extresid` varchar(255) DEFAULT NULL,
  `ld_tgs` varchar(1000) DEFAULT NULL,
  `ld_pages` int(11) NOT NULL,
  `ld_previewpages` int(11) NOT NULL,
  `ld_nature` int(11) NOT NULL,
  `ld_formid` bigint(20) DEFAULT NULL,
  `ld_links` int(11) NOT NULL,
  `ld_docattrs` int(11) NOT NULL,
  `ld_color` varchar(255) DEFAULT NULL,
  `ld_fillerid` bigint(20) DEFAULT NULL,
  `ld_filled` int(11) NOT NULL DEFAULT 0,
  `ld_fillmode` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ld_id`),
  UNIQUE KEY `AK_DOCUMENT` (`ld_customid`,`ld_tenantid`),
  KEY `FK75ED9C0276C86307` (`ld_templateid`),
  KEY `LD_DOC_LUID` (`ld_lockuserid`),
  KEY `LD_DOC_FID` (`ld_folderid`),
  KEY `LD_DOC_RID` (`ld_docref`),
  KEY `LD_DOC_STATUS` (`ld_status`),
  CONSTRAINT `FK75ED9C0276C86307` FOREIGN KEY (`ld_templateid`) REFERENCES `ld_template` (`ld_id`),
  CONSTRAINT `FK75ED9C027C565C60` FOREIGN KEY (`ld_folderid`) REFERENCES `ld_folder` (`ld_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_document`
--

LOCK TABLES `ld_document` WRITE;
/*!40000 ALTER TABLE `ld_document` DISABLE KEYS */;
INSERT INTO `ld_document` VALUES
(4951,'2026-11-20 02:00:47',4,0,1,0,'1','2.0','2.0','1.0','2026-11-20 02:00:47','2026-11-20 02:00:44','User Api',4952,'User Api',4952,0,'docx',NULL,'User Api','en','Engagement letter.docx',NULL,1324,0,0,0,0,NULL,4956,4951,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Sent to the client',NULL,NULL,NULL,1,'2026-11-20 00:00:00',NULL,NULL,NULL,NULL,1,-1,0,NULL,0,0,NULL,NULL,0,0),
(4952,'2026-11-20 02:00:45',0,0,1,0,'2','1.0','1.0','1.0','2026-11-20 02:00:45','2026-11-20 02:00:45','User Api',4952,'User Api',4952,0,'docx',NULL,NULL,'en','Résumé naïf.docx',NULL,1288,0,0,0,0,NULL,4956,4951,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-11-20 00:00:00',NULL,NULL,NULL,NULL,1,-1,0,NULL,0,0,NULL,NULL,0,0),
(4953,'2026-11-20 02:00:49',1,1,1,0,'3','1.0','1.0','1.0','2026-11-20 02:00:46','2026-11-20 02:00:46','User Api',4952,'User Api',4952,0,'docx',NULL,NULL,'en','Draft to delete.docx',NULL,1313,0,0,0,0,NULL,4956,4951,0,NULL,NULL,NULL,NULL,NULL,4952,'User Api',NULL,NULL,NULL,NULL,NULL,1,'2026-11-20 00:00:00',NULL,NULL,NULL,NULL,1,-1,0,NULL,0,0,NULL,NULL,0,0),
(4954,'2026-11-20 02:00:49',0,0,1,0,'4','1.0','1.0','1.0','2026-11-20 02:00:49','2026-11-20 02:00:49','User Api',4952,'User Api',4952,0,'eml',NULL,NULL,'en','Réunion de chantier.eml',NULL,299,0,0,0,0,NULL,4956,4951,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-11-20 00:00:00',NULL,NULL,NULL,NULL,1,-1,0,NULL,0,0,NULL,NULL,0,0),
(4955,'2026-11-20 02:00:52',0,0,1,0,'5','1.0','1.0','1.0','2026-11-20 02:00:52','2026-11-20 02:00:52','User Api',4952,'User Api',4952,0,'docx',NULL,NULL,'en','Plan du dépôt.docx',NULL,1304,0,0,0,0,NULL,4961,4951,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-11-20 00:00:00',NULL,NULL,NULL,NULL,1,-1,0,NULL,0,0,NULL,NULL,0,0);
/*!40000 ALTER TABLE `ld_document` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_document_acl`
--

DROP TABLE IF EXISTS `ld_document_acl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_document_acl` (
  `ld_docid` bigint(20) NOT NULL,
  `ld_groupid` bigint(20) NOT NULL,
  `ld_read` int(11) NOT NULL,
  `ld_write` int(11) NOT NULL,
  `ld_security` int(11) NOT NULL,
  `ld_immutable` int(11) NOT NULL,
  `ld_delete` int(11) NOT NULL,
  `ld_rename` int(11) NOT NULL,
  `ld_sign` int(11) NOT NULL,
  `ld_preview` int(11) NOT NULL,
  `ld_customid` int(11) NOT NULL,
  `ld_archive` int(11) NOT NULL,
  `ld_workflow` int(11) NOT NULL,
  `ld_download` int(11) NOT NULL,
  `ld_calendar` int(11) NOT NULL,
  `ld_subscription` int(11) NOT NULL,
  `ld_print` int(11) NOT NULL,
  `ld_password` int(11) NOT NULL,
  `ld_move` int(11) NOT NULL,
  `ld_email` int(11) NOT NULL,
  `ld_automation` int(11) NOT NULL,
  `ld_readingreq` int(11) NOT NULL,
  `ld_revision` int(11) NOT NULL,
  PRIMARY KEY (`ld_docid`,`ld_groupid`),
  KEY `FK_DOCACL_GROUP` (`ld_groupid`),
  CONSTRAINT `FK_DOCACL_DOCUMENT` FOREIGN KEY (`ld_docid`) REFERENCES `ld_document` (`ld_id`) ON DELETE CASCADE,
  CONSTRAINT `FK_DOCACL_GROUP` FOREIGN KEY (`ld_groupid`) REFERENCES `ld_group` (`ld_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_document_acl`
--

LOCK TABLES `ld_document_acl` WRITE;
/*!40000 ALTER TABLE `ld_document_acl` DISABLE KEYS */;
/*!40000 ALTER TABLE `ld_document_acl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_document_ext`
--

DROP TABLE IF EXISTS `ld_document_ext`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_document_ext` (
  `ld_docid` bigint(20) NOT NULL,
  `ld_mandatory` int(11) NOT NULL,
  `ld_type` int(11) NOT NULL,
  `ld_editor` int(11) NOT NULL,
  `ld_position` int(11) NOT NULL,
  `ld_stringvalue` varchar(4000) DEFAULT NULL,
  `ld_stringvalues` varchar(4000) DEFAULT NULL,
  `ld_intvalue` bigint(20) DEFAULT NULL,
  `ld_doublevalue` double DEFAULT NULL,
  `ld_datevalue` datetime DEFAULT NULL,
  `ld_name` varchar(255) NOT NULL,
  `ld_label` varchar(255) DEFAULT NULL,
  `ld_setid` bigint(20) DEFAULT NULL,
  `ld_hidden` int(11) NOT NULL,
  `ld_readonly` int(11) NOT NULL,
  `ld_multiple` int(11) NOT NULL,
  `ld_parent` varchar(255) DEFAULT NULL,
  `ld_dependson` varchar(255) DEFAULT NULL,
  `ld_validation` varchar(1) DEFAULT NULL,
  `ld_initialization` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`ld_docid`,`ld_name`),
  KEY `LD_EXT_NAME` (`ld_name`),
  KEY `LD_EXT_TYPE` (`ld_type`),
  CONSTRAINT `FK4E0884647C693DFD` FOREIGN KEY (`ld_docid`) REFERENCES `ld_document` (`ld_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_document_ext`
--

LOCK TABLES `ld_document_ext` WRITE;
/*!40000 ALTER TABLE `ld_document_ext` DISABLE KEYS */;
INSERT INTO `ld_document_ext` VALUES
(4951,0,4,0,2,'apiuser',NULL,4952,NULL,NULL,'author','Author',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4951,0,0,0,0,'1',NULL,NULL,NULL,NULL,'client','Client',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4951,0,0,0,6,NULL,NULL,NULL,NULL,NULL,'comments','Comments',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4951,1,0,1,4,'Docs',NULL,NULL,NULL,NULL,'docclass','Class',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4951,0,0,1,5,NULL,NULL,NULL,NULL,NULL,'docsubclass','Subclass',4951,0,0,0,NULL,'docclass',NULL,NULL),
(4951,0,0,0,10,NULL,NULL,NULL,NULL,NULL,'emailcc','CC',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4951,0,0,0,8,NULL,NULL,NULL,NULL,NULL,'emailfrom','From',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4951,0,0,0,14,NULL,NULL,NULL,NULL,NULL,'emailmessageid','Message-ID',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4951,0,3,0,13,NULL,NULL,NULL,NULL,NULL,'emailreceived','Received',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4951,0,3,0,12,NULL,NULL,NULL,NULL,NULL,'emailsent','Sent',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4951,0,0,0,11,NULL,NULL,NULL,NULL,NULL,'emailsubject','Subject',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4951,0,0,0,9,NULL,NULL,NULL,NULL,NULL,'emailto','To',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4951,0,0,0,7,NULL,NULL,NULL,NULL,NULL,'legacydocnum','Legacy doc #',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4951,0,0,0,1,'1',NULL,NULL,NULL,NULL,'matter','Matter',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4951,0,4,0,3,'apiuser',NULL,4952,NULL,NULL,'typist','Typist',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4952,0,4,0,2,'apiuser',NULL,4952,NULL,NULL,'author','Author',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4952,0,0,0,0,'1',NULL,NULL,NULL,NULL,'client','Client',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4952,0,0,0,6,NULL,NULL,NULL,NULL,NULL,'comments','Comments',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4952,1,0,1,4,'Docs',NULL,NULL,NULL,NULL,'docclass','Class',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4952,0,0,1,5,NULL,NULL,NULL,NULL,NULL,'docsubclass','Subclass',4951,0,0,0,NULL,'docclass',NULL,NULL),
(4952,0,0,0,10,NULL,NULL,NULL,NULL,NULL,'emailcc','CC',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4952,0,0,0,8,NULL,NULL,NULL,NULL,NULL,'emailfrom','From',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4952,0,0,0,14,NULL,NULL,NULL,NULL,NULL,'emailmessageid','Message-ID',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4952,0,3,0,13,NULL,NULL,NULL,NULL,NULL,'emailreceived','Received',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4952,0,3,0,12,NULL,NULL,NULL,NULL,NULL,'emailsent','Sent',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4952,0,0,0,11,NULL,NULL,NULL,NULL,NULL,'emailsubject','Subject',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4952,0,0,0,9,NULL,NULL,NULL,NULL,NULL,'emailto','To',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4952,0,0,0,7,NULL,NULL,NULL,NULL,NULL,'legacydocnum','Legacy doc #',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4952,0,0,0,1,'1',NULL,NULL,NULL,NULL,'matter','Matter',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4952,0,4,0,3,'apiuser',NULL,4952,NULL,NULL,'typist','Typist',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,4,0,2,'apiuser',NULL,4952,NULL,NULL,'author','Author',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,0,0,0,'1',NULL,NULL,NULL,NULL,'client','Client',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,0,0,6,NULL,NULL,NULL,NULL,NULL,'comments','Comments',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,1,0,1,4,'Docs',NULL,NULL,NULL,NULL,'docclass','Class',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,0,1,5,NULL,NULL,NULL,NULL,NULL,'docsubclass','Subclass',4951,0,0,0,NULL,'docclass',NULL,NULL),
(4953,0,0,0,10,NULL,NULL,NULL,NULL,NULL,'emailcc','CC',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,0,0,8,NULL,NULL,NULL,NULL,NULL,'emailfrom','From',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,0,0,14,NULL,NULL,NULL,NULL,NULL,'emailmessageid','Message-ID',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,3,0,13,NULL,NULL,NULL,NULL,NULL,'emailreceived','Received',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,3,0,12,NULL,NULL,NULL,NULL,NULL,'emailsent','Sent',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,0,0,11,NULL,NULL,NULL,NULL,NULL,'emailsubject','Subject',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,0,0,9,NULL,NULL,NULL,NULL,NULL,'emailto','To',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,0,0,7,NULL,NULL,NULL,NULL,NULL,'legacydocnum','Legacy doc #',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,0,0,1,'1',NULL,NULL,NULL,NULL,'matter','Matter',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,4,0,3,'apiuser',NULL,4952,NULL,NULL,'typist','Typist',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,4,0,2,'apiuser',NULL,4952,NULL,NULL,'author','Author',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,0,0,0,'1',NULL,NULL,NULL,NULL,'client','Client',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,0,0,6,NULL,NULL,NULL,NULL,NULL,'comments','Comments',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,1,0,1,4,'Docs',NULL,NULL,NULL,NULL,'docclass','Class',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,0,1,5,NULL,NULL,NULL,NULL,NULL,'docsubclass','Subclass',4951,0,0,0,NULL,'docclass',NULL,NULL),
(4954,0,5,0,10,NULL,NULL,NULL,NULL,NULL,'emailcc','CC',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,0,0,8,'Ann Example <ann@example.com>',NULL,NULL,NULL,NULL,'emailfrom','From',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,0,0,14,'move-fixture-1@example.com',NULL,NULL,NULL,NULL,'emailmessageid','Message-ID',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,5,0,13,NULL,NULL,NULL,NULL,NULL,'emailreceived','Received',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,3,0,12,NULL,NULL,NULL,NULL,'2026-11-19 09:30:00','emailsent','Sent',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,0,0,11,'Réunion de chantier',NULL,NULL,NULL,NULL,'emailsubject','Subject',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,0,0,9,'Bob Example <bob@example.com>',NULL,NULL,NULL,NULL,'emailto','To',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,0,0,7,NULL,NULL,NULL,NULL,NULL,'legacydocnum','Legacy doc #',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,0,0,1,'1',NULL,NULL,NULL,NULL,'matter','Matter',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,4,0,3,'apiuser',NULL,4952,NULL,NULL,'typist','Typist',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,4,0,2,'apiuser',NULL,4952,NULL,NULL,'author','Author',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,0,0,0,'1',NULL,NULL,NULL,NULL,'client','Client',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,0,0,6,NULL,NULL,NULL,NULL,NULL,'comments','Comments',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,1,0,1,4,'Docs',NULL,NULL,NULL,NULL,'docclass','Class',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,0,1,5,NULL,NULL,NULL,NULL,NULL,'docsubclass','Subclass',4951,0,0,0,NULL,'docclass',NULL,NULL),
(4955,0,0,0,10,NULL,NULL,NULL,NULL,NULL,'emailcc','CC',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,0,0,8,NULL,NULL,NULL,NULL,NULL,'emailfrom','From',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,0,0,14,NULL,NULL,NULL,NULL,NULL,'emailmessageid','Message-ID',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,3,0,13,NULL,NULL,NULL,NULL,NULL,'emailreceived','Received',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,3,0,12,NULL,NULL,NULL,NULL,NULL,'emailsent','Sent',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,0,0,11,NULL,NULL,NULL,NULL,NULL,'emailsubject','Subject',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,0,0,9,NULL,NULL,NULL,NULL,NULL,'emailto','To',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,0,0,7,NULL,NULL,NULL,NULL,NULL,'legacydocnum','Legacy doc #',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,0,0,1,'5',NULL,NULL,NULL,NULL,'matter','Matter',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,4,0,3,'apiuser',NULL,4952,NULL,NULL,'typist','Typist',NULL,0,0,0,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `ld_document_ext` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_extoption`
--

DROP TABLE IF EXISTS `ld_extoption`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_extoption` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_setid` bigint(20) NOT NULL,
  `ld_attribute` varchar(255) NOT NULL,
  `ld_value` varchar(255) NOT NULL,
  `ld_label` varchar(1000) DEFAULT NULL,
  `ld_position` int(11) NOT NULL,
  `ld_category` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ld_id`),
  UNIQUE KEY `AK_EXTOPTION` (`ld_setid`,`ld_attribute`,`ld_value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_extoption`
--

LOCK TABLES `ld_extoption` WRITE;
/*!40000 ALTER TABLE `ld_extoption` DISABLE KEYS */;
INSERT INTO `ld_extoption` VALUES
(4951,'2026-11-20 02:00:38','2026-11-20 02:00:38',0,0,1,4951,'docclass','Docs',NULL,0,NULL);
/*!40000 ALTER TABLE `ld_extoption` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_filler`
--

DROP TABLE IF EXISTS `ld_filler`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_filler` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_name` varchar(255) NOT NULL,
  `ld_title` varchar(255) DEFAULT NULL,
  `ld_label` varchar(255) DEFAULT NULL,
  `ld_description` varchar(4000) DEFAULT NULL,
  `ld_type` varchar(50) NOT NULL,
  `ld_modelid` bigint(20) DEFAULT NULL,
  `ld_embeddingschemeid` bigint(20) DEFAULT NULL,
  `ld_threshold` double DEFAULT NULL,
  `ld_checkin` int(11) NOT NULL,
  `ld_overwrite` int(11) NOT NULL,
  `ld_automation` mediumtext DEFAULT NULL,
  `ld_attribute` varchar(255) DEFAULT NULL,
  `ld_candidate` varchar(255) DEFAULT NULL,
  `ld_format` varchar(1000) DEFAULT NULL,
  `ld_dsep` varchar(2) DEFAULT NULL,
  `ld_gsep` varchar(2) DEFAULT NULL,
  `ld_automationbefore` mediumtext DEFAULT NULL,
  `ld_regexcl` varchar(1000) DEFAULT NULL,
  `ld_regincl` varchar(1000) DEFAULT NULL,
  `ld_templateid` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ld_id`),
  UNIQUE KEY `AK_FILLER` (`ld_name`,`ld_tenantid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_filler`
--

LOCK TABLES `ld_filler` WRITE;
/*!40000 ALTER TABLE `ld_filler` DISABLE KEYS */;
/*!40000 ALTER TABLE `ld_filler` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_filler_chain`
--

DROP TABLE IF EXISTS `ld_filler_chain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_filler_chain` (
  `ld_fillerid` bigint(20) NOT NULL,
  `ld_chainedid` bigint(20) NOT NULL,
  `ld_position` int(11) NOT NULL,
  PRIMARY KEY (`ld_fillerid`,`ld_chainedid`),
  KEY `FK_FILLERCHAIN_CHAINED` (`ld_chainedid`),
  CONSTRAINT `FK_FILLERCHAIN_CHAINED` FOREIGN KEY (`ld_chainedid`) REFERENCES `ld_filler` (`ld_id`) ON DELETE CASCADE,
  CONSTRAINT `FK_FILLERCHAIN_FILLER` FOREIGN KEY (`ld_fillerid`) REFERENCES `ld_filler` (`ld_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_filler_chain`
--

LOCK TABLES `ld_filler_chain` WRITE;
/*!40000 ALTER TABLE `ld_filler_chain` DISABLE KEYS */;
/*!40000 ALTER TABLE `ld_filler_chain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_folder`
--

DROP TABLE IF EXISTS `ld_folder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_folder` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_name` varchar(255) DEFAULT NULL,
  `ld_parentid` bigint(20) NOT NULL,
  `ld_securityref` bigint(20) DEFAULT NULL,
  `ld_description` varchar(4000) DEFAULT NULL,
  `ld_type` int(11) NOT NULL,
  `ld_creation` datetime DEFAULT NULL,
  `ld_creator` varchar(255) DEFAULT NULL,
  `ld_creatorid` bigint(20) DEFAULT NULL,
  `ld_templateid` bigint(20) DEFAULT NULL,
  `ld_templocked` int(11) NOT NULL,
  `ld_deleteuserid` bigint(20) DEFAULT NULL,
  `ld_deleteuser` varchar(255) DEFAULT NULL,
  `ld_position` int(11) NOT NULL,
  `ld_documentsquota` bigint(20) DEFAULT NULL,
  `ld_storagequota` bigint(20) DEFAULT NULL,
  `ld_hidden` int(11) NOT NULL,
  `ld_foldref` bigint(20) DEFAULT NULL,
  `ld_level` int(11) DEFAULT NULL,
  `ld_versionsquota` bigint(20) DEFAULT NULL,
  `ld_color` varchar(255) DEFAULT NULL,
  `ld_tgs` varchar(1000) DEFAULT NULL,
  `ld_qthreshold` int(11) DEFAULT NULL,
  `ld_qrecipients` varchar(1000) DEFAULT NULL,
  `ld_path` varchar(255) DEFAULT NULL,
  `ld_grid` varchar(4000) DEFAULT NULL,
  `ld_tile` mediumtext DEFAULT NULL,
  `ld_fillerid` bigint(20) DEFAULT NULL,
  `ld_fillmode` int(11) NOT NULL DEFAULT 0,
  `ld_pagesquota` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ld_id`),
  KEY `FK_FOLDER_PARENT` (`ld_parentid`),
  KEY `FK_FOLDER_TEMPLATE` (`ld_templateid`),
  KEY `LD_FLD_NAME` (`ld_name`),
  KEY `LD_FLD_PATH` (`ld_path`),
  KEY `LD_FLD_FOLDREF` (`ld_foldref`),
  CONSTRAINT `FK_FOLDER_PARENT` FOREIGN KEY (`ld_parentid`) REFERENCES `ld_folder` (`ld_id`),
  CONSTRAINT `FK_FOLDER_TEMPLATE` FOREIGN KEY (`ld_templateid`) REFERENCES `ld_template` (`ld_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_folder`
--

LOCK TABLES `ld_folder` WRITE;
/*!40000 ALTER TABLE `ld_folder` DISABLE KEYS */;
INSERT INTO `ld_folder` VALUES
(4,'2026-11-20 02:00:28',1,0,1,'Default',5,NULL,NULL,1,'2026-11-20 02:00:28',NULL,NULL,NULL,0,NULL,NULL,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'/4',NULL,NULL,NULL,0,NULL),
(5,'2026-11-20 02:00:28',1,0,1,'/',5,NULL,NULL,1,'2026-11-20 02:00:28',NULL,NULL,NULL,0,NULL,NULL,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'/',NULL,NULL,NULL,0,NULL),
(4951,'2026-11-20 02:00:38',1,0,1,'Templates',5,NULL,'',1,'2026-11-20 02:00:38','System',0,NULL,0,NULL,NULL,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'/4951',NULL,NULL,NULL,0,NULL),
(4952,'2026-11-20 02:00:38',2,0,1,'Smoke',5,NULL,'',1,'2026-11-20 02:00:38','System',0,NULL,0,NULL,NULL,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'/4952',NULL,NULL,NULL,0,NULL),
(4953,'2026-11-20 02:00:39',3,0,1,'Smoke template',4951,NULL,'',0,'2026-11-20 02:00:38','System',0,4951,1,NULL,NULL,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'/4951/4953',NULL,NULL,NULL,0,NULL),
(4954,'2026-11-20 02:00:38',1,0,1,'Documents',4953,4953,'',0,'2026-11-20 02:00:38','System',0,4951,1,NULL,NULL,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'/4951/4953/4954',NULL,NULL,NULL,0,NULL),
(4955,'2026-11-20 02:00:39',4,0,1,'1.1 – Smoke Matter',4952,NULL,NULL,0,'2026-11-20 02:00:39','Admin Admin',1,4951,1,NULL,NULL,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'/4952/4955',NULL,NULL,NULL,0,NULL),
(4956,'2026-11-20 02:00:39',1,0,1,'Documents',4955,4955,'',0,'2026-11-20 02:00:39','Admin Admin',1,4951,1,NULL,NULL,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'/4952/4955/4956',NULL,NULL,NULL,0,NULL),
(4957,'2026-11-20 02:00:39',3,0,1,'1.4 – Second Matter',4952,NULL,NULL,0,'2026-11-20 02:00:39','Admin Admin',1,4951,1,NULL,NULL,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'/4952/4957',NULL,NULL,NULL,0,NULL),
(4958,'2026-11-20 02:00:39',1,0,1,'Documents',4957,4957,'',0,'2026-11-20 02:00:39','Admin Admin',1,4951,1,NULL,NULL,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'/4952/4957/4958',NULL,NULL,NULL,0,NULL),
(4959,'2026-11-20 02:00:50',2,0,1,'Dépôt Local',5,NULL,'',1,'2026-11-20 02:00:50','Admin Admin',1,NULL,0,NULL,NULL,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'/4959',NULL,NULL,NULL,0,NULL),
(4960,'2026-11-20 02:00:51',3,0,1,'1.5 – Dépôt Müller',4959,NULL,NULL,0,'2026-11-20 02:00:51','Admin Admin',1,4951,1,NULL,NULL,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'/4959/4960',NULL,NULL,NULL,0,NULL),
(4961,'2026-11-20 02:00:51',1,0,1,'Documents',4960,4960,'',0,'2026-11-20 02:00:51','Admin Admin',1,4951,1,NULL,NULL,1,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'/4959/4960/4961',NULL,NULL,NULL,0,NULL);
/*!40000 ALTER TABLE `ld_folder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_folder_acl`
--

DROP TABLE IF EXISTS `ld_folder_acl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_folder_acl` (
  `ld_folderid` bigint(20) NOT NULL,
  `ld_groupid` bigint(20) NOT NULL,
  `ld_read` int(11) NOT NULL,
  `ld_write` int(11) NOT NULL,
  `ld_add` int(11) NOT NULL,
  `ld_security` int(11) NOT NULL,
  `ld_immutable` int(11) NOT NULL,
  `ld_delete` int(11) NOT NULL,
  `ld_rename` int(11) NOT NULL,
  `ld_import` int(11) NOT NULL,
  `ld_export` int(11) NOT NULL,
  `ld_sign` int(11) NOT NULL,
  `ld_archive` int(11) NOT NULL,
  `ld_workflow` int(11) NOT NULL,
  `ld_download` int(11) NOT NULL,
  `ld_calendar` int(11) NOT NULL,
  `ld_subscription` int(11) NOT NULL,
  `ld_print` int(11) NOT NULL,
  `ld_password` int(11) NOT NULL,
  `ld_move` int(11) NOT NULL,
  `ld_email` int(11) NOT NULL,
  `ld_automation` int(11) NOT NULL,
  `ld_store` int(11) NOT NULL,
  `ld_readingreq` int(11) NOT NULL,
  `ld_preview` int(11) NOT NULL,
  `ld_customid` int(11) NOT NULL,
  `ld_revision` int(11) NOT NULL,
  PRIMARY KEY (`ld_folderid`,`ld_groupid`),
  KEY `FK_FOLDACL_GROUP` (`ld_groupid`),
  CONSTRAINT `FK_FOLDACL_FOLDER` FOREIGN KEY (`ld_folderid`) REFERENCES `ld_folder` (`ld_id`) ON DELETE CASCADE,
  CONSTRAINT `FK_FOLDACL_GROUP` FOREIGN KEY (`ld_groupid`) REFERENCES `ld_group` (`ld_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_folder_acl`
--

LOCK TABLES `ld_folder_acl` WRITE;
/*!40000 ALTER TABLE `ld_folder_acl` DISABLE KEYS */;
INSERT INTO `ld_folder_acl` VALUES
(4,-10000,1,1,1,0,0,1,1,0,0,0,0,0,1,1,0,1,0,1,1,0,0,1,1,1,0),
(4,2,1,1,1,0,0,1,1,0,0,0,0,0,1,1,0,1,0,1,1,0,0,1,1,1,1),
(4,3,1,0,0,0,0,0,0,0,0,0,0,0,1,1,0,1,0,1,1,0,0,0,1,0,0),
(4,4,1,1,1,0,0,1,1,0,0,0,0,0,1,1,0,1,0,1,1,0,0,1,1,1,1),
(5,-10000,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,1,1,1),
(5,2,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,1,0,0),
(5,3,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,1,0,0),
(5,4,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,1,0,0),
(4952,4951,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
(4953,4951,1,1,1,0,0,1,1,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0),
(4955,-1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1),
(4955,4951,1,1,1,0,0,1,1,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0),
(4957,-1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1),
(4957,4951,1,1,1,0,0,1,1,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0),
(4959,4951,1,0,0,0,0,0,0,0,0,0,0,0,1,0,0,1,0,0,1,0,0,0,1,0,0),
(4960,-1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1),
(4960,4951,1,1,1,0,0,1,1,0,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1,0,0);
/*!40000 ALTER TABLE `ld_folder_acl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_folder_ext`
--

DROP TABLE IF EXISTS `ld_folder_ext`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_folder_ext` (
  `ld_folderid` bigint(20) NOT NULL,
  `ld_mandatory` int(11) NOT NULL,
  `ld_type` int(11) NOT NULL,
  `ld_editor` int(11) NOT NULL,
  `ld_position` int(11) NOT NULL,
  `ld_stringvalue` varchar(4000) DEFAULT NULL,
  `ld_stringvalues` varchar(4000) DEFAULT NULL,
  `ld_intvalue` bigint(20) DEFAULT NULL,
  `ld_doublevalue` double DEFAULT NULL,
  `ld_datevalue` datetime DEFAULT NULL,
  `ld_name` varchar(255) NOT NULL,
  `ld_label` varchar(255) DEFAULT NULL,
  `ld_setid` bigint(20) DEFAULT NULL,
  `ld_hidden` int(11) NOT NULL,
  `ld_readonly` int(11) NOT NULL,
  `ld_multiple` int(11) NOT NULL,
  `ld_parent` varchar(255) DEFAULT NULL,
  `ld_dependson` varchar(255) DEFAULT NULL,
  `ld_validation` varchar(1) DEFAULT NULL,
  `ld_initialization` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`ld_folderid`,`ld_name`),
  CONSTRAINT `FK_FOLDEREXT_FOLDER` FOREIGN KEY (`ld_folderid`) REFERENCES `ld_folder` (`ld_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_folder_ext`
--

LOCK TABLES `ld_folder_ext` WRITE;
/*!40000 ALTER TABLE `ld_folder_ext` DISABLE KEYS */;
INSERT INTO `ld_folder_ext` VALUES
(4953,0,4,0,2,NULL,NULL,NULL,NULL,NULL,'author','Author',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,0,0,0,NULL,NULL,NULL,NULL,NULL,'client','Client',NULL,0,1,0,NULL,NULL,NULL,NULL),
(4953,0,0,0,6,NULL,NULL,NULL,NULL,NULL,'comments','Comments',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,1,0,1,4,'Docs',NULL,NULL,NULL,NULL,'docclass','Class',4951,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,0,1,5,NULL,NULL,NULL,NULL,NULL,'docsubclass','Subclass',4951,0,0,0,NULL,'docclass',NULL,NULL),
(4953,0,0,0,10,NULL,NULL,NULL,NULL,NULL,'emailcc','CC',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,0,0,8,NULL,NULL,NULL,NULL,NULL,'emailfrom','From',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,0,0,14,NULL,NULL,NULL,NULL,NULL,'emailmessageid','Message-ID',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,3,0,13,NULL,NULL,NULL,NULL,NULL,'emailreceived','Received',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,3,0,12,NULL,NULL,NULL,NULL,NULL,'emailsent','Sent',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,0,0,11,NULL,NULL,NULL,NULL,NULL,'emailsubject','Subject',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,0,0,9,NULL,NULL,NULL,NULL,NULL,'emailto','To',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,0,0,7,NULL,NULL,NULL,NULL,NULL,'legacydocnum','Legacy doc #',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,0,0,1,NULL,NULL,NULL,NULL,NULL,'matter','Matter',NULL,0,1,0,NULL,NULL,NULL,NULL),
(4953,0,4,0,3,NULL,NULL,NULL,NULL,NULL,'typist','Typist',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,4,0,2,NULL,NULL,NULL,NULL,NULL,'author','Author',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,0,0,0,NULL,NULL,NULL,NULL,NULL,'client','Client',NULL,0,1,0,NULL,NULL,NULL,NULL),
(4954,0,0,0,6,NULL,NULL,NULL,NULL,NULL,'comments','Comments',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,1,0,1,4,'Docs',NULL,NULL,NULL,NULL,'docclass','Class',4951,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,0,1,5,NULL,NULL,NULL,NULL,NULL,'docsubclass','Subclass',4951,0,0,0,NULL,'docclass',NULL,NULL),
(4954,0,0,0,10,NULL,NULL,NULL,NULL,NULL,'emailcc','CC',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,0,0,8,NULL,NULL,NULL,NULL,NULL,'emailfrom','From',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,0,0,14,NULL,NULL,NULL,NULL,NULL,'emailmessageid','Message-ID',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,3,0,13,NULL,NULL,NULL,NULL,NULL,'emailreceived','Received',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,3,0,12,NULL,NULL,NULL,NULL,NULL,'emailsent','Sent',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,0,0,11,NULL,NULL,NULL,NULL,NULL,'emailsubject','Subject',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,0,0,9,NULL,NULL,NULL,NULL,NULL,'emailto','To',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,0,0,7,NULL,NULL,NULL,NULL,NULL,'legacydocnum','Legacy doc #',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,0,0,1,NULL,NULL,NULL,NULL,NULL,'matter','Matter',NULL,0,1,0,NULL,NULL,NULL,NULL),
(4954,0,4,0,3,NULL,NULL,NULL,NULL,NULL,'typist','Typist',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,4,0,2,NULL,NULL,NULL,NULL,NULL,'author','Author',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,0,0,0,'1',NULL,NULL,NULL,NULL,'client','Client',NULL,0,1,0,NULL,NULL,NULL,NULL),
(4955,0,0,0,6,NULL,NULL,NULL,NULL,NULL,'comments','Comments',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,1,0,1,4,'Docs',NULL,NULL,NULL,NULL,'docclass','Class',4951,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,0,1,5,NULL,NULL,NULL,NULL,NULL,'docsubclass','Subclass',4951,0,0,0,NULL,'docclass',NULL,NULL),
(4955,0,0,0,10,NULL,NULL,NULL,NULL,NULL,'emailcc','CC',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,0,0,8,NULL,NULL,NULL,NULL,NULL,'emailfrom','From',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,0,0,14,NULL,NULL,NULL,NULL,NULL,'emailmessageid','Message-ID',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,3,0,13,NULL,NULL,NULL,NULL,NULL,'emailreceived','Received',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,3,0,12,NULL,NULL,NULL,NULL,NULL,'emailsent','Sent',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,0,0,11,NULL,NULL,NULL,NULL,NULL,'emailsubject','Subject',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,0,0,9,NULL,NULL,NULL,NULL,NULL,'emailto','To',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,0,0,7,NULL,NULL,NULL,NULL,NULL,'legacydocnum','Legacy doc #',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,0,0,1,'1',NULL,NULL,NULL,NULL,'matter','Matter',NULL,0,1,0,NULL,NULL,NULL,NULL),
(4955,0,4,0,3,NULL,NULL,NULL,NULL,NULL,'typist','Typist',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4956,0,4,0,2,NULL,NULL,NULL,NULL,NULL,'author','Author',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4956,0,0,0,0,'1',NULL,NULL,NULL,NULL,'client','Client',NULL,0,1,0,NULL,NULL,NULL,NULL),
(4956,0,0,0,6,NULL,NULL,NULL,NULL,NULL,'comments','Comments',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4956,1,0,1,4,'Docs',NULL,NULL,NULL,NULL,'docclass','Class',4951,0,0,0,NULL,NULL,NULL,NULL),
(4956,0,0,1,5,NULL,NULL,NULL,NULL,NULL,'docsubclass','Subclass',4951,0,0,0,NULL,'docclass',NULL,NULL),
(4956,0,0,0,10,NULL,NULL,NULL,NULL,NULL,'emailcc','CC',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4956,0,0,0,8,NULL,NULL,NULL,NULL,NULL,'emailfrom','From',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4956,0,0,0,14,NULL,NULL,NULL,NULL,NULL,'emailmessageid','Message-ID',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4956,0,3,0,13,NULL,NULL,NULL,NULL,NULL,'emailreceived','Received',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4956,0,3,0,12,NULL,NULL,NULL,NULL,NULL,'emailsent','Sent',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4956,0,0,0,11,NULL,NULL,NULL,NULL,NULL,'emailsubject','Subject',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4956,0,0,0,9,NULL,NULL,NULL,NULL,NULL,'emailto','To',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4956,0,0,0,7,NULL,NULL,NULL,NULL,NULL,'legacydocnum','Legacy doc #',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4956,0,0,0,1,'1',NULL,NULL,NULL,NULL,'matter','Matter',NULL,0,1,0,NULL,NULL,NULL,NULL),
(4956,0,4,0,3,NULL,NULL,NULL,NULL,NULL,'typist','Typist',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4957,0,4,0,2,NULL,NULL,NULL,NULL,NULL,'author','Author',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4957,0,0,0,0,'1',NULL,NULL,NULL,NULL,'client','Client',NULL,0,1,0,NULL,NULL,NULL,NULL),
(4957,0,0,0,6,NULL,NULL,NULL,NULL,NULL,'comments','Comments',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4957,1,0,1,4,'Docs',NULL,NULL,NULL,NULL,'docclass','Class',4951,0,0,0,NULL,NULL,NULL,NULL),
(4957,0,0,1,5,NULL,NULL,NULL,NULL,NULL,'docsubclass','Subclass',4951,0,0,0,NULL,'docclass',NULL,NULL),
(4957,0,0,0,10,NULL,NULL,NULL,NULL,NULL,'emailcc','CC',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4957,0,0,0,8,NULL,NULL,NULL,NULL,NULL,'emailfrom','From',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4957,0,0,0,14,NULL,NULL,NULL,NULL,NULL,'emailmessageid','Message-ID',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4957,0,3,0,13,NULL,NULL,NULL,NULL,NULL,'emailreceived','Received',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4957,0,3,0,12,NULL,NULL,NULL,NULL,NULL,'emailsent','Sent',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4957,0,0,0,11,NULL,NULL,NULL,NULL,NULL,'emailsubject','Subject',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4957,0,0,0,9,NULL,NULL,NULL,NULL,NULL,'emailto','To',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4957,0,0,0,7,NULL,NULL,NULL,NULL,NULL,'legacydocnum','Legacy doc #',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4957,0,0,0,1,'4',NULL,NULL,NULL,NULL,'matter','Matter',NULL,0,1,0,NULL,NULL,NULL,NULL),
(4957,0,4,0,3,NULL,NULL,NULL,NULL,NULL,'typist','Typist',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4958,0,4,0,2,NULL,NULL,NULL,NULL,NULL,'author','Author',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4958,0,0,0,0,'1',NULL,NULL,NULL,NULL,'client','Client',NULL,0,1,0,NULL,NULL,NULL,NULL),
(4958,0,0,0,6,NULL,NULL,NULL,NULL,NULL,'comments','Comments',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4958,1,0,1,4,'Docs',NULL,NULL,NULL,NULL,'docclass','Class',4951,0,0,0,NULL,NULL,NULL,NULL),
(4958,0,0,1,5,NULL,NULL,NULL,NULL,NULL,'docsubclass','Subclass',4951,0,0,0,NULL,'docclass',NULL,NULL),
(4958,0,0,0,10,NULL,NULL,NULL,NULL,NULL,'emailcc','CC',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4958,0,0,0,8,NULL,NULL,NULL,NULL,NULL,'emailfrom','From',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4958,0,0,0,14,NULL,NULL,NULL,NULL,NULL,'emailmessageid','Message-ID',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4958,0,3,0,13,NULL,NULL,NULL,NULL,NULL,'emailreceived','Received',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4958,0,3,0,12,NULL,NULL,NULL,NULL,NULL,'emailsent','Sent',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4958,0,0,0,11,NULL,NULL,NULL,NULL,NULL,'emailsubject','Subject',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4958,0,0,0,9,NULL,NULL,NULL,NULL,NULL,'emailto','To',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4958,0,0,0,7,NULL,NULL,NULL,NULL,NULL,'legacydocnum','Legacy doc #',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4958,0,0,0,1,'4',NULL,NULL,NULL,NULL,'matter','Matter',NULL,0,1,0,NULL,NULL,NULL,NULL),
(4958,0,4,0,3,NULL,NULL,NULL,NULL,NULL,'typist','Typist',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4960,0,4,0,2,NULL,NULL,NULL,NULL,NULL,'author','Author',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4960,0,0,0,0,'1',NULL,NULL,NULL,NULL,'client','Client',NULL,0,1,0,NULL,NULL,NULL,NULL),
(4960,0,0,0,6,NULL,NULL,NULL,NULL,NULL,'comments','Comments',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4960,1,0,1,4,'Docs',NULL,NULL,NULL,NULL,'docclass','Class',4951,0,0,0,NULL,NULL,NULL,NULL),
(4960,0,0,1,5,NULL,NULL,NULL,NULL,NULL,'docsubclass','Subclass',4951,0,0,0,NULL,'docclass',NULL,NULL),
(4960,0,0,0,10,NULL,NULL,NULL,NULL,NULL,'emailcc','CC',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4960,0,0,0,8,NULL,NULL,NULL,NULL,NULL,'emailfrom','From',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4960,0,0,0,14,NULL,NULL,NULL,NULL,NULL,'emailmessageid','Message-ID',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4960,0,3,0,13,NULL,NULL,NULL,NULL,NULL,'emailreceived','Received',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4960,0,3,0,12,NULL,NULL,NULL,NULL,NULL,'emailsent','Sent',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4960,0,0,0,11,NULL,NULL,NULL,NULL,NULL,'emailsubject','Subject',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4960,0,0,0,9,NULL,NULL,NULL,NULL,NULL,'emailto','To',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4960,0,0,0,7,NULL,NULL,NULL,NULL,NULL,'legacydocnum','Legacy doc #',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4960,0,0,0,1,'5',NULL,NULL,NULL,NULL,'matter','Matter',NULL,0,1,0,NULL,NULL,NULL,NULL),
(4960,0,4,0,3,NULL,NULL,NULL,NULL,NULL,'typist','Typist',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4961,0,4,0,2,NULL,NULL,NULL,NULL,NULL,'author','Author',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4961,0,0,0,0,'1',NULL,NULL,NULL,NULL,'client','Client',NULL,0,1,0,NULL,NULL,NULL,NULL),
(4961,0,0,0,6,NULL,NULL,NULL,NULL,NULL,'comments','Comments',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4961,1,0,1,4,'Docs',NULL,NULL,NULL,NULL,'docclass','Class',4951,0,0,0,NULL,NULL,NULL,NULL),
(4961,0,0,1,5,NULL,NULL,NULL,NULL,NULL,'docsubclass','Subclass',4951,0,0,0,NULL,'docclass',NULL,NULL),
(4961,0,0,0,10,NULL,NULL,NULL,NULL,NULL,'emailcc','CC',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4961,0,0,0,8,NULL,NULL,NULL,NULL,NULL,'emailfrom','From',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4961,0,0,0,14,NULL,NULL,NULL,NULL,NULL,'emailmessageid','Message-ID',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4961,0,3,0,13,NULL,NULL,NULL,NULL,NULL,'emailreceived','Received',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4961,0,3,0,12,NULL,NULL,NULL,NULL,NULL,'emailsent','Sent',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4961,0,0,0,11,NULL,NULL,NULL,NULL,NULL,'emailsubject','Subject',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4961,0,0,0,9,NULL,NULL,NULL,NULL,NULL,'emailto','To',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4961,0,0,0,7,NULL,NULL,NULL,NULL,NULL,'legacydocnum','Legacy doc #',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4961,0,0,0,1,'5',NULL,NULL,NULL,NULL,'matter','Matter',NULL,0,1,0,NULL,NULL,NULL,NULL),
(4961,0,4,0,3,NULL,NULL,NULL,NULL,NULL,'typist','Typist',NULL,0,0,0,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `ld_folder_ext` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_folder_history`
--

DROP TABLE IF EXISTS `ld_folder_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_folder_history` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_docid` bigint(20) DEFAULT NULL,
  `ld_keylabel` varchar(255) DEFAULT NULL,
  `ld_folderid` bigint(20) DEFAULT NULL,
  `ld_userid` bigint(20) DEFAULT NULL,
  `ld_date` datetime(3) DEFAULT NULL,
  `ld_username` varchar(255) DEFAULT NULL,
  `ld_event` varchar(255) DEFAULT NULL,
  `ld_comment` varchar(4000) DEFAULT NULL,
  `ld_reason` varchar(4000) DEFAULT NULL,
  `ld_version` varchar(255) DEFAULT NULL,
  `ld_fileversion` varchar(10) DEFAULT NULL,
  `ld_path` varchar(4000) DEFAULT NULL,
  `ld_pathold` varchar(4000) DEFAULT NULL,
  `ld_notified` int(11) NOT NULL,
  `ld_sessionid` varchar(255) DEFAULT NULL,
  `ld_filename` varchar(255) DEFAULT NULL,
  `ld_userlogin` varchar(255) DEFAULT NULL,
  `ld_filenameold` varchar(255) DEFAULT NULL,
  `ld_revision` varchar(255) DEFAULT NULL,
  `ld_ip` varchar(255) DEFAULT NULL,
  `ld_geolocation` varchar(255) DEFAULT NULL,
  `ld_device` varchar(255) DEFAULT NULL,
  `ld_filesize` bigint(20) DEFAULT NULL,
  `ld_color` varchar(255) DEFAULT NULL,
  `ld_impersonator` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ld_id`),
  KEY `LD_FHIST_FID` (`ld_folderid`),
  KEY `LD_FHIST_NOT` (`ld_notified`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_folder_history`
--

LOCK TABLES `ld_folder_history` WRITE;
/*!40000 ALTER TABLE `ld_folder_history` DISABLE KEYS */;
INSERT INTO `ld_folder_history` VALUES
(1,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,NULL,NULL,5,1,'2026-11-20 02:00:28.000','admin','event.folder.created',NULL,NULL,'1.0',NULL,'/',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(2,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,NULL,NULL,4,1,'2026-11-20 02:00:28.000','admin','event.folder.created',NULL,NULL,'1.0',NULL,'/Default',NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4951,'2026-11-20 02:00:38','2026-11-20 02:00:38',0,0,1,NULL,'',4951,0,'2026-11-20 02:00:38.669','System','event.folder.created','Healdan first-start setup (user id -1010)',NULL,NULL,NULL,'/Templates',NULL,0,'','Templates','_system',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4952,'2026-11-20 02:00:38','2026-11-20 02:00:38',0,0,1,NULL,'',5,0,'2026-11-20 02:00:38.669','System','event.folder.subfolder.created','Healdan first-start setup (user id -1010)',NULL,NULL,NULL,'/Templates',NULL,0,'','Templates','_system',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4953,'2026-11-20 02:00:38','2026-11-20 02:00:38',0,0,1,NULL,'',4952,0,'2026-11-20 02:00:38.836','System','event.folder.created','Healdan smoke fixture (user id -1010)',NULL,NULL,NULL,'/Smoke',NULL,0,'','Smoke','_system',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4954,'2026-11-20 02:00:38','2026-11-20 02:00:38',0,0,1,NULL,'',5,0,'2026-11-20 02:00:38.836','System','event.folder.subfolder.created','Healdan smoke fixture (user id -1010)',NULL,NULL,NULL,'/Smoke',NULL,0,'','Smoke','_system',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4955,'2026-11-20 02:00:38','2026-11-20 02:00:38',0,0,1,NULL,'',4952,0,'2026-11-20 02:00:38.846','System','event.folder.permission','Healdan smoke fixture (user id -1010)',NULL,NULL,NULL,'/Smoke',NULL,0,'','Smoke','_system',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4956,'2026-11-20 02:00:38','2026-11-20 02:00:38',0,0,1,NULL,'',5,0,'2026-11-20 02:00:38.846','System','event.folder.subfolder.permission','Healdan smoke fixture (user id -1010)',NULL,NULL,NULL,'/Smoke',NULL,0,'','Smoke','_system',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4957,'2026-11-20 02:00:38','2026-11-20 02:00:38',0,0,1,NULL,'',4953,0,'2026-11-20 02:00:38.861','System','event.folder.created','Healdan smoke fixture (user id -1010)',NULL,NULL,NULL,'/Templates/Smoke template',NULL,0,'','Smoke template','_system',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4958,'2026-11-20 02:00:38','2026-11-20 02:00:38',0,0,1,NULL,'',4951,0,'2026-11-20 02:00:38.861','System','event.folder.subfolder.created','Healdan smoke fixture (user id -1010)',NULL,NULL,NULL,'/Templates/Smoke template',NULL,0,'','Smoke template','_system',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4959,'2026-11-20 02:00:38','2026-11-20 02:00:38',0,0,1,NULL,'',4953,0,'2026-11-20 02:00:38.887','System','event.folder.permission','Healdan smoke fixture (user id -1010)',NULL,NULL,NULL,'/Templates/Smoke template',NULL,0,'','Smoke template','_system',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4960,'2026-11-20 02:00:38','2026-11-20 02:00:38',0,0,1,NULL,'',4951,0,'2026-11-20 02:00:38.887','System','event.folder.subfolder.permission','Healdan smoke fixture (user id -1010)',NULL,NULL,NULL,'/Templates/Smoke template',NULL,0,'','Smoke template','_system',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4961,'2026-11-20 02:00:38','2026-11-20 02:00:38',0,0,1,NULL,'',4954,0,'2026-11-20 02:00:38.903','System','event.folder.created','Healdan smoke fixture (user id -1010)',NULL,NULL,NULL,'/Templates/Smoke template/Documents',NULL,0,'','Documents','_system',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4962,'2026-11-20 02:00:38','2026-11-20 02:00:38',0,0,1,NULL,'',4953,0,'2026-11-20 02:00:38.903','System','event.folder.subfolder.created','Healdan smoke fixture (user id -1010)',NULL,NULL,NULL,'/Templates/Smoke template/Documents',NULL,0,'','Documents','_system',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4963,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,NULL,'',4955,1,'2026-11-20 02:00:39.002','Admin Admin','event.folder.created','',NULL,NULL,NULL,'/Smoke/1.1 – Smoke Matter',NULL,0,'','1.1 – Smoke Matter','admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4964,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,NULL,'',4952,1,'2026-11-20 02:00:39.002','Admin Admin','event.folder.subfolder.created','',NULL,NULL,NULL,'/Smoke/1.1 – Smoke Matter',NULL,0,'','1.1 – Smoke Matter','admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4965,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,NULL,'',4955,1,'2026-11-20 02:00:39.002','Admin Admin','event.folder.permission','',NULL,NULL,NULL,'/Smoke/1.1 – Smoke Matter',NULL,0,'','1.1 – Smoke Matter','admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4966,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,NULL,'',4952,1,'2026-11-20 02:00:39.002','Admin Admin','event.folder.subfolder.permission','',NULL,NULL,NULL,'/Smoke/1.1 – Smoke Matter',NULL,0,'','1.1 – Smoke Matter','admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4967,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,NULL,'',4956,1,'2026-11-20 02:00:39.002','Admin Admin','event.folder.created','',NULL,NULL,NULL,'/Smoke/1.1 – Smoke Matter/Documents',NULL,0,'','Documents','admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4968,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,NULL,'',4955,1,'2026-11-20 02:00:39.002','Admin Admin','event.folder.subfolder.created','',NULL,NULL,NULL,'/Smoke/1.1 – Smoke Matter/Documents',NULL,0,'','Documents','admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4969,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,NULL,'',4955,1,'2026-11-20 02:00:39.002','Admin Admin','event.folder.permission','',NULL,NULL,NULL,'/Smoke/1.1 – Smoke Matter',NULL,0,'','1.1 – Smoke Matter','admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4970,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,NULL,'',4952,1,'2026-11-20 02:00:39.002','Admin Admin','event.folder.subfolder.permission','',NULL,NULL,NULL,'/Smoke/1.1 – Smoke Matter',NULL,0,'','1.1 – Smoke Matter','admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4971,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,NULL,'',4953,0,'2026-11-20 02:00:39.106','System','event.folder.permission','Healdan smoke fixture (user id -1010)',NULL,NULL,NULL,'/Templates/Smoke template',NULL,0,'','Smoke template','_system',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4972,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,NULL,'',4951,0,'2026-11-20 02:00:39.106','System','event.folder.subfolder.permission','Healdan smoke fixture (user id -1010)',NULL,NULL,NULL,'/Templates/Smoke template',NULL,0,'','Smoke template','_system',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4973,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,NULL,'',4955,0,'2026-11-20 02:00:39.133','System','event.folder.permission','Healdan smoke fixture (user id -1010)',NULL,NULL,NULL,'/Smoke/1.1 – Smoke Matter',NULL,0,'','1.1 – Smoke Matter','_system',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4974,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,NULL,'',4952,0,'2026-11-20 02:00:39.133','System','event.folder.subfolder.permission','Healdan smoke fixture (user id -1010)',NULL,NULL,NULL,'/Smoke/1.1 – Smoke Matter',NULL,0,'','1.1 – Smoke Matter','_system',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4975,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,NULL,'',4957,1,'2026-11-20 02:00:39.267','Admin Admin','event.folder.created','',NULL,NULL,NULL,'/Smoke/1.4 – Second Matter',NULL,0,'','1.4 – Second Matter','admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4976,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,NULL,'',4952,1,'2026-11-20 02:00:39.267','Admin Admin','event.folder.subfolder.created','',NULL,NULL,NULL,'/Smoke/1.4 – Second Matter',NULL,0,'','1.4 – Second Matter','admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4977,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,NULL,'',4957,1,'2026-11-20 02:00:39.267','Admin Admin','event.folder.permission','',NULL,NULL,NULL,'/Smoke/1.4 – Second Matter',NULL,0,'','1.4 – Second Matter','admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4978,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,NULL,'',4952,1,'2026-11-20 02:00:39.267','Admin Admin','event.folder.subfolder.permission','',NULL,NULL,NULL,'/Smoke/1.4 – Second Matter',NULL,0,'','1.4 – Second Matter','admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4979,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,NULL,'',4958,1,'2026-11-20 02:00:39.267','Admin Admin','event.folder.created','',NULL,NULL,NULL,'/Smoke/1.4 – Second Matter/Documents',NULL,0,'','Documents','admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4980,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,NULL,'',4957,1,'2026-11-20 02:00:39.267','Admin Admin','event.folder.subfolder.created','',NULL,NULL,NULL,'/Smoke/1.4 – Second Matter/Documents',NULL,0,'','Documents','admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4981,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,NULL,'',4957,1,'2026-11-20 02:00:39.267','Admin Admin','event.folder.permission','',NULL,NULL,NULL,'/Smoke/1.4 – Second Matter',NULL,0,'','1.4 – Second Matter','admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4982,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,NULL,'',4952,1,'2026-11-20 02:00:39.267','Admin Admin','event.folder.subfolder.permission','',NULL,NULL,NULL,'/Smoke/1.4 – Second Matter',NULL,0,'','1.4 – Second Matter','admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4983,'2026-11-20 02:00:50','2026-11-20 02:00:50',0,0,1,NULL,'',4959,1,'2026-11-20 02:00:50.684','Admin Admin','event.folder.created','',NULL,NULL,NULL,'/Dépôt Local',NULL,0,'8af886df-3035-4957-8e20-93e3af0f4037','Dépôt Local','admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4984,'2026-11-20 02:00:50','2026-11-20 02:00:50',0,0,1,NULL,'',5,1,'2026-11-20 02:00:50.684','Admin Admin','event.folder.subfolder.created','',NULL,NULL,NULL,'/Dépôt Local',NULL,0,'8af886df-3035-4957-8e20-93e3af0f4037','Dépôt Local','admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4985,'2026-11-20 02:00:50','2026-11-20 02:00:50',0,0,1,NULL,NULL,4959,1,'2026-11-20 02:00:50.761','Admin Admin','event.folder.permission','',NULL,NULL,NULL,'/Dépôt Local',NULL,0,'8af886df-3035-4957-8e20-93e3af0f4037','Dépôt Local','admin',NULL,NULL,'127.0.0.1',NULL,'Downloading Tool on Unknown (UNKNOWN)',NULL,NULL,NULL),
(4986,'2026-11-20 02:00:50','2026-11-20 02:00:50',0,0,1,NULL,NULL,5,1,'2026-11-20 02:00:50.761','Admin Admin','event.folder.subfolder.permission','',NULL,NULL,NULL,'/Dépôt Local',NULL,0,'8af886df-3035-4957-8e20-93e3af0f4037','Dépôt Local','admin',NULL,NULL,'127.0.0.1',NULL,'Downloading Tool on Unknown (UNKNOWN)',NULL,NULL,NULL),
(4987,'2026-11-20 02:00:51','2026-11-20 02:00:51',0,0,1,NULL,'',4960,1,'2026-11-20 02:00:51.207','Admin Admin','event.folder.created','',NULL,NULL,NULL,'/Dépôt Local/1.5 – Dépôt Müller',NULL,0,'','1.5 – Dépôt Müller','admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4988,'2026-11-20 02:00:51','2026-11-20 02:00:51',0,0,1,NULL,'',4959,1,'2026-11-20 02:00:51.207','Admin Admin','event.folder.subfolder.created','',NULL,NULL,NULL,'/Dépôt Local/1.5 – Dépôt Müller',NULL,0,'','1.5 – Dépôt Müller','admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4989,'2026-11-20 02:00:51','2026-11-20 02:00:51',0,0,1,NULL,'',4960,1,'2026-11-20 02:00:51.207','Admin Admin','event.folder.permission','',NULL,NULL,NULL,'/Dépôt Local/1.5 – Dépôt Müller',NULL,0,'','1.5 – Dépôt Müller','admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4990,'2026-11-20 02:00:51','2026-11-20 02:00:51',0,0,1,NULL,'',4959,1,'2026-11-20 02:00:51.207','Admin Admin','event.folder.subfolder.permission','',NULL,NULL,NULL,'/Dépôt Local/1.5 – Dépôt Müller',NULL,0,'','1.5 – Dépôt Müller','admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4991,'2026-11-20 02:00:51','2026-11-20 02:00:51',0,0,1,NULL,'',4961,1,'2026-11-20 02:00:51.207','Admin Admin','event.folder.created','',NULL,NULL,NULL,'/Dépôt Local/1.5 – Dépôt Müller/Documents',NULL,0,'','Documents','admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4992,'2026-11-20 02:00:51','2026-11-20 02:00:51',0,0,1,NULL,'',4960,1,'2026-11-20 02:00:51.207','Admin Admin','event.folder.subfolder.created','',NULL,NULL,NULL,'/Dépôt Local/1.5 – Dépôt Müller/Documents',NULL,0,'','Documents','admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4993,'2026-11-20 02:00:51','2026-11-20 02:00:51',0,0,1,NULL,'',4960,1,'2026-11-20 02:00:51.207','Admin Admin','event.folder.permission','',NULL,NULL,NULL,'/Dépôt Local/1.5 – Dépôt Müller',NULL,0,'','1.5 – Dépôt Müller','admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4994,'2026-11-20 02:00:51','2026-11-20 02:00:51',0,0,1,NULL,'',4959,1,'2026-11-20 02:00:51.207','Admin Admin','event.folder.subfolder.permission','',NULL,NULL,NULL,'/Dépôt Local/1.5 – Dépôt Müller',NULL,0,'','1.5 – Dépôt Müller','admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `ld_folder_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_folder_store`
--

DROP TABLE IF EXISTS `ld_folder_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_folder_store` (
  `ld_folderid` bigint(20) NOT NULL,
  `ld_nodeid` varchar(255) NOT NULL,
  `ld_storeid` int(11) NOT NULL,
  PRIMARY KEY (`ld_folderid`,`ld_nodeid`),
  CONSTRAINT `FK_FOLDER_STORE` FOREIGN KEY (`ld_folderid`) REFERENCES `ld_folder` (`ld_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_folder_store`
--

LOCK TABLES `ld_folder_store` WRITE;
/*!40000 ALTER TABLE `ld_folder_store` DISABLE KEYS */;
/*!40000 ALTER TABLE `ld_folder_store` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_foldertag`
--

DROP TABLE IF EXISTS `ld_foldertag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_foldertag` (
  `ld_folderid` bigint(20) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_tag` varchar(255) DEFAULT NULL,
  KEY `FK_TAG_FOLDER` (`ld_folderid`),
  KEY `LD_FTAG_TAG` (`ld_tag`),
  CONSTRAINT `FK_TAG_FOLDER` FOREIGN KEY (`ld_folderid`) REFERENCES `ld_folder` (`ld_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_foldertag`
--

LOCK TABLES `ld_foldertag` WRITE;
/*!40000 ALTER TABLE `ld_foldertag` DISABLE KEYS */;
/*!40000 ALTER TABLE `ld_foldertag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_generic`
--

DROP TABLE IF EXISTS `ld_generic`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_generic` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_type` varchar(255) NOT NULL,
  `ld_subtype` varchar(255) NOT NULL,
  `ld_qualifier` bigint(20) DEFAULT NULL,
  `ld_string1` varchar(4000) DEFAULT NULL,
  `ld_string2` varchar(4000) DEFAULT NULL,
  `ld_string3` varchar(4000) DEFAULT NULL,
  `ld_string4` varchar(4000) DEFAULT NULL,
  `ld_string5` varchar(1000) DEFAULT NULL,
  `ld_string6` varchar(1000) DEFAULT NULL,
  `ld_string7` varchar(1000) DEFAULT NULL,
  `ld_string8` varchar(1000) DEFAULT NULL,
  `ld_integer1` bigint(20) DEFAULT NULL,
  `ld_integer2` bigint(20) DEFAULT NULL,
  `ld_integer3` bigint(20) DEFAULT NULL,
  `ld_double1` double DEFAULT NULL,
  `ld_double2` double DEFAULT NULL,
  `ld_text1` mediumtext DEFAULT NULL,
  `ld_date1` datetime DEFAULT NULL,
  `ld_date2` datetime DEFAULT NULL,
  PRIMARY KEY (`ld_id`),
  UNIQUE KEY `AK_GENERIC` (`ld_type`,`ld_subtype`,`ld_qualifier`,`ld_tenantid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_generic`
--

LOCK TABLES `ld_generic` WRITE;
/*!40000 ALTER TABLE `ld_generic` DISABLE KEYS */;
INSERT INTO `ld_generic` VALUES
(-52,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'usersetting','dashlet-6',1,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,6,1,0,NULL,NULL,NULL,NULL,NULL),
(-51,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'usersetting','dashlet-3',1,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,0,1,NULL,NULL,NULL,NULL,NULL),
(-50,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'usersetting','dashlet-1',1,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,NULL,NULL,NULL,NULL,NULL),
(4951,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,'usersetting','dashlet-checkout',4951,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,NULL,NULL,NULL,NULL,NULL),
(4952,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,'usersetting','dashlet-locked',4951,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,0,1,NULL,NULL,NULL,NULL,NULL),
(4953,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,'usersetting','dashlet-notes',4951,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4954,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,'usersetting','dashlet-checkout',4952,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,NULL,NULL,NULL,NULL,NULL),
(4955,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,'usersetting','dashlet-locked',4952,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,0,1,NULL,NULL,NULL,NULL,NULL),
(4956,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,'usersetting','dashlet-notes',4952,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4957,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,'usersetting','dashlet-checkout',4953,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,0,0,NULL,NULL,NULL,NULL,NULL),
(4958,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,'usersetting','dashlet-locked',4953,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,3,0,1,NULL,NULL,NULL,NULL,NULL),
(4959,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,'usersetting','dashlet-notes',4953,'0',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `ld_generic` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_generic_ext`
--

DROP TABLE IF EXISTS `ld_generic_ext`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_generic_ext` (
  `ld_genid` bigint(20) NOT NULL,
  `ld_mandatory` int(11) NOT NULL,
  `ld_type` int(11) NOT NULL,
  `ld_editor` bigint(20) NOT NULL,
  `ld_position` int(11) NOT NULL,
  `ld_stringvalue` varchar(4000) DEFAULT NULL,
  `ld_stringvalues` varchar(4000) DEFAULT NULL,
  `ld_intvalue` bigint(20) DEFAULT NULL,
  `ld_doublevalue` double DEFAULT NULL,
  `ld_datevalue` datetime DEFAULT NULL,
  `ld_name` varchar(255) NOT NULL,
  `ld_label` varchar(255) DEFAULT NULL,
  `ld_setid` bigint(20) DEFAULT NULL,
  `ld_hidden` int(11) NOT NULL,
  `ld_readonly` int(11) NOT NULL,
  `ld_multiple` int(11) NOT NULL,
  `ld_parent` varchar(255) DEFAULT NULL,
  `ld_dependson` varchar(255) DEFAULT NULL,
  `ld_validation` varchar(1) DEFAULT NULL,
  `ld_initialization` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`ld_genid`,`ld_name`),
  CONSTRAINT `FK913AF772CF8376C7` FOREIGN KEY (`ld_genid`) REFERENCES `ld_generic` (`ld_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_generic_ext`
--

LOCK TABLES `ld_generic_ext` WRITE;
/*!40000 ALTER TABLE `ld_generic_ext` DISABLE KEYS */;
/*!40000 ALTER TABLE `ld_generic_ext` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_group`
--

DROP TABLE IF EXISTS `ld_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_group` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_name` varchar(255) NOT NULL,
  `ld_description` varchar(255) DEFAULT NULL,
  `ld_type` int(11) NOT NULL,
  `ld_source` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ld_id`),
  UNIQUE KEY `AK_GROUP` (`ld_name`,`ld_tenantid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_group`
--

LOCK TABLES `ld_group` WRITE;
/*!40000 ALTER TABLE `ld_group` DISABLE KEYS */;
INSERT INTO `ld_group` VALUES
(-10000,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'publisher','Group of publishers',0,'local'),
(-1010,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'_user_-1010','',1,'local'),
(-1,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'_user_1',NULL,1,'local'),
(1,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'admin','Group of admins',0,'local'),
(2,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'author','Group of authors',0,'local'),
(3,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'guest','Group of guests',0,'local'),
(4,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'poweruser','Group of power users',0,'local'),
(4951,'2026-11-20 02:00:38','2026-11-20 02:00:38',0,0,1,'Everyone','Every user of the install',0,'local'),
(4952,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,'Smoke SSO','The smoke test\'s stand-in provider\'s healdan-users',0,'local'),
(4953,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,'_user_4951','',1,'local'),
(4954,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,'_user_4952','',1,'local'),
(4955,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,'_user_4953','',1,'local');
/*!40000 ALTER TABLE `ld_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_history`
--

DROP TABLE IF EXISTS `ld_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_history` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_docid` bigint(20) DEFAULT NULL,
  `ld_keylabel` varchar(255) DEFAULT NULL,
  `ld_folderid` bigint(20) DEFAULT NULL,
  `ld_userid` bigint(20) DEFAULT NULL,
  `ld_date` datetime(3) DEFAULT NULL,
  `ld_username` varchar(255) DEFAULT NULL,
  `ld_event` varchar(255) DEFAULT NULL,
  `ld_comment` varchar(4000) DEFAULT NULL,
  `ld_reason` varchar(4000) DEFAULT NULL,
  `ld_version` varchar(255) DEFAULT NULL,
  `ld_fileversion` varchar(10) DEFAULT NULL,
  `ld_path` varchar(4000) DEFAULT NULL,
  `ld_pathold` varchar(4000) DEFAULT NULL,
  `ld_notified` int(11) NOT NULL,
  `ld_sessionid` varchar(255) DEFAULT NULL,
  `ld_new` int(11) DEFAULT NULL,
  `ld_filename` varchar(255) DEFAULT NULL,
  `ld_filenameold` varchar(255) DEFAULT NULL,
  `ld_userlogin` varchar(255) DEFAULT NULL,
  `ld_ip` varchar(255) DEFAULT NULL,
  `ld_revision` varchar(255) DEFAULT NULL,
  `ld_geolocation` varchar(255) DEFAULT NULL,
  `ld_device` varchar(255) DEFAULT NULL,
  `ld_filesize` bigint(20) DEFAULT NULL,
  `ld_color` varchar(255) DEFAULT NULL,
  `ld_impersonator` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ld_id`),
  KEY `LD_HIST_DOCID` (`ld_docid`),
  KEY `LD_HIST_UID` (`ld_userid`),
  KEY `LD_HIST_NOT` (`ld_notified`),
  KEY `LD_HIST_EVENT` (`ld_event`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_history`
--

LOCK TABLES `ld_history` WRITE;
/*!40000 ALTER TABLE `ld_history` DISABLE KEYS */;
INSERT INTO `ld_history` VALUES
(4951,'2026-11-20 02:00:44','2026-11-20 02:00:44',0,0,1,4951,NULL,4956,4952,'2026-11-19 10:15:30.069','User Api','event.stored','',NULL,'1.0','1.0','/Smoke/1.1 – Smoke Matter/Documents',NULL,0,'8c9da877-7056-4e1c-a13e-32cd6e5077d9',1,'Engagement letter.docx',NULL,'apiuser','127.0.0.1','1.0',NULL,'Downloading Tool on Unknown (UNKNOWN)',1304,NULL,NULL),
(4952,'2026-11-20 02:00:45','2026-11-20 02:00:45',0,0,1,4952,NULL,4956,4952,'2026-11-20 02:00:45.454','User Api','event.stored','',NULL,'1.0','1.0','/Smoke/1.1 – Smoke Matter/Documents',NULL,0,'8c9da877-7056-4e1c-a13e-32cd6e5077d9',1,'Résumé naïf.docx',NULL,'apiuser','127.0.0.1','1.0',NULL,'Downloading Tool on Unknown (UNKNOWN)',1288,NULL,NULL),
(4953,'2026-11-20 02:00:46','2026-11-20 02:00:46',0,0,1,4953,NULL,4956,4952,'2026-11-20 02:00:46.668','User Api','event.stored','',NULL,'1.0','1.0','/Smoke/1.1 – Smoke Matter/Documents',NULL,0,'8c9da877-7056-4e1c-a13e-32cd6e5077d9',1,'Draft to delete.docx',NULL,'apiuser','127.0.0.1','1.0',NULL,'Downloading Tool on Unknown (UNKNOWN)',1313,NULL,NULL),
(4954,'2026-11-20 02:00:47','2026-11-20 02:00:47',0,0,1,4951,NULL,4956,4952,'2026-11-19 10:15:31.760','User Api','event.checkedout','',NULL,'1.0','1.0','/Smoke/1.1 – Smoke Matter/Documents',NULL,0,'8c9da877-7056-4e1c-a13e-32cd6e5077d9',1,'Engagement letter.docx',NULL,'apiuser','127.0.0.1','1.0',NULL,'Downloading Tool on Unknown (UNKNOWN)',1304,NULL,NULL),
(4955,'2026-11-20 02:00:47','2026-11-20 02:00:47',0,0,1,4951,NULL,4956,4952,'2026-11-19 10:15:32.000','User Api','event.checkedin','Sent to the client',NULL,'2.0','2.0','/Smoke/1.1 – Smoke Matter/Documents',NULL,0,'8c9da877-7056-4e1c-a13e-32cd6e5077d9',1,'Engagement letter.docx',NULL,'apiuser','127.0.0.1','1.0',NULL,'Downloading Tool on Unknown (UNKNOWN)',1324,NULL,NULL),
(4956,'2026-11-20 02:00:49','2026-11-20 02:00:49',0,0,1,4953,NULL,4956,4952,'2026-11-20 02:00:49.151','User Api','event.deleted','',NULL,'1.0','1.0','/Smoke/1.1 – Smoke Matter/Documents',NULL,0,'8c9da877-7056-4e1c-a13e-32cd6e5077d9',1,'Draft to delete.docx',NULL,'apiuser','127.0.0.1','1.0',NULL,'Downloading Tool on Unknown (UNKNOWN)',1313,NULL,NULL),
(4957,'2026-11-20 02:00:49','2026-11-20 02:00:49',0,0,1,4954,NULL,4956,4952,'2026-11-20 02:00:49.255','User Api','event.stored','',NULL,'1.0','1.0','/Smoke/1.1 – Smoke Matter/Documents',NULL,0,'8c9da877-7056-4e1c-a13e-32cd6e5077d9',1,'Réunion de chantier.eml',NULL,'apiuser','127.0.0.1','1.0',NULL,'Downloading Tool on Unknown (UNKNOWN)',299,NULL,NULL),
(4958,'2026-11-20 02:00:52','2026-11-20 02:00:52',0,0,1,4955,NULL,4961,4952,'2026-11-20 02:00:52.300','User Api','event.stored','',NULL,'1.0','1.0','/Dépôt Local/1.5 – Dépôt Müller/Documents',NULL,0,'8c9da877-7056-4e1c-a13e-32cd6e5077d9',1,'Plan du dépôt.docx',NULL,'apiuser','127.0.0.1','1.0',NULL,'Downloading Tool on Unknown (UNKNOWN)',1304,NULL,NULL),
(4959,'2026-11-20 02:00:53','2026-11-20 02:00:53',0,0,1,4951,NULL,4956,4952,'2026-11-20 02:00:53.682','User Api','event.downloaded','',NULL,'2.0','2.0','/Smoke/1.1 – Smoke Matter/Documents',NULL,0,'8c9da877-7056-4e1c-a13e-32cd6e5077d9',1,'Engagement letter.docx',NULL,'apiuser','127.0.0.1','1.0',NULL,'Downloading Tool on Unknown (UNKNOWN)',1324,NULL,NULL),
(4960,'2026-11-20 02:00:53','2026-11-20 02:00:53',0,0,1,4955,NULL,4961,4952,'2026-11-20 02:00:53.724','User Api','event.downloaded','',NULL,'1.0','1.0','/Dépôt Local/1.5 – Dépôt Müller/Documents',NULL,0,'8c9da877-7056-4e1c-a13e-32cd6e5077d9',1,'Plan du dépôt.docx',NULL,'apiuser','127.0.0.1','1.0',NULL,'Downloading Tool on Unknown (UNKNOWN)',1304,NULL,NULL);
/*!40000 ALTER TABLE `ld_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_impersonator`
--

DROP TABLE IF EXISTS `ld_impersonator`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_impersonator` (
  `ld_userid` bigint(20) NOT NULL,
  `ld_username` varchar(255) NOT NULL,
  PRIMARY KEY (`ld_userid`,`ld_username`),
  CONSTRAINT `FK_IMPERS_USERID` FOREIGN KEY (`ld_userid`) REFERENCES `ld_user` (`ld_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_impersonator`
--

LOCK TABLES `ld_impersonator` WRITE;
/*!40000 ALTER TABLE `ld_impersonator` DISABLE KEYS */;
/*!40000 ALTER TABLE `ld_impersonator` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_legal`
--

DROP TABLE IF EXISTS `ld_legal`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_legal` (
  `ld_name` varchar(255) NOT NULL,
  `ld_title` varchar(255) DEFAULT NULL,
  `ld_category` varchar(255) DEFAULT NULL,
  `ld_date` datetime DEFAULT NULL,
  `ld_sort` int(11) DEFAULT NULL,
  `ld_content` mediumtext NOT NULL,
  PRIMARY KEY (`ld_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_legal`
--

LOCK TABLES `ld_legal` WRITE;
/*!40000 ALTER TABLE `ld_legal` DISABLE KEYS */;
/*!40000 ALTER TABLE `ld_legal` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_legal_confirmation`
--

DROP TABLE IF EXISTS `ld_legal_confirmation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_legal_confirmation` (
  `ld_legal` varchar(255) NOT NULL,
  `ld_date` datetime DEFAULT NULL,
  `ld_username` varchar(255) NOT NULL,
  `ld_user` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ld_legal`,`ld_username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_legal_confirmation`
--

LOCK TABLES `ld_legal_confirmation` WRITE;
/*!40000 ALTER TABLE `ld_legal_confirmation` DISABLE KEYS */;
/*!40000 ALTER TABLE `ld_legal_confirmation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_link`
--

DROP TABLE IF EXISTS `ld_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_link` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_type` varchar(255) NOT NULL,
  `ld_docid1` bigint(20) DEFAULT NULL,
  `ld_docid2` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ld_id`),
  UNIQUE KEY `AK_LINK` (`ld_docid1`,`ld_docid2`,`ld_type`),
  KEY `FK1330661CADD6217` (`ld_docid2`),
  CONSTRAINT `FK1330661CADD6216` FOREIGN KEY (`ld_docid1`) REFERENCES `ld_document` (`ld_id`),
  CONSTRAINT `FK1330661CADD6217` FOREIGN KEY (`ld_docid2`) REFERENCES `ld_document` (`ld_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_link`
--

LOCK TABLES `ld_link` WRITE;
/*!40000 ALTER TABLE `ld_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `ld_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_menu`
--

DROP TABLE IF EXISTS `ld_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_menu` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_name` varchar(255) DEFAULT NULL,
  `ld_parentid` bigint(20) NOT NULL,
  `ld_icon` varchar(255) DEFAULT NULL,
  `ld_type` int(11) NOT NULL,
  `ld_description` varchar(4000) DEFAULT NULL,
  `ld_position` int(11) NOT NULL,
  `ld_enabled` int(11) NOT NULL,
  `ld_routineid` bigint(20) DEFAULT NULL,
  `ld_automation` mediumtext DEFAULT NULL,
  PRIMARY KEY (`ld_id`),
  KEY `FK_MENU_PARENT` (`ld_parentid`),
  CONSTRAINT `FK_MENU_PARENT` FOREIGN KEY (`ld_parentid`) REFERENCES `ld_menu` (`ld_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_menu`
--

LOCK TABLES `ld_menu` WRITE;
/*!40000 ALTER TABLE `ld_menu` DISABLE KEYS */;
INSERT INTO `ld_menu` VALUES
(-2070,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,1,1,'dropbox',16,'document.png',1,NULL,1,1,NULL,NULL),
(-9,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'destroydocs',-5,'menu.png',1,NULL,1,1,NULL,NULL),
(-8,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'apicalls',90,'menu.png',1,NULL,1,1,NULL,NULL),
(-7,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'tickets',90,'menu.png',1,NULL,1,1,NULL,NULL),
(-6,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'deletedfolders',90,'menu.png',1,NULL,1,1,NULL,NULL),
(-5,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'deleteddocs',90,'menu.png',1,NULL,1,1,NULL,NULL),
(-3,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'lockeddocs',90,'menu.png',1,NULL,1,1,NULL,NULL),
(-2,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'lastchanges',90,'menu.png',1,NULL,1,1,NULL,NULL),
(1,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'/',1,'menu.png',1,NULL,1,1,NULL,NULL),
(2,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'administration',1,'menu.png',1,NULL,20,1,NULL,NULL),
(3,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'protocols',7,'menu.png',1,NULL,1,1,NULL,NULL),
(5,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'frontend',1,'menu.png',1,NULL,1,1,NULL,NULL),
(7,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'settings',2,'menu.png',1,NULL,60,1,NULL,NULL),
(8,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'impex',2,'menu.png',1,NULL,40,1,NULL,NULL),
(9,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'accesscontrol',2,'menu.png',1,NULL,20,1,NULL,NULL),
(10,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'index',1500,'menu.png',1,NULL,1,1,NULL,NULL),
(11,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'userinterface',1500,'menu.png',1,NULL,1,1,NULL,NULL),
(12,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'dropspot',1500,'menu.png',1,NULL,1,1,NULL,NULL),
(14,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'scheduledtasks',80,'menu.png',1,NULL,1,1,NULL,NULL),
(16,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'tools',110,'menu.png',1,NULL,20,1,NULL,NULL),
(25,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'documentmetadata',2,'menu.png',1,NULL,30,1,NULL,NULL),
(40,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'account',110,'menu.png',1,NULL,10,1,NULL,NULL),
(41,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'security',40,'menu.png',1,NULL,1,1,NULL,NULL),
(42,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'apikeys',41,'menu.png',1,NULL,1,1,NULL,NULL),
(70,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'general',80,'menu.png',1,NULL,20,1,NULL,NULL),
(71,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'sessions',70,'menu.png',1,NULL,20,1,NULL,NULL),
(72,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'logs',70,'menu.png',1,NULL,20,1,NULL,NULL),
(73,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'runlevel',70,'menu.png',1,NULL,20,1,NULL,NULL),
(80,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'system',2,'system.png',1,NULL,10,1,NULL,NULL),
(90,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'reports',2,'reports.png',1,NULL,48,1,NULL,NULL),
(99,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'proxy',7,'proxy.png',1,NULL,6,1,NULL,NULL),
(100,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'parameters',7,'parameters.png',1,NULL,6,1,NULL,NULL),
(101,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'searchandindexing',7,'searchandindexing.png',1,NULL,6,1,NULL,NULL),
(102,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'guisettings',7,'guisettings.png',1,NULL,6,1,NULL,NULL),
(103,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'outgoingemail',7,'outgoingemail.png',1,NULL,6,1,NULL,NULL),
(105,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,1,1,'stores',7,'repositories.png',1,NULL,6,1,NULL,NULL),
(106,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'auditing',7,'settings.png',1,NULL,6,1,NULL,NULL),
(110,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'mainmenu',5,'menu.png',1,NULL,10,1,NULL,NULL),
(200,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'textcontent',16,'text.png',1,NULL,1,1,NULL,NULL),
(1500,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'documents',5,'menu.png',1,NULL,50,1,NULL,NULL),
(1510,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'search',5,'menu.png',1,NULL,60,1,NULL,NULL),
(1511,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'sharesearch',1510,'menu.png',1,NULL,10,1,NULL,NULL),
(1520,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'dashboard',5,'menu.png',1,NULL,40,1,NULL,NULL),
(1525,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'messages',1520,'menu.png',1,NULL,40,1,NULL,NULL),
(1526,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'calendar',1520,'menu.png',1,NULL,40,1,NULL,NULL),
(1530,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'contacts',40,'menu.png',1,NULL,1,1,NULL,NULL),
(1535,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'interfacedensity',110,'menu.png',1,NULL,5,1,NULL,NULL),
(1600,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'history',1500,'menu.png',1,NULL,10,1,NULL,NULL),
(1601,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'sessions',1600,'menu.png',1,NULL,10,1,NULL,NULL),
(1602,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'trash',1500,'menu.png',1,NULL,10,1,NULL,NULL),
(1603,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'versions',1500,'menu.png',1,NULL,10,1,NULL,NULL),
(1605,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'aliases',1500,'menu.png',1,NULL,10,1,NULL,NULL),
(1606,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'calendar',1500,'menu.png',1,NULL,10,1,NULL,NULL),
(1607,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'signature',1500,'menu.png',1,NULL,10,1,NULL,NULL),
(1608,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'capture',1500,'menu.png',1,NULL,10,1,NULL,NULL),
(1609,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'preview',1500,'menu.png',1,NULL,10,1,NULL,NULL),
(1610,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'rating',1500,'menu.png',1,NULL,10,1,NULL,NULL),
(1896,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'security',9,'security.png',1,NULL,9,1,NULL,NULL),
(1897,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'users',9,'users.png',1,NULL,8,1,NULL,NULL),
(1898,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'groups',9,'groups.png',1,NULL,7,1,NULL,NULL);
/*!40000 ALTER TABLE `ld_menu` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_menu_acl`
--

DROP TABLE IF EXISTS `ld_menu_acl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_menu_acl` (
  `ld_menuid` bigint(20) NOT NULL,
  `ld_groupid` bigint(20) NOT NULL,
  `ld_read` int(11) NOT NULL,
  `ld_write` int(11) NOT NULL,
  PRIMARY KEY (`ld_menuid`,`ld_groupid`),
  KEY `FK_MENUACL_GROUP` (`ld_groupid`),
  CONSTRAINT `FK_MENUACL_GROUP` FOREIGN KEY (`ld_groupid`) REFERENCES `ld_group` (`ld_id`) ON DELETE CASCADE,
  CONSTRAINT `FK_MENUACL_MENU` FOREIGN KEY (`ld_menuid`) REFERENCES `ld_menu` (`ld_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_menu_acl`
--

LOCK TABLES `ld_menu_acl` WRITE;
/*!40000 ALTER TABLE `ld_menu_acl` DISABLE KEYS */;
INSERT INTO `ld_menu_acl` VALUES
(-9,-1010,1,0),
(2,4,1,0),
(5,-10000,1,0),
(5,2,1,0),
(5,3,1,0),
(5,4,1,0),
(10,-10000,1,0),
(10,2,1,0),
(10,3,1,0),
(10,4,1,0),
(11,-10000,1,0),
(11,2,1,0),
(11,3,1,0),
(11,4,1,0),
(12,-10000,1,0),
(12,2,1,0),
(12,3,1,0),
(12,4,1,0),
(14,4,1,0),
(16,-10000,1,0),
(16,2,1,0),
(16,3,1,0),
(16,4,1,0),
(25,4,1,0),
(40,-10000,1,0),
(40,2,1,0),
(40,3,1,0),
(40,4,1,0),
(41,-10000,1,0),
(41,2,1,0),
(41,3,1,0),
(41,4,1,0),
(42,-10000,1,0),
(42,2,1,0),
(42,3,1,0),
(42,4,1,0),
(200,2,1,0),
(200,3,1,0),
(200,4,1,0),
(1500,-10000,1,0),
(1500,2,1,0),
(1500,3,1,0),
(1500,4,1,0),
(1510,-10000,1,0),
(1510,2,1,0),
(1510,3,1,0),
(1510,4,1,0),
(1520,-10000,1,0),
(1520,2,1,0),
(1520,3,1,0),
(1520,4,1,0),
(1525,-10000,1,0),
(1525,2,1,0),
(1525,3,1,0),
(1525,4,1,0),
(1526,-10000,1,0),
(1526,2,1,0),
(1526,3,1,0),
(1526,4,1,0),
(1530,-10000,1,0),
(1530,2,1,0),
(1530,3,1,0),
(1530,4,1,0),
(1535,-10000,1,0),
(1535,2,1,0),
(1535,3,1,0),
(1535,4,1,0),
(1602,-10000,1,0),
(1602,2,1,0),
(1602,3,1,0),
(1602,4,1,0),
(1603,-10000,1,0),
(1603,2,1,0),
(1603,3,1,0),
(1603,4,1,0),
(1606,-10000,1,0),
(1606,2,1,0),
(1606,3,1,0),
(1606,4,1,0),
(1607,-10000,1,0),
(1607,2,1,0),
(1607,3,1,0),
(1607,4,1,0),
(1609,-10000,1,0),
(1609,2,1,0),
(1609,3,1,0),
(1609,4,1,0),
(1610,-10000,1,0),
(1610,2,1,0),
(1610,3,1,0),
(1610,4,1,0);
/*!40000 ALTER TABLE `ld_menu_acl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_messagetemplate`
--

DROP TABLE IF EXISTS `ld_messagetemplate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_messagetemplate` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_name` varchar(255) NOT NULL,
  `ld_language` varchar(10) NOT NULL,
  `ld_description` varchar(1000) DEFAULT NULL,
  `ld_body` varchar(4000) DEFAULT NULL,
  `ld_type` varchar(255) DEFAULT NULL,
  `ld_footer` varchar(4000) DEFAULT NULL,
  `ld_buttons` varchar(4000) DEFAULT NULL,
  `ld_subject` varchar(1000) DEFAULT NULL,
  `ld_category` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ld_id`),
  UNIQUE KEY `AK_MSGTEMPL` (`ld_name`,`ld_language`,`ld_tenantid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_messagetemplate`
--

LOCK TABLES `ld_messagetemplate` WRITE;
/*!40000 ALTER TABLE `ld_messagetemplate` DISABLE KEYS */;
INSERT INTO `ld_messagetemplate` VALUES
(1,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'task.report','en',NULL,'<p>$I18N.get(\'startedon\'): <b>$DateTool.format($started, true)</b><br />\r\n$I18N.get(\'finishedon\'): <b>$DateTool.format($ended, true)</b><br />\r\n$I18N.get(\'duration\'): <b>$DateTool.printDuration($duration)</b></p>\r\n\r\n<hr />\r\n<p>#if( $error ) $I18N.get(\'error\'): <b>$error</b></p>\r\n\r\n<hr />\r\n<p>#end $report</p>','SYSTEM',NULL,NULL,'$product - $task',NULL),
(2,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'psw.rec1','en',NULL,'$I18N.format(\'emailnotifyaccount\', $user.fullName)<br/>\r\n$I18N.get(\'username\'): <b>$user.username</b><br/>\r\n$I18N.get(\'password\'): <b>$password</b><br/>\r\n$I18N.get(\'clickhere\'): <a href=\"$url\">$url</a><br/><br/>\r\n$I18N.get(\'askedtochangepswdatlogin\')','SYSTEM',NULL,NULL,'$product - $I18N.get(\'emailnotifyaccountobject\')',NULL),
(3,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'psw.rec2','en',NULL,'$product - $I18N.get(\'passwordrequest\')<br/><br/>\r\n$I18N.get(\'clickhere\'): <a href=\"$url\">$url</a>','SYSTEM',NULL,NULL,'$product - $I18N.get(\'passwordrequest\')',NULL),
(4,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'newdoc','en',NULL,'$I18N.get(\'newdocscreated\')<br/>\r\n<hr/>\r\n$message\r\n<hr/>\r\n$I18N.get(\'user\'): <b>$creator.fullName</b> $UserTool.getAvatarImg($creator.id, 16) <br/>\r\n$I18N.get(\'date\'): <b>$DateTool.format($CURRENT_DATE, true)</b><br/>\r\n<hr/>\r\n<b>$I18N.get(\'documents\')</b>:\r\n#foreach( $doc in $documents )\r\n  <br/>$doc.fileName | <a href=\"$DocTool.downloadUrl($doc)\">$I18N.get(\'download\')</a> | <a href=\"$DocTool.displayUrl($doc)\">$I18N.get(\'display\')</a>\r\n#end','SYSTEM',NULL,NULL,'$product - $I18N.get(\'newdocscreated\')',NULL),
(5,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'empty','en',NULL,NULL,'USER',NULL,NULL,NULL,NULL),
(7,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'newdevice','en',NULL,'$I18N.get(\'wenoticednewlogin\') <b>$user.username</b> $I18N.get(\'fromnewdevice\')<br/>\r\n$I18N.get(\'device\'): $device.browser $I18N.get(\'on\') $device.operativeSystem<br/>\r\n$I18N.get(\'dateandtime\'): $DateTool.formatDate($event.date)<br/>\r\n$I18N.get(\'ipaddress\'): $client.address<br/>\r\n#if($client.geolocation)\r\n$I18N.get(\'ipgeolocation\'): $client.geolocation<br/>\r\n#end\r\n<br/>\r\n<b>$I18N.get(\'ifthiswasyou\')</b><br/>$I18N.get(\'youcanignore\')\r\n<br/><br/>\r\n<b>$I18N.get(\'ifthiswasnotyou\')</b><br/>$I18N.get(\'stepstoprotect\')<ul>\r\n<li>$I18N.get(\'changeyourpasswd\')</li>\r\n<li>$I18N.get(\'reporttosysadmin\')</li></ul>','SYSTEM',NULL,NULL,'$I18N.get(\'newloginto\') $product $I18N.get(\'ffrom\') $device.browser $I18N.get(\'on\') $device.operativeSystem',NULL),
(8,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,'checkin','en',NULL,'$I18N.get(\'newdocversion\')<br/>\r\n<hr/>\r\n$message\r\n<hr/>\r\n$I18N.get(\'user\'): <b>$user.fullName</b> $UserTool.getAvatarImg($user.id, 16) <br/>\r\n$I18N.get(\'date\'): <b>$DateTool.format($CURRENT_DATE, true)</b><br/>\r\n<hr/>\r\n<b>$I18N.get(\'document\')</b>:<br/>\r\n$document.fileName | <a href=\"$DocTool.downloadUrl($document)\">$I18N.get(\'download\')</a> | <a href=\"$DocTool.displayUrl($document)\">$I18N.get(\'display\')</a><br/>\r\n#if($tile)<img src=\"$tile\" />#end','SYSTEM',NULL,NULL,'$product - $I18N.get(\'newdocversion\')',NULL),
(4951,'2026-11-20 02:00:38','2026-11-20 02:00:38',0,0,1,'bfa.alert','en','Sent to throttle.alert.recipients when the sign-in throttle starts a block','$I18N.format(\'bfaalert\', $product)<br/><br/>\n#if($suspectedUsername)$I18N.get(\'username\'): <b>$suspectedUsername</b><br/>#end\n#if($suspectedIp)$I18N.get(\'ipaddress\'): <b>$suspectedIp</b><br/>#end\n#if($suspectedApiKey)$I18N.get(\'apikey\'): <b>$suspectedApiKey</b><br/>#end\n$I18N.get(\'dateandtime\'): $DateTool.formatDate($date)\n','SYSTEM',NULL,NULL,'$product - $I18N.get(\'bfadetected\')','UTILITY'),
(4952,'2026-11-20 02:00:38','2026-11-20 02:00:38',0,0,1,'signin.adminalert','en','Sent to signin.adminAlert.recipients when admin signs in with its password','The emergency account <b>admin</b> signed in to $product with its password.<br/><br/>$I18N.get(\'ipaddress\'): <b>$ip</b><br/>$I18N.get(\'dateandtime\'): $DateTool.formatDate($date)','SYSTEM',NULL,NULL,'$product - admin signed in with its password','UTILITY'),
(4953,'2026-11-20 02:00:38','2026-11-20 02:00:38',0,0,1,'storage.alert','en','Sent to the admin group when files wait for their storage backend, or a backend fails, for more than 24 hours','Files have been waiting more than 24 hours to reach the storage backend of their Store, or a storage backend has been failing for that long.<br/><br/>Open the Storage tab in the settings of $product to see which, and what to do.','SYSTEM',NULL,NULL,'$product - storage needs attention','UTILITY');
/*!40000 ALTER TABLE `ld_messagetemplate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_note`
--

DROP TABLE IF EXISTS `ld_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_note` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_docid` bigint(20) NOT NULL,
  `ld_username` varchar(255) DEFAULT NULL,
  `ld_userid` bigint(20) DEFAULT NULL,
  `ld_date` datetime DEFAULT NULL,
  `ld_filename` varchar(255) DEFAULT NULL,
  `ld_message` varchar(4000) DEFAULT NULL,
  `ld_page` int(11) NOT NULL,
  `ld_fileversion` varchar(10) DEFAULT NULL,
  `ld_opacity` int(11) NOT NULL,
  `ld_color` varchar(255) DEFAULT NULL,
  `ld_left` double NOT NULL,
  `ld_top` double NOT NULL,
  `ld_width` double NOT NULL,
  `ld_height` double NOT NULL,
  `ld_type` varchar(255) DEFAULT NULL,
  `ld_recipient` varchar(255) DEFAULT NULL,
  `ld_recipientemail` varchar(255) DEFAULT NULL,
  `ld_shape` varchar(255) DEFAULT NULL,
  `ld_linecolor` varchar(255) DEFAULT NULL,
  `ld_lineopacity` int(11) NOT NULL,
  `ld_linewidth` int(11) NOT NULL,
  `ld_rotation` double NOT NULL,
  PRIMARY KEY (`ld_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_note`
--

LOCK TABLES `ld_note` WRITE;
/*!40000 ALTER TABLE `ld_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `ld_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_note_acl`
--

DROP TABLE IF EXISTS `ld_note_acl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_note_acl` (
  `ld_noteid` bigint(20) NOT NULL,
  `ld_groupid` bigint(20) NOT NULL,
  `ld_read` int(11) NOT NULL,
  `ld_write` int(11) NOT NULL,
  `ld_security` int(11) NOT NULL,
  `ld_delete` int(11) NOT NULL,
  PRIMARY KEY (`ld_noteid`,`ld_groupid`),
  KEY `FK_NOTEACL_GROUP` (`ld_groupid`),
  CONSTRAINT `FK_NOTEACL_GROUP` FOREIGN KEY (`ld_groupid`) REFERENCES `ld_group` (`ld_id`) ON DELETE CASCADE,
  CONSTRAINT `FK_NOTEACL_NOTE` FOREIGN KEY (`ld_noteid`) REFERENCES `ld_note` (`ld_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_note_acl`
--

LOCK TABLES `ld_note_acl` WRITE;
/*!40000 ALTER TABLE `ld_note_acl` DISABLE KEYS */;
/*!40000 ALTER TABLE `ld_note_acl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_password_history`
--

DROP TABLE IF EXISTS `ld_password_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_password_history` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_userid` bigint(20) NOT NULL,
  `ld_password` varchar(255) DEFAULT NULL,
  `ld_date` datetime DEFAULT NULL,
  PRIMARY KEY (`ld_id`),
  KEY `LD_PHIST_USERID` (`ld_userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_password_history`
--

LOCK TABLES `ld_password_history` WRITE;
/*!40000 ALTER TABLE `ld_password_history` DISABLE KEYS */;
INSERT INTO `ld_password_history` VALUES
(4951,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,4951,'FDC965A94D35D3014424289990AEF1E536FA6D4834F36D3267C2D1462EE05D59','2026-11-20 02:00:39'),
(4952,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,4952,'E751823996A96790FC70DDE028E6227EF6B8FC5CD6E8B5FE036D78DD9368D048','2026-11-20 02:00:39'),
(4953,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,4953,'A97A472CDBA03E998B4E1A8E42DA04F833CCD0008902ECB6E398C43AB3CDEFE6','2026-11-20 02:00:39');
/*!40000 ALTER TABLE `ld_password_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_patch`
--

DROP TABLE IF EXISTS `ld_patch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_patch` (
  `ld_patch` varchar(255) DEFAULT NULL,
  `ld_date` timestamp NULL DEFAULT NULL,
  `ld_version` varchar(255) DEFAULT NULL,
  `ld_name` varchar(255) DEFAULT NULL,
  `ld_rating` int(11) NOT NULL,
  `ld_size` bigint(20) NOT NULL,
  `ld_description` varchar(4000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_patch`
--

LOCK TABLES `ld_patch` WRITE;
/*!40000 ALTER TABLE `ld_patch` DISABLE KEYS */;
/*!40000 ALTER TABLE `ld_patch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_rating`
--

DROP TABLE IF EXISTS `ld_rating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_rating` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_docid` bigint(20) NOT NULL,
  `ld_userid` bigint(20) NOT NULL,
  `ld_vote` int(11) NOT NULL,
  `ld_username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ld_id`),
  UNIQUE KEY `AK_RATING` (`ld_docid`,`ld_userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_rating`
--

LOCK TABLES `ld_rating` WRITE;
/*!40000 ALTER TABLE `ld_rating` DISABLE KEYS */;
/*!40000 ALTER TABLE `ld_rating` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_recipient`
--

DROP TABLE IF EXISTS `ld_recipient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_recipient` (
  `ld_messageid` bigint(20) NOT NULL,
  `ld_name` varchar(255) NOT NULL,
  `ld_address` varchar(255) NOT NULL,
  `ld_mode` varchar(255) NOT NULL,
  `ld_type` int(11) NOT NULL,
  `ld_read` int(11) NOT NULL,
  KEY `LD_RCP_MID_NAME` (`ld_messageid`,`ld_name`),
  CONSTRAINT `FK406A04126621DEBE` FOREIGN KEY (`ld_messageid`) REFERENCES `ld_systemmessage` (`ld_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_recipient`
--

LOCK TABLES `ld_recipient` WRITE;
/*!40000 ALTER TABLE `ld_recipient` DISABLE KEYS */;
/*!40000 ALTER TABLE `ld_recipient` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_search`
--

DROP TABLE IF EXISTS `ld_search`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_search` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_userid` bigint(20) NOT NULL,
  `ld_name` varchar(255) DEFAULT NULL,
  `ld_description` varchar(1000) DEFAULT NULL,
  `ld_options` varchar(4000) DEFAULT NULL,
  `ld_date` datetime DEFAULT NULL,
  `ld_type` int(11) NOT NULL,
  PRIMARY KEY (`ld_id`),
  UNIQUE KEY `AK_SEARCH` (`ld_userid`,`ld_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_search`
--

LOCK TABLES `ld_search` WRITE;
/*!40000 ALTER TABLE `ld_search` DISABLE KEYS */;
/*!40000 ALTER TABLE `ld_search` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_sequence`
--

DROP TABLE IF EXISTS `ld_sequence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_sequence` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_name` varchar(255) NOT NULL,
  `ld_objectid` bigint(20) NOT NULL,
  `ld_lastreset` datetime DEFAULT NULL,
  `ld_value` bigint(20) NOT NULL,
  PRIMARY KEY (`ld_id`),
  UNIQUE KEY `AK_SEQUENCE` (`ld_name`,`ld_objectid`,`ld_tenantid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_sequence`
--

LOCK TABLES `ld_sequence` WRITE;
/*!40000 ALTER TABLE `ld_sequence` DISABLE KEYS */;
INSERT INTO `ld_sequence` VALUES
(4951,'2026-11-20 02:00:53','2026-11-20 02:00:53',0,0,-1,'wscall-202611',0,'2026-11-20 02:00:53',4),
(4952,'2026-11-20 02:00:53','2026-11-20 02:00:53',0,0,1,'wscall-202611',0,'2026-11-20 02:00:53',2),
(4953,'2026-11-20 02:00:53','2026-11-20 02:00:53',0,0,1,'wscall',0,'2026-11-20 02:00:53',2),
(4954,'2026-11-20 02:00:53','2026-11-20 02:00:53',0,0,-1,'wscall',0,'2026-11-20 02:00:53',4);
/*!40000 ALTER TABLE `ld_sequence` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_session`
--

DROP TABLE IF EXISTS `ld_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_session` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_sid` varchar(255) NOT NULL,
  `ld_username` varchar(255) DEFAULT NULL,
  `ld_key` varchar(255) DEFAULT NULL,
  `ld_node` varchar(255) DEFAULT NULL,
  `ld_tenantname` varchar(255) DEFAULT NULL,
  `ld_creation` datetime DEFAULT NULL,
  `ld_finished` datetime DEFAULT NULL,
  `ld_lastrenew` datetime DEFAULT NULL,
  `ld_status` int(11) NOT NULL,
  `ld_clientid` varchar(255) DEFAULT NULL,
  `ld_clientaddr` varchar(255) DEFAULT NULL,
  `ld_clienthost` varchar(255) DEFAULT NULL,
  `ld_keylabel` varchar(255) DEFAULT NULL,
  `ld_impersonator` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ld_id`),
  UNIQUE KEY `AK_SESSION` (`ld_sid`),
  KEY `LD_SES_USR_STAT` (`ld_username`,`ld_status`),
  KEY `LD_SES_TNT_STAT` (`ld_tenantid`,`ld_status`),
  KEY `LD_SES_STAT` (`ld_status`),
  KEY `LD_SES_USERNAME` (`ld_username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_session`
--

LOCK TABLES `ld_session` WRITE;
/*!40000 ALTER TABLE `ld_session` DISABLE KEYS */;
INSERT INTO `ld_session` VALUES
(4951,'2026-11-20 02:00:53',2,0,1,'51f0986e-f618-4e5a-9d21-9c9b593a30a1','admin',NULL,'9414c6cb-0816-4610-a72f-02bc7b2fbbb9','default','2026-11-20 02:00:43','2026-11-20 02:00:53','2026-11-20 02:00:53',2,'0-0-0-127.0.0.1-curl/8.7.1','127.0.0.1','127.0.0.1',NULL,NULL),
(4952,'2026-11-20 02:00:53',2,0,1,'8c9da877-7056-4e1c-a13e-32cd6e5077d9','apiuser',NULL,'9414c6cb-0816-4610-a72f-02bc7b2fbbb9','default','2026-11-20 02:00:43','2026-11-20 02:00:53','2026-11-20 02:00:53',2,'0-0-0-127.0.0.1-curl/8.7.1','127.0.0.1','127.0.0.1',NULL,NULL),
(4953,'2026-11-20 02:00:53',1,0,1,'8af886df-3035-4957-8e20-93e3af0f4037','admin',NULL,'9414c6cb-0816-4610-a72f-02bc7b2fbbb9','default','2026-11-20 02:00:50','2026-11-20 02:00:53','2026-11-20 02:00:53',2,'admin-1807906825-0-127.0.0.1-curl/8.7.1','127.0.0.1','127.0.0.1',NULL,NULL);
/*!40000 ALTER TABLE `ld_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_systemmessage`
--

DROP TABLE IF EXISTS `ld_systemmessage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_systemmessage` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_author` varchar(255) DEFAULT NULL,
  `ld_messagetext` mediumtext DEFAULT NULL,
  `ld_subject` varchar(1000) DEFAULT NULL,
  `ld_sentdate` datetime NOT NULL,
  `ld_datescope` int(11) DEFAULT NULL,
  `ld_prio` int(11) DEFAULT NULL,
  `ld_confirmation` int(11) DEFAULT NULL,
  `ld_lastnotified` datetime DEFAULT NULL,
  `ld_status` int(11) NOT NULL,
  `ld_trials` int(11) DEFAULT NULL,
  `ld_type` int(11) NOT NULL,
  `ld_html` int(11) NOT NULL,
  PRIMARY KEY (`ld_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_systemmessage`
--

LOCK TABLES `ld_systemmessage` WRITE;
/*!40000 ALTER TABLE `ld_systemmessage` DISABLE KEYS */;
/*!40000 ALTER TABLE `ld_systemmessage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_tag`
--

DROP TABLE IF EXISTS `ld_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_tag` (
  `ld_docid` bigint(20) DEFAULT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_tag` varchar(255) DEFAULT NULL,
  KEY `FK55BBDA227C693DFD` (`ld_docid`),
  KEY `LD_TAG_TAG` (`ld_tag`),
  CONSTRAINT `FK55BBDA227C693DFD` FOREIGN KEY (`ld_docid`) REFERENCES `ld_document` (`ld_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_tag`
--

LOCK TABLES `ld_tag` WRITE;
/*!40000 ALTER TABLE `ld_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `ld_tag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_temp`
--

DROP TABLE IF EXISTS `ld_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_temp` (
  `ld_int` bigint(20) DEFAULT NULL,
  `ld_int1` bigint(20) DEFAULT NULL,
  `ld_date` datetime DEFAULT NULL,
  `ld_string` varchar(4000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_temp`
--

LOCK TABLES `ld_temp` WRITE;
/*!40000 ALTER TABLE `ld_temp` DISABLE KEYS */;
/*!40000 ALTER TABLE `ld_temp` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_template`
--

DROP TABLE IF EXISTS `ld_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_template` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_name` varchar(255) NOT NULL,
  `ld_label` varchar(255) DEFAULT NULL,
  `ld_description` varchar(2000) DEFAULT NULL,
  `ld_readonly` int(11) NOT NULL,
  `ld_type` int(11) NOT NULL,
  `ld_validation` varchar(4000) DEFAULT NULL,
  `ld_initialization` varchar(4000) DEFAULT NULL,
  PRIMARY KEY (`ld_id`),
  UNIQUE KEY `AK_TEMPLATE` (`ld_name`,`ld_tenantid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_template`
--

LOCK TABLES `ld_template` WRITE;
/*!40000 ALTER TABLE `ld_template` DISABLE KEYS */;
INSERT INTO `ld_template` VALUES
(4951,'2026-11-20 02:00:38','2026-11-20 02:00:38',2,0,1,'Healdan profile','Healdan profile','Healdan\'s profile: the values every document and folder carries',0,0,NULL,NULL);
/*!40000 ALTER TABLE `ld_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_template_acl`
--

DROP TABLE IF EXISTS `ld_template_acl`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_template_acl` (
  `ld_templateid` bigint(20) NOT NULL,
  `ld_groupid` bigint(20) NOT NULL,
  `ld_read` int(11) NOT NULL,
  `ld_write` int(11) NOT NULL,
  PRIMARY KEY (`ld_templateid`,`ld_groupid`),
  KEY `FK_TEMPLACL_GROUP` (`ld_groupid`),
  CONSTRAINT `FK_TEMPLACL_GROUP` FOREIGN KEY (`ld_groupid`) REFERENCES `ld_group` (`ld_id`) ON DELETE CASCADE,
  CONSTRAINT `FK_TEMPLACL_TEMPL` FOREIGN KEY (`ld_templateid`) REFERENCES `ld_template` (`ld_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_template_acl`
--

LOCK TABLES `ld_template_acl` WRITE;
/*!40000 ALTER TABLE `ld_template_acl` DISABLE KEYS */;
/*!40000 ALTER TABLE `ld_template_acl` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_template_ext`
--

DROP TABLE IF EXISTS `ld_template_ext`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_template_ext` (
  `ld_templateid` bigint(20) NOT NULL,
  `ld_mandatory` int(11) NOT NULL,
  `ld_type` int(11) NOT NULL,
  `ld_editor` int(11) NOT NULL,
  `ld_position` int(11) NOT NULL,
  `ld_stringvalue` varchar(4000) DEFAULT NULL,
  `ld_stringvalues` varchar(4000) DEFAULT NULL,
  `ld_intvalue` bigint(20) DEFAULT NULL,
  `ld_doublevalue` double DEFAULT NULL,
  `ld_datevalue` datetime DEFAULT NULL,
  `ld_validation` varchar(4000) DEFAULT NULL,
  `ld_initialization` varchar(4000) DEFAULT NULL,
  `ld_name` varchar(255) NOT NULL,
  `ld_label` varchar(255) DEFAULT NULL,
  `ld_setid` bigint(20) DEFAULT NULL,
  `ld_hidden` int(11) NOT NULL,
  `ld_readonly` int(11) NOT NULL,
  `ld_multiple` int(11) NOT NULL,
  `ld_parent` varchar(255) DEFAULT NULL,
  `ld_dependson` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ld_templateid`,`ld_name`),
  CONSTRAINT `FK6BABB84376C86307` FOREIGN KEY (`ld_templateid`) REFERENCES `ld_template` (`ld_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_template_ext`
--

LOCK TABLES `ld_template_ext` WRITE;
/*!40000 ALTER TABLE `ld_template_ext` DISABLE KEYS */;
INSERT INTO `ld_template_ext` VALUES
(4951,0,4,0,2,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'author','Author',NULL,0,0,0,NULL,NULL),
(4951,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'client','Client',NULL,0,1,0,NULL,NULL),
(4951,0,0,0,6,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'comments','Comments',NULL,0,0,0,NULL,NULL),
(4951,1,0,1,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'docclass','Class',4951,0,0,0,NULL,NULL),
(4951,0,0,1,5,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'docsubclass','Subclass',4951,0,0,0,NULL,'docclass'),
(4951,0,0,0,10,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'emailcc','CC',NULL,0,0,0,NULL,NULL),
(4951,0,0,0,8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'emailfrom','From',NULL,0,0,0,NULL,NULL),
(4951,0,0,0,14,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'emailmessageid','Message-ID',NULL,0,0,0,NULL,NULL),
(4951,0,3,0,13,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'emailreceived','Received',NULL,0,0,0,NULL,NULL),
(4951,0,3,0,12,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'emailsent','Sent',NULL,0,0,0,NULL,NULL),
(4951,0,0,0,11,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'emailsubject','Subject',NULL,0,0,0,NULL,NULL),
(4951,0,0,0,9,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'emailto','To',NULL,0,0,0,NULL,NULL),
(4951,0,0,0,7,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'legacydocnum','Legacy doc #',NULL,0,0,0,NULL,NULL),
(4951,0,0,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'matter','Matter',NULL,0,1,0,NULL,NULL),
(4951,0,4,0,3,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'typist','Typist',NULL,0,0,0,NULL,NULL);
/*!40000 ALTER TABLE `ld_template_ext` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_tenant`
--

DROP TABLE IF EXISTS `ld_tenant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_tenant` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_name` varchar(255) DEFAULT NULL,
  `ld_displayname` varchar(4000) DEFAULT NULL,
  `ld_enabled` int(11) NOT NULL,
  `ld_expire` datetime DEFAULT NULL,
  `ld_street` varchar(255) DEFAULT NULL,
  `ld_postalcode` varchar(255) DEFAULT NULL,
  `ld_city` varchar(255) DEFAULT NULL,
  `ld_country` varchar(255) DEFAULT NULL,
  `ld_state` varchar(255) DEFAULT NULL,
  `ld_email` varchar(255) DEFAULT NULL,
  `ld_telephone` varchar(255) DEFAULT NULL,
  `ld_formsquota` bigint(20) DEFAULT NULL,
  `ld_formsquotathr` int(11) DEFAULT NULL,
  `ld_usersquota` bigint(20) DEFAULT NULL,
  `ld_usersquotathr` int(11) DEFAULT NULL,
  `ld_sessionsquota` bigint(20) DEFAULT NULL,
  `ld_sessionsquotathr` int(11) DEFAULT NULL,
  `ld_documentsquota` bigint(20) DEFAULT NULL,
  `ld_documentsquotathr` int(11) DEFAULT NULL,
  `ld_workflowsquota` bigint(20) DEFAULT NULL,
  `ld_workflowsquotathr` int(11) DEFAULT NULL,
  `ld_storagequota` bigint(20) DEFAULT NULL,
  `ld_storagequotathr` int(11) DEFAULT NULL,
  `ld_type` int(11) NOT NULL,
  `ld_creation` datetime DEFAULT NULL,
  `ld_qthreshold` int(11) DEFAULT NULL,
  `ld_qrecipients` varchar(1000) DEFAULT NULL,
  `ld_rousersquota` bigint(20) DEFAULT NULL,
  `ld_rousersquotathr` int(11) DEFAULT NULL,
  `ld_reportsquota` bigint(20) DEFAULT NULL,
  `ld_reportsquotathr` int(11) DEFAULT NULL,
  `ld_apicallsquota` bigint(20) DEFAULT NULL,
  `ld_apicallsquotathr` int(11) DEFAULT NULL,
  `ld_ticketsquota` bigint(20) DEFAULT NULL,
  `ld_ticketsquotathr` int(11) DEFAULT NULL,
  `ld_stampsquota` bigint(20) DEFAULT NULL,
  `ld_stampsquotathr` int(11) DEFAULT NULL,
  `ld_importfoldersquota` bigint(20) DEFAULT NULL,
  `ld_importfoldersquotathr` int(11) DEFAULT NULL,
  `ld_emailaccountsquota` bigint(20) DEFAULT NULL,
  `ld_emailaccountsquotathr` int(11) DEFAULT NULL,
  `ld_pagesquota` bigint(20) DEFAULT NULL,
  `ld_pagesquotathr` int(11) DEFAULT NULL,
  PRIMARY KEY (`ld_id`),
  UNIQUE KEY `AK_TENANT` (`ld_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_tenant`
--

LOCK TABLES `ld_tenant` WRITE;
/*!40000 ALTER TABLE `ld_tenant` DISABLE KEYS */;
INSERT INTO `ld_tenant` VALUES
(1,'2026-11-20 02:00:28',1,0,1,'default','Default',1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2026-11-20 02:00:28',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `ld_tenant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_ticket`
--

DROP TABLE IF EXISTS `ld_ticket`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_ticket` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_ticketid` varchar(255) NOT NULL,
  `ld_docid` bigint(20) NOT NULL,
  `ld_userid` bigint(20) NOT NULL,
  `ld_type` int(11) NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_expired` datetime DEFAULT NULL,
  `ld_count` int(11) NOT NULL,
  `ld_suffix` varchar(255) DEFAULT NULL,
  `ld_enabled` int(11) NOT NULL,
  `ld_maxcount` int(11) DEFAULT NULL,
  `ld_maxviews` int(11) DEFAULT NULL,
  `ld_views` int(11) NOT NULL,
  `ld_password` varchar(255) DEFAULT NULL,
  `ld_username` varchar(255) DEFAULT NULL,
  `ld_userlogin` varchar(255) DEFAULT NULL,
  `ld_targetuserid` bigint(20) DEFAULT NULL,
  `ld_targetusername` varchar(255) DEFAULT NULL,
  `ld_targetlogin` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ld_id`),
  UNIQUE KEY `AK_TICKET` (`ld_ticketid`),
  KEY `FK_TICKET_USER` (`ld_userid`),
  CONSTRAINT `FK_TICKET_USER` FOREIGN KEY (`ld_userid`) REFERENCES `ld_user` (`ld_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_ticket`
--

LOCK TABLES `ld_ticket` WRITE;
/*!40000 ALTER TABLE `ld_ticket` DISABLE KEYS */;
/*!40000 ALTER TABLE `ld_ticket` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_uniquetag`
--

DROP TABLE IF EXISTS `ld_uniquetag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_uniquetag` (
  `ld_tag` varchar(255) NOT NULL,
  `ld_int1` bigint(20) DEFAULT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_count` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`ld_tag`,`ld_tenantid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_uniquetag`
--

LOCK TABLES `ld_uniquetag` WRITE;
/*!40000 ALTER TABLE `ld_uniquetag` DISABLE KEYS */;
/*!40000 ALTER TABLE `ld_uniquetag` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_update`
--

DROP TABLE IF EXISTS `ld_update`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_update` (
  `ld_update` varchar(255) DEFAULT NULL,
  `ld_date` datetime DEFAULT NULL,
  `ld_version` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_update`
--

LOCK TABLES `ld_update` WRITE;
/*!40000 ALTER TABLE `ld_update` DISABLE KEYS */;
/*!40000 ALTER TABLE `ld_update` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_user`
--

DROP TABLE IF EXISTS `ld_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_user` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_enabled` int(11) NOT NULL,
  `ld_username` varchar(255) NOT NULL,
  `ld_password` varchar(255) DEFAULT NULL,
  `ld_name` varchar(255) DEFAULT NULL,
  `ld_firstname` varchar(255) DEFAULT NULL,
  `ld_street` varchar(255) DEFAULT NULL,
  `ld_postalcode` varchar(255) DEFAULT NULL,
  `ld_city` varchar(255) DEFAULT NULL,
  `ld_country` varchar(255) DEFAULT NULL,
  `ld_state` varchar(255) DEFAULT NULL,
  `ld_language` varchar(10) DEFAULT NULL,
  `ld_email` varchar(255) DEFAULT NULL,
  `ld_emailsignature` varchar(1000) DEFAULT NULL,
  `ld_telephone` varchar(255) DEFAULT NULL,
  `ld_telephone2` varchar(255) DEFAULT NULL,
  `ld_whatsapp` varchar(255) DEFAULT NULL,
  `ld_type` int(11) NOT NULL,
  `ld_passwordchanged` datetime DEFAULT NULL,
  `ld_passwordexpires` int(11) NOT NULL,
  `ld_source` int(11) NOT NULL,
  `ld_storagequota` bigint(20) DEFAULT NULL,
  `ld_welcomescreen` int(11) DEFAULT NULL,
  `ld_ipwhitelist` varchar(1000) DEFAULT NULL,
  `ld_ipblacklist` varchar(1000) DEFAULT NULL,
  `ld_passwordexpired` int(11) NOT NULL,
  `ld_defworkspace` bigint(20) DEFAULT NULL,
  `ld_email2` varchar(255) DEFAULT NULL,
  `ld_emailsignature2` varchar(1000) DEFAULT NULL,
  `ld_avatar` mediumtext DEFAULT NULL,
  `ld_expire` datetime DEFAULT NULL,
  `ld_certexpire` datetime DEFAULT NULL,
  `ld_certdn` varchar(1000) DEFAULT NULL,
  `ld_enforcewrktime` int(11) NOT NULL,
  `ld_lastlogin` datetime DEFAULT NULL,
  `ld_secondfactor` varchar(255) DEFAULT NULL,
  `ld_key` varchar(255) DEFAULT NULL,
  `ld_lastenabled` datetime DEFAULT NULL,
  `ld_maxinactivity` int(11) DEFAULT NULL,
  `ld_docsgrid` varchar(4000) DEFAULT NULL,
  `ld_hitsgrid` varchar(4000) DEFAULT NULL,
  `ld_legals` int(11) NOT NULL,
  `ld_dateformat` varchar(255) DEFAULT NULL,
  `ld_dateformatshort` varchar(255) DEFAULT NULL,
  `ld_dateformatlong` varchar(255) DEFAULT NULL,
  `ld_searchpref` varchar(255) DEFAULT NULL,
  `ld_timezone` varchar(255) DEFAULT NULL,
  `ld_company` varchar(255) DEFAULT NULL,
  `ld_sessionsquota` bigint(20) DEFAULT NULL,
  `ld_department` varchar(255) DEFAULT NULL,
  `ld_organizationalunit` varchar(255) DEFAULT NULL,
  `ld_building` varchar(255) DEFAULT NULL,
  `ld_pagesquota` bigint(20) DEFAULT NULL,
  `ld_documentsquota` bigint(20) DEFAULT NULL,
  `ld_qthreshold` int(11) DEFAULT NULL,
  PRIMARY KEY (`ld_id`),
  UNIQUE KEY `AK_USER` (`ld_username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_user`
--

LOCK TABLES `ld_user` WRITE;
/*!40000 ALTER TABLE `ld_user` DISABLE KEYS */;
INSERT INTO `ld_user` VALUES
(-1010,'2026-11-20 02:00:28','2026-11-20 02:00:28',1,0,1,1,'_system','','User','System','','','','',NULL,'en','system@acme.com',NULL,'',NULL,NULL,1,NULL,0,0,-1,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,-1,NULL,NULL,NULL,NULL,NULL,NULL),
(1,'2026-11-20 02:00:38','2026-11-20 02:00:28',2,0,1,1,'admin','8C6976E5B5410415BDE908BD4DEE15DFB167A9C873FC4BB8A81F6F2AB448A918','Admin','Admin','','','','',NULL,'en','admin@admin.net',NULL,'','',NULL,0,NULL,0,0,NULL,1520,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,'2026-11-20 02:00:50',NULL,NULL,'2026-11-20 02:00:28',-1,NULL,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4951,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,1,'sso-user','FDC965A94D35D3014424289990AEF1E536FA6D4834F36D3267C2D1462EE05D59','User','Sso','','','','','','','sso-user@smoke.example',NULL,'','','',0,'2026-11-20 02:00:39',0,0,NULL,1520,NULL,NULL,0,NULL,'',NULL,NULL,NULL,NULL,NULL,0,'2026-11-20 02:00:39',NULL,NULL,'2026-11-20 02:00:39',NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4952,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,1,'apiuser','E751823996A96790FC70DDE028E6227EF6B8FC5CD6E8B5FE036D78DD9368D048','Api','User','','','','','','en','apiuser@example.com',NULL,'','','',0,'2026-11-20 02:00:39',0,0,NULL,1520,NULL,NULL,0,NULL,'',NULL,'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAARMnRFWHRDb21tZW50AHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4eHh4kcXdZAAAAAxJREFUeJxj0MqeDQAB8wExOtRSCwAAAABJRU5ErkJggg',NULL,NULL,NULL,0,'2026-11-20 02:00:43',NULL,NULL,'2026-11-20 02:00:39',NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4953,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,1,'webuser','A97A472CDBA03E998B4E1A8E42DA04F833CCD0008902ECB6E398C43AB3CDEFE6','Web','User','','','','','','en','webuser@example.com',NULL,'','','',0,'2026-11-20 02:00:39',0,0,NULL,1520,NULL,NULL,0,NULL,'',NULL,NULL,NULL,NULL,NULL,0,'2026-11-20 02:00:39',NULL,NULL,'2026-11-20 02:00:39',NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `ld_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_user_history`
--

DROP TABLE IF EXISTS `ld_user_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_user_history` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_userid` bigint(20) DEFAULT NULL,
  `ld_keylabel` varchar(255) DEFAULT NULL,
  `ld_date` datetime(3) DEFAULT NULL,
  `ld_username` varchar(255) DEFAULT NULL,
  `ld_event` varchar(255) DEFAULT NULL,
  `ld_comment` varchar(4000) DEFAULT NULL,
  `ld_notified` int(11) NOT NULL,
  `ld_sessionid` varchar(255) DEFAULT NULL,
  `ld_filename` varchar(255) DEFAULT NULL,
  `ld_userlogin` varchar(255) DEFAULT NULL,
  `ld_ip` varchar(255) DEFAULT NULL,
  `ld_geolocation` varchar(255) DEFAULT NULL,
  `ld_device` varchar(255) DEFAULT NULL,
  `ld_author` varchar(255) DEFAULT NULL,
  `ld_filesize` bigint(20) DEFAULT NULL,
  `ld_folderid` bigint(20) DEFAULT NULL,
  `ld_docid` bigint(20) DEFAULT NULL,
  `ld_path` varchar(4000) DEFAULT NULL,
  `ld_impersonator` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ld_id`),
  KEY `LD_UHIST_UID` (`ld_userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_user_history`
--

LOCK TABLES `ld_user_history` WRITE;
/*!40000 ALTER TABLE `ld_user_history` DISABLE KEYS */;
INSERT INTO `ld_user_history` VALUES
(4951,'2026-11-20 02:00:38','2026-11-20 02:00:38',0,0,1,1,'','2026-11-20 02:00:38.586','Admin Admin','event.user.updated','admin',0,'',NULL,'admin',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4952,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,4951,'','2026-11-20 02:00:39.215','Sso User','event.user.created','sso-user',0,'',NULL,'sso-user',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4953,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,4952,'','2026-11-20 02:00:39.240','User Api','event.user.created','apiuser',0,'',NULL,'apiuser',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4954,'2026-11-20 02:00:39','2026-11-20 02:00:39',0,0,1,4953,'','2026-11-20 02:00:39.255','User Web','event.user.created','webuser',0,'',NULL,'webuser',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
(4955,'2026-11-20 02:00:43','2026-11-20 02:00:43',1,0,1,1,'','2026-11-20 02:00:43.580','Admin Admin','event.user.login','127.0.0.1',0,'51f0986e-f618-4e5a-9d21-9c9b593a30a1',NULL,'admin','127.0.0.1',NULL,'Downloading Tool on Unknown (UNKNOWN)',NULL,NULL,NULL,NULL,NULL,NULL),
(4956,'2026-11-20 02:00:43','2026-11-20 02:00:43',1,0,1,4952,'','2026-11-20 02:00:43.723','User Api','event.user.login','127.0.0.1',0,'8c9da877-7056-4e1c-a13e-32cd6e5077d9',NULL,'apiuser','127.0.0.1',NULL,'Downloading Tool on Unknown (UNKNOWN)',NULL,NULL,NULL,NULL,NULL,NULL),
(4957,'2026-11-20 02:00:50','2026-11-20 02:00:50',1,0,1,1,'','2026-11-20 02:00:50.566','Admin Admin','event.user.login','127.0.0.1',0,'8af886df-3035-4957-8e20-93e3af0f4037',NULL,'admin','127.0.0.1',NULL,'Downloading Tool on Unknown (UNKNOWN)',NULL,NULL,NULL,NULL,NULL,NULL),
(4958,'2026-11-20 02:00:53','2026-11-20 02:00:53',0,0,1,4952,NULL,'2026-11-20 02:00:53.765','User Api','event.user.logout',NULL,0,'8c9da877-7056-4e1c-a13e-32cd6e5077d9',NULL,'apiuser','127.0.0.1',NULL,'Downloading Tool on Unknown (UNKNOWN)',NULL,NULL,NULL,NULL,NULL,NULL),
(4959,'2026-11-20 02:00:53','2026-11-20 02:00:53',0,0,1,1,NULL,'2026-11-20 02:00:53.798','Admin Admin','event.user.logout',NULL,0,'51f0986e-f618-4e5a-9d21-9c9b593a30a1',NULL,'admin','127.0.0.1',NULL,'Downloading Tool on Unknown (UNKNOWN)',NULL,NULL,NULL,NULL,NULL,NULL),
(4960,'2026-11-20 02:00:53','2026-11-20 02:00:53',0,0,1,1,NULL,'2026-11-20 02:00:53.888','Admin Admin','event.user.logout',NULL,0,'8af886df-3035-4957-8e20-93e3af0f4037',NULL,'admin','127.0.0.1',NULL,'Downloading Tool on Unknown (UNKNOWN)',NULL,NULL,NULL,NULL,NULL,NULL),
(4961,'2026-11-20 02:00:53','2026-11-20 02:00:53',0,0,1,4952,NULL,'2026-11-20 02:00:53.890','User Api','event.user.logout',NULL,0,'8c9da877-7056-4e1c-a13e-32cd6e5077d9',NULL,'apiuser','127.0.0.1',NULL,'Downloading Tool on Unknown (UNKNOWN)',NULL,NULL,NULL,NULL,NULL,NULL),
(4962,'2026-11-20 02:00:53','2026-11-20 02:00:53',0,0,1,1,NULL,'2026-11-20 02:00:53.892','Admin Admin','event.user.logout',NULL,0,'51f0986e-f618-4e5a-9d21-9c9b593a30a1',NULL,'admin','127.0.0.1',NULL,'Downloading Tool on Unknown (UNKNOWN)',NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `ld_user_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_usergroup`
--

DROP TABLE IF EXISTS `ld_usergroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_usergroup` (
  `ld_groupid` bigint(20) NOT NULL,
  `ld_userid` bigint(20) NOT NULL,
  PRIMARY KEY (`ld_groupid`,`ld_userid`),
  KEY `FK2435438DB8B12CA9` (`ld_userid`),
  CONSTRAINT `FK2435438D76F11EA1` FOREIGN KEY (`ld_groupid`) REFERENCES `ld_group` (`ld_id`) ON DELETE CASCADE,
  CONSTRAINT `FK2435438DB8B12CA9` FOREIGN KEY (`ld_userid`) REFERENCES `ld_user` (`ld_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_usergroup`
--

LOCK TABLES `ld_usergroup` WRITE;
/*!40000 ALTER TABLE `ld_usergroup` DISABLE KEYS */;
INSERT INTO `ld_usergroup` VALUES
(-1010,-1010),
(-1,1),
(1,1),
(4951,1),
(4951,4951),
(4952,4951),
(4953,4951),
(4951,4952),
(4954,4952),
(4951,4953),
(4955,4953);
/*!40000 ALTER TABLE `ld_usergroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_version`
--

DROP TABLE IF EXISTS `ld_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_version` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_immutable` int(11) NOT NULL,
  `ld_customid` varchar(200) DEFAULT NULL,
  `ld_version` varchar(10) DEFAULT NULL,
  `ld_fileversion` varchar(10) DEFAULT NULL,
  `ld_revision` varchar(255) DEFAULT NULL,
  `ld_date` datetime DEFAULT NULL,
  `ld_creation` datetime DEFAULT NULL,
  `ld_publisher` varchar(255) DEFAULT NULL,
  `ld_publisherid` bigint(20) NOT NULL,
  `ld_creator` varchar(255) DEFAULT NULL,
  `ld_creatorid` bigint(20) NOT NULL,
  `ld_status` int(11) DEFAULT NULL,
  `ld_type` varchar(255) DEFAULT NULL,
  `ld_lockuserid` bigint(20) DEFAULT NULL,
  `ld_lockuser` varchar(255) DEFAULT NULL,
  `ld_language` varchar(10) DEFAULT NULL,
  `ld_filename` varchar(255) DEFAULT NULL,
  `ld_password` varchar(255) DEFAULT NULL,
  `ld_lastnote` varchar(4000) DEFAULT NULL,
  `ld_filesize` bigint(20) DEFAULT NULL,
  `ld_indexed` int(11) NOT NULL DEFAULT 0,
  `ld_embedded` int(11) NOT NULL DEFAULT 0,
  `ld_signed` int(11) NOT NULL,
  `ld_stamped` int(11) NOT NULL,
  `ld_digest` varchar(255) DEFAULT NULL,
  `ld_folderid` bigint(20) DEFAULT NULL,
  `ld_foldername` varchar(1000) DEFAULT NULL,
  `ld_templateid` bigint(20) DEFAULT NULL,
  `ld_templatename` varchar(1000) DEFAULT NULL,
  `ld_tgs` varchar(1000) DEFAULT NULL,
  `ld_username` varchar(255) DEFAULT NULL,
  `ld_userid` bigint(20) DEFAULT NULL,
  `ld_versiondate` datetime DEFAULT NULL,
  `ld_comment` varchar(1000) DEFAULT NULL,
  `ld_event` varchar(255) DEFAULT NULL,
  `ld_documentid` bigint(20) NOT NULL,
  `ld_exportstatus` int(11) NOT NULL,
  `ld_exportid` bigint(20) DEFAULT NULL,
  `ld_exportname` varchar(255) DEFAULT NULL,
  `ld_exportversion` varchar(10) DEFAULT NULL,
  `ld_deleteuserid` bigint(20) DEFAULT NULL,
  `ld_workflowstatus` varchar(1000) DEFAULT NULL,
  `ld_workflowstatusdisp` varchar(1000) DEFAULT NULL,
  `ld_published` int(11) NOT NULL,
  `ld_startpublishing` datetime DEFAULT NULL,
  `ld_stoppublishing` datetime DEFAULT NULL,
  `ld_transactionid` varchar(255) DEFAULT NULL,
  `ld_extresid` varchar(255) DEFAULT NULL,
  `ld_pages` int(11) NOT NULL,
  `ld_previewpages` int(11) NOT NULL,
  `ld_nature` int(11) NOT NULL,
  `ld_formid` bigint(20) DEFAULT NULL,
  `ld_links` int(11) NOT NULL,
  `ld_docattrs` int(11) NOT NULL,
  `ld_color` varchar(255) DEFAULT NULL,
  `ld_fillerid` bigint(20) DEFAULT NULL,
  `ld_filled` int(11) NOT NULL DEFAULT 0,
  `ld_fillmode` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ld_id`),
  UNIQUE KEY `AK_VERSION` (`ld_documentid`,`ld_version`),
  CONSTRAINT `FK9B3BD9118A053CE` FOREIGN KEY (`ld_documentid`) REFERENCES `ld_document` (`ld_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_version`
--

LOCK TABLES `ld_version` WRITE;
/*!40000 ALTER TABLE `ld_version` DISABLE KEYS */;
INSERT INTO `ld_version` VALUES
(4951,'2026-11-20 02:00:45',0,0,1,0,'1','1.0','1.0','1.0','2026-11-20 02:00:44','2026-11-20 02:00:44','User Api',4952,'User Api',4952,0,'docx',NULL,NULL,'en','Engagement letter.docx',NULL,NULL,1304,0,0,0,0,NULL,4956,'Documents',4951,'Healdan profile','','User Api',4952,'2026-11-19 10:15:33','','event.stored',4951,0,NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-11-20 00:00:00',NULL,NULL,NULL,1,-1,0,NULL,0,0,NULL,NULL,0,0),
(4952,'2026-11-20 02:00:46',0,0,1,0,'2','1.0','1.0','1.0','2026-11-20 02:00:45','2026-11-20 02:00:45','User Api',4952,'User Api',4952,0,'docx',NULL,NULL,'en','Résumé naïf.docx',NULL,NULL,1288,0,0,0,0,NULL,4956,'Documents',4951,'Healdan profile','','User Api',4952,'2026-11-20 02:00:45','','event.stored',4952,0,NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-11-20 00:00:00',NULL,NULL,NULL,1,-1,0,NULL,0,0,NULL,NULL,0,0),
(4953,'2026-11-20 02:00:49',1,1,1,0,'3','1.0','1.0','1.0','2026-11-20 02:00:46','2026-11-20 02:00:46','User Api',4952,'User Api',4952,0,'docx',NULL,NULL,'en','Draft to delete.docx',NULL,NULL,1313,0,0,0,0,NULL,4956,'Documents',4951,'Healdan profile','','User Api',4952,'2026-11-20 02:00:46','','event.stored',4953,0,NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-11-20 00:00:00',NULL,NULL,NULL,1,-1,0,NULL,0,0,NULL,NULL,0,0),
(4954,'2026-11-20 02:00:49',0,0,1,0,'1','2.0','2.0','1.0','2026-11-20 02:00:47','2026-11-20 02:00:44','User Api',4952,'User Api',4952,0,'docx',NULL,'User Api','en','Engagement letter.docx',NULL,NULL,1324,0,0,0,0,NULL,4956,'Documents',4951,'Healdan profile','','User Api',4952,'2026-11-20 02:00:47','Sent to the client','event.checkedin',4951,0,NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-11-20 00:00:00',NULL,NULL,NULL,1,-1,0,NULL,0,0,NULL,NULL,0,0),
(4955,'2026-11-20 02:00:50',0,0,1,0,'4','1.0','1.0','1.0','2026-11-20 02:00:49','2026-11-20 02:00:49','User Api',4952,'User Api',4952,0,'eml',NULL,NULL,'en','Réunion de chantier.eml',NULL,NULL,299,0,0,0,0,NULL,4956,'Documents',4951,'Healdan profile','','User Api',4952,'2026-11-20 02:00:49','','event.stored',4954,0,NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-11-20 00:00:00',NULL,NULL,NULL,1,-1,0,NULL,0,0,NULL,NULL,0,0),
(4956,'2026-11-20 02:00:53',0,0,1,0,'5','1.0','1.0','1.0','2026-11-20 02:00:52','2026-11-20 02:00:52','User Api',4952,'User Api',4952,0,'docx',NULL,NULL,'en','Plan du dépôt.docx',NULL,NULL,1304,0,0,0,0,NULL,4961,'Documents',4951,'Healdan profile','','User Api',4952,'2026-11-20 02:00:52','','event.stored',4955,0,NULL,NULL,NULL,NULL,NULL,NULL,1,'2026-11-20 00:00:00',NULL,NULL,NULL,1,-1,0,NULL,0,0,NULL,NULL,0,0);
/*!40000 ALTER TABLE `ld_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_version_ext`
--

DROP TABLE IF EXISTS `ld_version_ext`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_version_ext` (
  `ld_versionid` bigint(20) NOT NULL,
  `ld_mandatory` int(11) NOT NULL,
  `ld_type` int(11) NOT NULL,
  `ld_editor` int(11) NOT NULL,
  `ld_position` int(11) NOT NULL,
  `ld_stringvalue` varchar(4000) DEFAULT NULL,
  `ld_stringvalues` varchar(4000) DEFAULT NULL,
  `ld_intvalue` bigint(20) DEFAULT NULL,
  `ld_doublevalue` double DEFAULT NULL,
  `ld_datevalue` datetime DEFAULT NULL,
  `ld_name` varchar(255) NOT NULL,
  `ld_label` varchar(255) DEFAULT NULL,
  `ld_setid` bigint(20) DEFAULT NULL,
  `ld_hidden` int(11) NOT NULL,
  `ld_readonly` int(11) NOT NULL,
  `ld_multiple` int(11) NOT NULL,
  `ld_parent` varchar(255) DEFAULT NULL,
  `ld_dependson` varchar(255) DEFAULT NULL,
  `ld_validation` varchar(1) DEFAULT NULL,
  `ld_initialization` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`ld_versionid`,`ld_name`),
  CONSTRAINT `FK78C3A1F3B90495EE` FOREIGN KEY (`ld_versionid`) REFERENCES `ld_version` (`ld_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_version_ext`
--

LOCK TABLES `ld_version_ext` WRITE;
/*!40000 ALTER TABLE `ld_version_ext` DISABLE KEYS */;
INSERT INTO `ld_version_ext` VALUES
(4951,0,4,0,2,'apiuser',NULL,4952,NULL,NULL,'author','Author',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4951,0,0,0,0,'1',NULL,NULL,NULL,NULL,'client','Client',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4951,0,0,0,6,NULL,NULL,NULL,NULL,NULL,'comments','Comments',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4951,1,0,1,4,'Docs',NULL,NULL,NULL,NULL,'docclass','Class',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4951,0,0,1,5,NULL,NULL,NULL,NULL,NULL,'docsubclass','Subclass',4951,0,0,0,NULL,'docclass',NULL,NULL),
(4951,0,0,0,10,NULL,NULL,NULL,NULL,NULL,'emailcc','CC',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4951,0,0,0,8,NULL,NULL,NULL,NULL,NULL,'emailfrom','From',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4951,0,0,0,14,NULL,NULL,NULL,NULL,NULL,'emailmessageid','Message-ID',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4951,0,3,0,13,NULL,NULL,NULL,NULL,NULL,'emailreceived','Received',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4951,0,3,0,12,NULL,NULL,NULL,NULL,NULL,'emailsent','Sent',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4951,0,0,0,11,NULL,NULL,NULL,NULL,NULL,'emailsubject','Subject',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4951,0,0,0,9,NULL,NULL,NULL,NULL,NULL,'emailto','To',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4951,0,0,0,7,NULL,NULL,NULL,NULL,NULL,'legacydocnum','Legacy doc #',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4951,0,0,0,1,'1',NULL,NULL,NULL,NULL,'matter','Matter',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4951,0,4,0,3,'apiuser',NULL,4952,NULL,NULL,'typist','Typist',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4952,0,4,0,2,'apiuser',NULL,4952,NULL,NULL,'author','Author',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4952,0,0,0,0,'1',NULL,NULL,NULL,NULL,'client','Client',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4952,0,0,0,6,NULL,NULL,NULL,NULL,NULL,'comments','Comments',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4952,1,0,1,4,'Docs',NULL,NULL,NULL,NULL,'docclass','Class',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4952,0,0,1,5,NULL,NULL,NULL,NULL,NULL,'docsubclass','Subclass',4951,0,0,0,NULL,'docclass',NULL,NULL),
(4952,0,0,0,10,NULL,NULL,NULL,NULL,NULL,'emailcc','CC',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4952,0,0,0,8,NULL,NULL,NULL,NULL,NULL,'emailfrom','From',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4952,0,0,0,14,NULL,NULL,NULL,NULL,NULL,'emailmessageid','Message-ID',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4952,0,3,0,13,NULL,NULL,NULL,NULL,NULL,'emailreceived','Received',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4952,0,3,0,12,NULL,NULL,NULL,NULL,NULL,'emailsent','Sent',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4952,0,0,0,11,NULL,NULL,NULL,NULL,NULL,'emailsubject','Subject',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4952,0,0,0,9,NULL,NULL,NULL,NULL,NULL,'emailto','To',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4952,0,0,0,7,NULL,NULL,NULL,NULL,NULL,'legacydocnum','Legacy doc #',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4952,0,0,0,1,'1',NULL,NULL,NULL,NULL,'matter','Matter',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4952,0,4,0,3,'apiuser',NULL,4952,NULL,NULL,'typist','Typist',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,4,0,2,'apiuser',NULL,4952,NULL,NULL,'author','Author',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,0,0,0,'1',NULL,NULL,NULL,NULL,'client','Client',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,0,0,6,NULL,NULL,NULL,NULL,NULL,'comments','Comments',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,1,0,1,4,'Docs',NULL,NULL,NULL,NULL,'docclass','Class',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,0,1,5,NULL,NULL,NULL,NULL,NULL,'docsubclass','Subclass',4951,0,0,0,NULL,'docclass',NULL,NULL),
(4953,0,0,0,10,NULL,NULL,NULL,NULL,NULL,'emailcc','CC',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,0,0,8,NULL,NULL,NULL,NULL,NULL,'emailfrom','From',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,0,0,14,NULL,NULL,NULL,NULL,NULL,'emailmessageid','Message-ID',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,3,0,13,NULL,NULL,NULL,NULL,NULL,'emailreceived','Received',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,3,0,12,NULL,NULL,NULL,NULL,NULL,'emailsent','Sent',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,0,0,11,NULL,NULL,NULL,NULL,NULL,'emailsubject','Subject',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,0,0,9,NULL,NULL,NULL,NULL,NULL,'emailto','To',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,0,0,7,NULL,NULL,NULL,NULL,NULL,'legacydocnum','Legacy doc #',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,0,0,1,'1',NULL,NULL,NULL,NULL,'matter','Matter',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4953,0,4,0,3,'apiuser',NULL,4952,NULL,NULL,'typist','Typist',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,4,0,2,'apiuser',NULL,4952,NULL,NULL,'author','Author',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,0,0,0,'1',NULL,NULL,NULL,NULL,'client','Client',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,0,0,6,NULL,NULL,NULL,NULL,NULL,'comments','Comments',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,1,0,1,4,'Docs',NULL,NULL,NULL,NULL,'docclass','Class',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,0,1,5,NULL,NULL,NULL,NULL,NULL,'docsubclass','Subclass',4951,0,0,0,NULL,'docclass',NULL,NULL),
(4954,0,0,0,10,NULL,NULL,NULL,NULL,NULL,'emailcc','CC',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,0,0,8,NULL,NULL,NULL,NULL,NULL,'emailfrom','From',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,0,0,14,NULL,NULL,NULL,NULL,NULL,'emailmessageid','Message-ID',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,3,0,13,NULL,NULL,NULL,NULL,NULL,'emailreceived','Received',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,3,0,12,NULL,NULL,NULL,NULL,NULL,'emailsent','Sent',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,0,0,11,NULL,NULL,NULL,NULL,NULL,'emailsubject','Subject',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,0,0,9,NULL,NULL,NULL,NULL,NULL,'emailto','To',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,0,0,7,NULL,NULL,NULL,NULL,NULL,'legacydocnum','Legacy doc #',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,0,0,1,'1',NULL,NULL,NULL,NULL,'matter','Matter',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4954,0,4,0,3,'apiuser',NULL,4952,NULL,NULL,'typist','Typist',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,4,0,2,'apiuser',NULL,4952,NULL,NULL,'author','Author',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,0,0,0,'1',NULL,NULL,NULL,NULL,'client','Client',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,0,0,6,NULL,NULL,NULL,NULL,NULL,'comments','Comments',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,1,0,1,4,'Docs',NULL,NULL,NULL,NULL,'docclass','Class',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,0,1,5,NULL,NULL,NULL,NULL,NULL,'docsubclass','Subclass',4951,0,0,0,NULL,'docclass',NULL,NULL),
(4955,0,5,0,10,NULL,NULL,NULL,NULL,NULL,'emailcc','CC',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,0,0,8,'Ann Example <ann@example.com>',NULL,NULL,NULL,NULL,'emailfrom','From',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,0,0,14,'move-fixture-1@example.com',NULL,NULL,NULL,NULL,'emailmessageid','Message-ID',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,5,0,13,NULL,NULL,NULL,NULL,NULL,'emailreceived','Received',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,3,0,12,NULL,NULL,NULL,NULL,'2026-11-19 09:30:00','emailsent','Sent',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,0,0,11,'Réunion de chantier',NULL,NULL,NULL,NULL,'emailsubject','Subject',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,0,0,9,'Bob Example <bob@example.com>',NULL,NULL,NULL,NULL,'emailto','To',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,0,0,7,NULL,NULL,NULL,NULL,NULL,'legacydocnum','Legacy doc #',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,0,0,1,'1',NULL,NULL,NULL,NULL,'matter','Matter',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4955,0,4,0,3,'apiuser',NULL,4952,NULL,NULL,'typist','Typist',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4956,0,4,0,2,'apiuser',NULL,4952,NULL,NULL,'author','Author',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4956,0,0,0,0,'1',NULL,NULL,NULL,NULL,'client','Client',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4956,0,0,0,6,NULL,NULL,NULL,NULL,NULL,'comments','Comments',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4956,1,0,1,4,'Docs',NULL,NULL,NULL,NULL,'docclass','Class',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4956,0,0,1,5,NULL,NULL,NULL,NULL,NULL,'docsubclass','Subclass',4951,0,0,0,NULL,'docclass',NULL,NULL),
(4956,0,0,0,10,NULL,NULL,NULL,NULL,NULL,'emailcc','CC',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4956,0,0,0,8,NULL,NULL,NULL,NULL,NULL,'emailfrom','From',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4956,0,0,0,14,NULL,NULL,NULL,NULL,NULL,'emailmessageid','Message-ID',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4956,0,3,0,13,NULL,NULL,NULL,NULL,NULL,'emailreceived','Received',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4956,0,3,0,12,NULL,NULL,NULL,NULL,NULL,'emailsent','Sent',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4956,0,0,0,11,NULL,NULL,NULL,NULL,NULL,'emailsubject','Subject',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4956,0,0,0,9,NULL,NULL,NULL,NULL,NULL,'emailto','To',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4956,0,0,0,7,NULL,NULL,NULL,NULL,NULL,'legacydocnum','Legacy doc #',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4956,0,0,0,1,'5',NULL,NULL,NULL,NULL,'matter','Matter',NULL,0,0,0,NULL,NULL,NULL,NULL),
(4956,0,4,0,3,'apiuser',NULL,4952,NULL,NULL,'typist','Typist',NULL,0,0,0,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `ld_version_ext` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_webservicecall`
--

DROP TABLE IF EXISTS `ld_webservicecall`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_webservicecall` (
  `ld_id` bigint(20) NOT NULL,
  `ld_lastmodified` datetime NOT NULL,
  `ld_creation` datetime NOT NULL,
  `ld_recordversion` bigint(20) NOT NULL,
  `ld_deleted` int(11) NOT NULL,
  `ld_tenantid` bigint(20) NOT NULL,
  `ld_keylabel` varchar(255) DEFAULT NULL,
  `ld_userid` bigint(20) DEFAULT NULL,
  `ld_date` datetime(3) DEFAULT NULL,
  `ld_username` varchar(255) DEFAULT NULL,
  `ld_event` varchar(255) DEFAULT NULL,
  `ld_comment` varchar(4000) DEFAULT NULL,
  `ld_path` varchar(4000) DEFAULT NULL,
  `ld_sessionid` varchar(255) DEFAULT NULL,
  `ld_userlogin` varchar(255) DEFAULT NULL,
  `ld_ip` varchar(255) DEFAULT NULL,
  `ld_geolocation` varchar(255) DEFAULT NULL,
  `ld_device` varchar(255) DEFAULT NULL,
  `ld_protocol` varchar(255) DEFAULT NULL,
  `ld_notified` int(11) NOT NULL,
  `ld_impersonator` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ld_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_webservicecall`
--

LOCK TABLES `ld_webservicecall` WRITE;
/*!40000 ALTER TABLE `ld_webservicecall` DISABLE KEYS */;
/*!40000 ALTER TABLE `ld_webservicecall` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ld_workingtime`
--

DROP TABLE IF EXISTS `ld_workingtime`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ld_workingtime` (
  `ld_userid` bigint(20) NOT NULL,
  `ld_dayofweek` int(11) NOT NULL,
  `ld_hourstart` int(11) NOT NULL,
  `ld_minutestart` int(11) NOT NULL,
  `ld_hourend` int(11) NOT NULL,
  `ld_minuteend` int(11) NOT NULL,
  `ld_label` varchar(255) DEFAULT NULL,
  `ld_description` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`ld_userid`,`ld_dayofweek`,`ld_hourstart`,`ld_minutestart`),
  CONSTRAINT `FK_WRKTIME_USER` FOREIGN KEY (`ld_userid`) REFERENCES `ld_user` (`ld_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ld_workingtime`
--

LOCK TABLES `ld_workingtime` WRITE;
/*!40000 ALTER TABLE `ld_workingtime` DISABLE KEYS */;
/*!40000 ALTER TABLE `ld_workingtime` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed
